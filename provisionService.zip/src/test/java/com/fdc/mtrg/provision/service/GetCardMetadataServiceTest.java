package com.fdc.mtrg.provision.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fdc.mtrg.api.Error;
import com.fdc.mtrg.api.*;
import com.fdc.mtrg.provision.config.ApplicationProperties;
import com.fdc.mtrg.provision.error.ApplicationError;
import com.fdc.util.exception.FdcException;
import com.fdc.util.exception.types.FdcSystemException;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@DirtiesContext
@RunWith(MockitoJUnitRunner.class)
public class GetCardMetadataServiceTest {

    @Rule
    public ExpectedException expectedException = ExpectedException.none();

    ObjectMapper objectMapper = new ObjectMapper();

    @Mock
    ObjectMapper mockObjectMapper;

    @Mock
    private RestTemplate restTemplate;

    @Mock
    private ApplicationProperties applicationProperties;

    @Mock
    private ResponseEntity<GetAssetResponse> responseEntity;

    @InjectMocks
    private GetCardMetadataService SUT = new GetCardMetadataService();

    public final static String ROOT_URL = "http://localhost:8081/";
    public final static String MERCHANT_ID = "TEST";
    public final static String TSP_ID = "501";
    public final static String GOOD_ASSET_ID = "3789637f-32a1-4810-a138-4bf34501c509";
    public final static String BAD_ASSET_ID = "3789637f-32a1-4810-a138-4bf34501c5090";

    @Before
    public void init() throws JsonProcessingException {
        setUp();
    }

    @Test
    public void testAsset() throws FdcException, JsonProcessingException {
        doReturn(responseEntity)
                .when(restTemplate)
                .exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(Class.class));
        GetCardMetadataService spyService = spy(SUT);
        spyService.getCardMetadata(MERCHANT_ID, GOOD_ASSET_ID, TSP_ID, UUID.randomUUID().toString());

        verify(restTemplate).exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(Class.class));
    }

    @Test
    public void testAsset_Then_Throw_RestClientException() throws FdcException, JsonProcessingException {
        doThrow(RestClientException.class)
                .when(restTemplate)
                .exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(Class.class));
        expectedException.expect(FdcSystemException.class);
        expectedException.expectMessage(ApplicationError.SERVICE_UNAVAILABLE.getErrorDescription());

        GetCardMetadataService spyService = spy(SUT);
        spyService.getCardMetadata(MERCHANT_ID, BAD_ASSET_ID, TSP_ID, UUID.randomUUID().toString());
    }

    @Test
    public void testAsset_Then_Throw_BadRequestException() throws FdcException, JsonProcessingException {
        Error error = new Error();
        error.setCategory("Category");
        error.setCode("Code");

        ErrorDeveloperInfo developerInfo = new ErrorDeveloperInfo();
        developerInfo.setDeveloperMessage("what a pain!");
        developerInfo.setMoreInfo("more info here");

        List<ErrorDeveloperInfoFieldError> listOfFieldErrorAreYouKiddingMe = new ArrayList<>();
        ErrorDeveloperInfoFieldError oneMoreError = new ErrorDeveloperInfoFieldError();
        oneMoreError.setMessage("Error MEssage");
        oneMoreError.setField("field for error message");
        listOfFieldErrorAreYouKiddingMe.add(oneMoreError);

        developerInfo.setFieldError(listOfFieldErrorAreYouKiddingMe);

        error.setDeveloperInfo(developerInfo);
        error.setMessage("Invalid request format/data.");

        List<NVP> hostExtraInfos = new ArrayList<>();
        NVP testError = new NVP();
        testError.setValue("test");
        testError.setName("test name");
        hostExtraInfos.add(testError);

        error.setHostExtraInfo(hostExtraInfos);

        HttpClientErrorException.BadRequest returnErrorThrown =
                (HttpClientErrorException.BadRequest) HttpClientErrorException.BadRequest.create(HttpStatus.BAD_REQUEST,
                "Bad Request test",
                null,
                        objectMapper.writeValueAsBytes(error),
                null);
        when(mockObjectMapper.readValue(anyString(), eq(com.fdc.mtrg.api.Error.class))).thenReturn(error);

        doThrow(returnErrorThrown)
                .when(restTemplate)
                .exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(Class.class));
        expectedException.expect(FdcException.class);
        expectedException.expectMessage(ApplicationError.INVALID_REQUEST.getErrorDescription());

        GetCardMetadataService spyService = spy(SUT);
        spyService.getCardMetadata(MERCHANT_ID, BAD_ASSET_ID, TSP_ID, UUID.randomUUID().toString());
    }

    private void setUp() throws JsonProcessingException {
        when(applicationProperties.getMasterCardServiceUrl()).thenReturn(ROOT_URL);
        String assetResponseJson = "{\n  \"transactionId\": \"e789518fd7e63afc/df39d906878c9228\",\n  \"mediaContents\":" +
                " {\n    \"mimeType\": \"image/pdf\",\n    \"data\": \"JVBERi0xLjUNJeLjz9MNCjEgMCBvYmoNPDwvTWV0YWRhdGEgM" +
                "iAwIFIvT0NQcm9wZXJ0aWVzPDwvRDw8L09OWzUgMCBSXS9PcmRlciA2IDAgUi9SQkdyb3Vwc1tdPj4vT0NHc1s1IDAgUl0+Pi9QYWdl" +
                "cyAzIDAgUi9UeXBlL0NhdGFsb2c+Pg1lbmRvYmoNMiAwIG9iag08PC9MZW5ndGggNTc5MDQvU3VidHlwZS9YTUwvVHlwZS9NZXRhZGF" +
                "0YT4+c3RyZWFtDQo8P3hwYWNrZXQgYmVnaW49Iu+7vyIgaWQ9Ilc1TTBNcENlaGlIenJlU3pOVGN6a2M5ZCI\"\n  }\n}";

        GetAssetResponse getAssetResponse = objectMapper.readValue(assetResponseJson, GetAssetResponse.class);
        responseEntity = ResponseEntity.ok(getAssetResponse);
    }
}
