package com.fdc.mtrg.provision.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fdc.mtrg.api.*;
import com.fdc.mtrg.api.Error;
import com.fdc.mtrg.provision.config.ApplicationProperties;
import com.fdc.mtrg.provision.error.ApplicationError;
import com.fdc.util.exception.FdcException;
import com.fdc.util.exception.types.FdcSystemException;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@DirtiesContext
@RunWith(MockitoJUnitRunner.class)
public class MasterCardGetTokenServiceTest {

    ObjectMapper objectMapper = new ObjectMapper();

    @Rule
    public ExpectedException expectedException = ExpectedException.none();

    @Mock
    ObjectMapper mockObjectMapper;

    @Mock
    private RestTemplate restTemplate;

    @Mock
    private ApplicationProperties applicationProperties;

    @Mock
    private ResponseEntity<ProvisionTokenResponse> responseEntity;

    @InjectMocks
    private MasterCardGetTokenService SUT = new MasterCardGetTokenService();

    public final static String ROOT_URL = "http://localhost:8081/";
    public final static String MERCHANT_ID = "TEST";
    public final static String TRID = "5001a9f027e5629d11e3949a0800a";
    public final static String CRID = "51da80412172f0eb/9f071f4204e5cadf";
    public final static String TSP_ID = "501";
    public final static String TOKEN_TYPE = "TSP";

    @Before
    public void init() throws JsonProcessingException {
        setUp();
    }

    private void setUp() throws JsonProcessingException {
        when(applicationProperties.getMasterCardServiceUrl()).thenReturn(ROOT_URL);
        String provisionTokenResponseJson = "{\"provision\": {\"transactionId\": \"51da80412172f0eb/9f071f4204e5cadf\",\"" +
                "card\": {\"alias\": \"5675\",\"cardBrandLogoAssetId\": \"800200c9-629d-11e3-949a-0739d27e5a67\",\"cardB" +
                "randDescription\": \"Bank Rewards MasterCard with the super duper rewards program\",\"expiryDate\": {\"" +
                "month\": \"03\",\"year\": \"23\"}},\"tokenInfo\": {\"token\": {\"alias\": \"1234\",\"expiryDate\": {\"m" +
                "onth\": \"03\",\"year\": \"23\"},\"tokenReferenceId\": \"5001a9f027e5629d11e3949a0800a\",\"tspId\": \"5" +
                "01\",\"paymentAccountReferenceId\": \"500181d9f8e0629211e3949a08002\",\"paymentToken\": \"5123456789012" +
                "345\"}}}\n}";

        ProvisionTokenResponse provisionTokenResponse = objectMapper.readValue(provisionTokenResponseJson, ProvisionTokenResponse.class);
        responseEntity = ResponseEntity.ok(provisionTokenResponse);
    }

    @Test
    public void testGetProvision() throws FdcException, JsonProcessingException {
        doReturn(responseEntity)
                .when(restTemplate)
                .exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(Class.class));
        MasterCardGetTokenService spyService = spy(SUT);
        spyService.getToken(MERCHANT_ID, TRID, TSP_ID, TOKEN_TYPE, CRID);
    }

    @Test
    public void testGetProvision_Then_Throw_RestClientException() throws FdcException, JsonProcessingException {
        doThrow(RestClientException.class)
                .when(restTemplate)
                .exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(Class.class));
        expectedException.expect(FdcSystemException.class);
        expectedException.expectMessage(ApplicationError.SERVICE_UNAVAILABLE.getErrorDescription());

        MasterCardGetTokenService spyService = spy(SUT);
        spyService.getToken(MERCHANT_ID, TRID, TSP_ID, TOKEN_TYPE, CRID);
    }

    @Test
    public void testGetProvision_Then_Throw_BadRequestException() throws FdcException, JsonProcessingException {
        Error error = new Error();
        error.setCategory("Category");
        error.setCode("Code");

        ErrorDeveloperInfo developerInfo = new ErrorDeveloperInfo();
        developerInfo.setDeveloperMessage("what a pain!");
        developerInfo.setMoreInfo("more info here");

        List<ErrorDeveloperInfoFieldError> listOfFieldErrorAreYouKiddingMe = new ArrayList<>();
        ErrorDeveloperInfoFieldError oneMoreError = new ErrorDeveloperInfoFieldError();
        oneMoreError.setMessage("Error MEssage");
        oneMoreError.setField("field for error message");
        listOfFieldErrorAreYouKiddingMe.add(oneMoreError);

        developerInfo.setFieldError(listOfFieldErrorAreYouKiddingMe);

        error.setDeveloperInfo(developerInfo);
        error.setMessage("Invalid request format/data.");

        List<NVP> hostExtraInfos = new ArrayList<>();
        NVP testError = new NVP();
        testError.setValue("test");
        testError.setName("test name");
        hostExtraInfos.add(testError);

        error.setHostExtraInfo(hostExtraInfos);

        HttpClientErrorException.BadRequest returnErrorThrown =
                (HttpClientErrorException.BadRequest) HttpClientErrorException.BadRequest.create(HttpStatus.BAD_REQUEST,
                        "Bad Request test",
                        null,
                        objectMapper.writeValueAsBytes(error),
                        null);
        when(mockObjectMapper.readValue(anyString(), eq(com.fdc.mtrg.api.Error.class))).thenReturn(error);

        doThrow(returnErrorThrown)
                .when(restTemplate)
                .exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(Class.class));
        expectedException.expect(FdcException.class);
        expectedException.expectMessage(ApplicationError.INVALID_REQUEST.getErrorDescription());

        MasterCardGetTokenService spyService = spy(SUT);
        spyService.getToken(MERCHANT_ID, TRID, TSP_ID, TOKEN_TYPE, CRID);
    }
}
