package com.fdc.mtrg.provision.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fdc.mtrg.api.*;
import com.fdc.mtrg.api.Error;
import com.fdc.mtrg.provision.config.ApplicationProperties;
import com.fdc.mtrg.provision.error.ApplicationError;
import com.fdc.util.exception.FdcException;
import com.fdc.util.exception.types.FdcSystemException;
import com.mastercard.developer.encryption.EncryptionException;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class CreateLifecycleDeleteServiceTest {

    @Rule
    public ExpectedException expectedException = ExpectedException.none();

    @InjectMocks
    private CreateLifecycleDeleteService lifecycleDeleteService = new CreateLifecycleDeleteService();

    @Mock
    private ObjectMapper objectMapper;

    @Mock
    private ApplicationProperties applicationProperties;

    @Mock
    private RestTemplate restTemplate;

    @Mock
    private UpdateTokenRequest updateTokenRequest;

    Message<UpdateTokenRequest> msg;

    @Mock
    private Error error;

    private String errorStr;

    @Before
    public void setUp() throws JsonProcessingException {
        setData();
        when(applicationProperties.getMasterCardServiceUrl()).thenReturn("http://localhost:8080/");
        msg = MessageBuilder.withPayload(updateTokenRequest).build();
    }

    @Test
    public void testDoOutboundServiceCall_ThenReturnHttp204() throws FdcSystemException, FdcException, JsonProcessingException {
        msg = MessageBuilder.withPayload(updateTokenRequest).build();
        doReturn(new ResponseEntity<>(HttpStatus.NO_CONTENT)).when(restTemplate)
                .exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(Class.class));

        HttpStatus httpStatus = lifecycleDeleteService.doOutboundServiceCall("test", "DWSDWSPMC000000000132d72d4fcb2f4136a0532d3093ff1a45", "123", msg);
        Assert.assertEquals("Not equal", HttpStatus.NO_CONTENT, httpStatus);
    }

    @Test
    public void testDoOutboundServiceCall_Then_Throw_RestClientException() throws FdcSystemException, FdcException, JsonProcessingException {
        doReturn(new ResponseEntity<>(HttpStatus.NO_CONTENT)).when(restTemplate)
                .exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(Class.class));

        HttpStatus httpStatus = lifecycleDeleteService.doOutboundServiceCall("test", "DWSDWSPMC000000000132d72d4fcb2f4136a0532d3093ff1a45", "123", msg);
        Assert.assertEquals("Not equal", HttpStatus.NO_CONTENT, httpStatus);
        doThrow(RestClientException.class).when(restTemplate)
                .exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(Class.class));

        expectedException.expect(FdcSystemException.class);
        expectedException.expectMessage(ApplicationError.SERVICE_UNAVAILABLE.getErrorDescription());

        lifecycleDeleteService.doOutboundServiceCall("test", "DWSDWSPMC000000000132d72d4fcb2f4136a0532d3093ff1a45", "123",msg);
    }

    @Test
    public void testDoOutboundServiceCall_Then_Throw_FdcException() throws FdcSystemException, FdcException, JsonProcessingException {

        HttpClientErrorException.BadRequest returnErrorThrown = (HttpClientErrorException.BadRequest) HttpClientErrorException.BadRequest.create(HttpStatus.BAD_REQUEST,
                "Bad request ressonCode", null, errorStr.getBytes(), null);

        when(objectMapper.readValue(anyString(), eq(Error.class))).thenReturn(error);

        doThrow(returnErrorThrown).when(restTemplate)
                .exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(Class.class));

        expectedException.expect(FdcException.class);

        lifecycleDeleteService.doOutboundServiceCall("test", "DWSDWSPMC000000000132d72d4fcb2f4136a0532d3093ff1a45", "123",msg);
    }


    private void setData() throws JsonProcessingException {
        updateTokenRequest = new UpdateTokenRequest();
        updateTokenRequest.setOperation(Operation.SUSPEND);

        UpdateReason updateReason = new UpdateReason();
        updateReason.setCausedBy(CausedBy.CARDHOLDER);
        updateReason.setReason("Lost/stolen device");
        updateReason.setReasonCode(ReasonCode.DEVICE_LOST);
        updateReason.setTspId(TSPID.MASTERCARD.getValue());

        updateTokenRequest.setUpdateReason(updateReason);

        errorStr= "{\"code\":\"400000\",\"message\":\"Invalid request format/data.\",\"category\":\"common\"," +
                "\"developerInfo\":{\"developerMessage\":\"Invalid request format/data.\"," +
                "\"moreInfo\":null,\"fieldError\":[{\"field\":\"Invalid reasonCode\",\"message\":\"reasonCode\"}]}," +
                "\"hostExtraInfo\":[{\"name\":\"test name\",\"value\":\"test\",\"valueAsList\":null}]}";

        ObjectMapper objectMapper = new ObjectMapper();
        error =  objectMapper.readValue(errorStr, Error.class);

    }
}
