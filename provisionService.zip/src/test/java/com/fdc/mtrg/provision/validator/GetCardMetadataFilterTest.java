package com.fdc.mtrg.provision.validator;

import com.fdc.mtrg.provision.error.ApplicationError;
import com.fdc.mtrg.provision.util.Constants;
import com.fdc.util.exception.FdcException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.validation.FieldError;

import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

@RunWith(MockitoJUnitRunner.class)
public class GetCardMetadataFilterTest {

    @InjectMocks
    private GetCardMetadataFilter metadataFilter = new GetCardMetadataFilter();

    @Test
    public void testDoValidateRequest_valid_tspId() throws FdcException {

        String tspId = "501";
        String merchantId = "TEST";
        String assetId = "3789637f-32a1-4810-a138-4bf34501c509";
        String clientRequestId = UUID.randomUUID().toString();

        boolean validateRequest = metadataFilter.doValidateRequest(merchantId, assetId, tspId, clientRequestId);
        assertTrue(validateRequest);

    }

    @Test
    public void testDoValidateRequest_invalid_tspId() {

        String tspId = "500";
        String merchantId = "TEST";
        String assetId = "3789637f-32a1-4810-a138-4bf34501c509";
        String clientRequestId = UUID.randomUUID().toString();
        try {
            metadataFilter.doValidateRequest(merchantId, assetId, tspId, clientRequestId);
        } catch (Exception ex) {
            assertTrue(ex instanceof FdcException);
            FdcException fdcException = (FdcException) ex;
            assertEquals(ApplicationError.INVALID_REQUEST.getErrorCode(), fdcException.getCode());
            assertEquals(ApplicationError.INVALID_REQUEST.getErrorDescription(), fdcException.getMessage());

            List<FieldError> fieldErrors = fdcException.getFieldError();
            assertNotNull(fieldErrors);

            FieldError fieldError = fieldErrors.get(0);

            assertEquals(Constants.INVALID_TSP_ID, fieldError.getDefaultMessage());
        }
    }
}
