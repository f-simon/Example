package com.fdc.mtrg.provision.utils;

import com.fasterxml.jackson.databind.ObjectMapper;

public class TestUtils {
    public final static String ROOT_URL = "http://localhost:8080/";

    public final static String PARTNER_ID = "merchantId";
    public final static String CLIENT_REQUEST_ID = "CLIENT_REQUEST_ID";
    public final static String TOKEN_REFERENCE_ID = "tokenReferenceId";

    public final static String TRANSACT_REQUEST_PAYLOAD = "{" +
            "  \"transactionType\": \"ECOM\"," +
            "  \"tspId\": \"501\"," +
            "  \"transactionInitiaitionType\": \"CONSUMER\"," +
            "  \"acquirerMerchantId\": \"53722\"" +
            "}";

    public static ObjectMapper realObjectMapper = new ObjectMapper();

    public final static String TRANSACT_RESPONSE_PAYLOAD = "{\n" +
            "  \"transactionId\": \"537edec8-d33e-4ee8-93a7-b9f61876950c\",\n" +
            "  \"token\": {\n" +
            "    \"paymentToken\": \"5001a9f027e5629d11e3949a0800a\"\n" +
            "  },\n" +
            "  \"crypto\":{\n" +
            "      \"cryptogram\": \"5001a9f027e5629d11e3949a0800a\"\n" +
            "  }\n" +
            "}";

    public final static String REQUEST_PAYLOAD = "{\"provision\":{\"card\":{\"cardNumber\":\"54321111111111111\",\"nameOnCard\":\"John Smith\",\"securityCode\":\"444\"," +
            "\"expiryDate\":{\"month\":\"09\",\"year\":\"20\"},\"billingAddress\":{\"type\":\"work\",\"streetAddress\":\"100 Universal City Plaza\",\"locality\":\"Hollywood\"," +
            "\"region\":\"CA\",\"postalCode\":\"91608\",\"country\":\"USA\",\"formatted\":\"100 Universal City Plaza\\nHollywood, CA 91608 US\",\"primary\":true}," +
            "\"source\":\"ACCOUNT_ON_FILE\",\"captureMethod\":\"KEYENTERED\"},\"account\":{\"accountType\":\"GUEST\",\"email\":{\"type\":\"work\",\"value\":\"bjensen@example.com\"," +
            "\"primary\":true},\"clientWalletAccountId\":\"1234560987\",\"clientAppId\":\"1234560987\"},\"deviceDetails\":{\"id\":\"537edec8-d33e-4ee8-93a7-b9f61876950c\"," +
            "\"deviceScore\":\"5\",\"accountScore\":\"5\",\"loaction\":{\"latitude\":\"38.63\",\"longitude\":\"-90.25\",\"ipAddress\":\"172.27.37.221\"}},\"locale\":\"en_US\"}}";


    public static <T> T  getTokenRequest(Class<T> valueType) throws Exception {
        return realObjectMapper.readValue(REQUEST_PAYLOAD.getBytes(), valueType);
    }

    public static <T> T  getTransactRequest(Class<T> valueType) throws Exception {
        return realObjectMapper.readValue(TRANSACT_REQUEST_PAYLOAD.getBytes(), valueType);
    }
}
