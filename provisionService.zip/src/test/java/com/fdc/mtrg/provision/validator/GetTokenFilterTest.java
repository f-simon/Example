package com.fdc.mtrg.provision.validator;

import com.fdc.util.exception.FdcException;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;

@RunWith(MockitoJUnitRunner.class)
public class GetTokenFilterTest {


    @Autowired
    private GetTokenFilter getTokenFilter;

    public final static String MERCHANT_ID = "TEST";
    public final static String TRID = "5001a9f027e5629d11e3949a0800a";
    public final static String CRID = "51da80412172f0eb/9f071f4204e5cadf";
    public final static String TSP_ID = "501";
    public final static String TOKEN_TYPE = "TSP";



    @Before
    public void setUp(){
        getTokenFilter = new GetTokenFilter();
    }

    @Test
    public void testDoValidateRequest_ThenReturnTrue() throws FdcException {

        Boolean returnTrue = getTokenFilter.doValidateRequest(MERCHANT_ID, TRID, TSP_ID, TOKEN_TYPE, CRID);
        Assert.assertTrue(returnTrue);
    }

    @Test(expected = FdcException.class)
    public void testDoValidateRequest_Without_Parameter_ThenThrow_FdcException() throws FdcException {
        getTokenFilter.doValidateRequest(null, null, null, null, null);

    }

    @Test(expected = FdcException.class)
    public void testDoValidateRequest_WithBad_TSP_ThenThrow_FdcException() throws FdcException {
        getTokenFilter.doValidateRequest(MERCHANT_ID, TRID, "XXX", TOKEN_TYPE, CRID);

    }

    @Test(expected = FdcException.class)
    public void testDoValidateRequest_WithBad_TOKEN_TYPE_ThenThrow_FdcException() throws FdcException {
        getTokenFilter.doValidateRequest(MERCHANT_ID, TRID, TSP_ID, "XYZ", CRID);

    }

    @Test(expected = FdcException.class)
    public void testDoValidateRequest_Withot_VALID_TSPID_ThenThrow_FdcException() throws FdcException {
        getTokenFilter.doValidateRequest(MERCHANT_ID, TRID, "500", "XYZ", CRID);

    }

}
