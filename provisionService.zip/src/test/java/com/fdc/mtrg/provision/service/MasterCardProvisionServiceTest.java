package com.fdc.mtrg.provision.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fdc.mtrg.api.*;
import com.fdc.mtrg.provision.config.ApplicationProperties;
import com.fdc.util.exception.FdcException;
import com.fdc.util.exception.types.FdcSystemException;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.messaging.Message;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;

import static com.fdc.mtrg.provision.utils.TestUtils.*;
import static com.fdc.mtrg.provision.utils.TestUtils.TRANSACT_RESPONSE_PAYLOAD;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class MasterCardProvisionServiceTest {

    @InjectMocks
    private MasterCardProvisionService masterCardProvisionService = new MasterCardProvisionService();

    @Mock
    private ApplicationProperties applicationProperties;

    @Mock
    private ResponseEntity<ProvisionTokenResponse> responseEntity;

    @Mock
    private ObjectMapper objectMapper;

    @Mock
    private RestTemplate restTemplate;

    @Mock
    private ProvisionTokenResponse provisionTokenResponse;


    @Mock
    ProvisionTokenRequest pTokenRequest;

    @Before
    public void before() throws  Exception{

    }

    @Rule
    public ExpectedException expectedException = ExpectedException.none();


    @Test
    public void TokenizeTest() throws Exception{
        when(applicationProperties.getMasterCardServiceUrl()).thenReturn(ROOT_URL);

        doReturn(responseEntity).when(restTemplate).exchange(ArgumentMatchers.anyString(),
                ArgumentMatchers.any(HttpMethod.class),
                ArgumentMatchers.any(),
                ArgumentMatchers.<Class<ProvisionTokenResponse>>any());

        when(responseEntity.getBody()).thenReturn(provisionTokenResponse);


        masterCardProvisionService.tokenize("123",
                false,
                "12345",
                pTokenRequest );

    }

    @Test
    public void TokenizeWithSearchTest() throws Exception{
        when(applicationProperties.getMasterCardServiceUrl()).thenReturn(ROOT_URL);

        doReturn(responseEntity).when(restTemplate).exchange(ArgumentMatchers.anyString(),
                ArgumentMatchers.any(HttpMethod.class),
                ArgumentMatchers.any(),
                ArgumentMatchers.<Class<ProvisionTokenResponse>>any());

        when(responseEntity.getBody()).thenReturn(provisionTokenResponse);


        masterCardProvisionService.tokenize("123",
                true,
                "12345",
                pTokenRequest );

    }

    @Test
    public void TokenizeTest_BadRequest() throws Exception{

        when(applicationProperties.getMasterCardServiceUrl()).thenReturn(ROOT_URL);

        com.fdc.mtrg.api.Error error = new com.fdc.mtrg.api.Error();
        error.setCategory("Category");
        error.setCode("Code");

        ErrorDeveloperInfo theDeveloperInfo = new ErrorDeveloperInfo();
        theDeveloperInfo.setDeveloperMessage("what a pain!");
        theDeveloperInfo.setMoreInfo("more info here");

        List<ErrorDeveloperInfoFieldError> listOfFieldErrorAreYouKiddingMe = new ArrayList<ErrorDeveloperInfoFieldError>();
        ErrorDeveloperInfoFieldError oneMoreError = new ErrorDeveloperInfoFieldError();
        oneMoreError.setMessage("One more Error MEssage");
        oneMoreError.setField("field for error message");
        listOfFieldErrorAreYouKiddingMe.add(oneMoreError);

        theDeveloperInfo.setFieldError(listOfFieldErrorAreYouKiddingMe);


        error.setDeveloperInfo(theDeveloperInfo);
        error.setMessage("Error Message");

        List<NVP> hostExtraInfos = new ArrayList<>();
        NVP testError = new NVP();
        testError.setValue("test");
        testError.setName("test name");
        hostExtraInfos.add(testError);

        error.setHostExtraInfo(hostExtraInfos);

        HttpClientErrorException.BadRequest returnErrorThrown = (HttpClientErrorException.BadRequest) HttpClientErrorException.BadRequest.create(HttpStatus.BAD_REQUEST,
                "Bad REquest test",
                null,
                realObjectMapper.writeValueAsBytes(error),
                null);

        when(objectMapper.readValue(anyString(), eq(com.fdc.mtrg.api.Error.class))).thenReturn(error);

        when(restTemplate.exchange(ArgumentMatchers.anyString(),
                ArgumentMatchers.any(HttpMethod.class),
                ArgumentMatchers.any(),
                ArgumentMatchers.<Class<CryptoGramResponse>>any())).thenThrow(returnErrorThrown);


        expectedException.expect(FdcException.class);

        masterCardProvisionService.tokenize("123",
                false,
                "12345",
                pTokenRequest );
    }


    @Test
    public void TokenizeTest__RCE_Exception() throws Exception{
        when(applicationProperties.getMasterCardServiceUrl()).thenReturn(ROOT_URL);

        when(restTemplate.exchange(ArgumentMatchers.anyString(),
                ArgumentMatchers.any(HttpMethod.class),
                ArgumentMatchers.any(),
                ArgumentMatchers.<Class<String>>any())).thenThrow(RestClientException.class);

        expectedException.expect(FdcSystemException.class);

        masterCardProvisionService.tokenize("123",
                false,
                "12345",
                pTokenRequest );
    }

    @Test
    public void TokenizeTest_NullResponse() throws Exception{
        when(applicationProperties.getMasterCardServiceUrl()).thenReturn(ROOT_URL);

        doReturn(responseEntity).when(restTemplate).exchange(ArgumentMatchers.anyString(),
                ArgumentMatchers.any(HttpMethod.class),
                ArgumentMatchers.any(),
                ArgumentMatchers.<Class<ProvisionTokenResponse>>any());

        when(responseEntity.getBody()).thenReturn(null);


        expectedException.expect(FdcSystemException.class);

        masterCardProvisionService.tokenize("123",
                false,
                "12345",
                pTokenRequest );

    }

}
