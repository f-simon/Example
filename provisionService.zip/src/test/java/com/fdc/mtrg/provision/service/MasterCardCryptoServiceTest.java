package com.fdc.mtrg.provision.service;


import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fdc.mtrg.api.*;
import com.fdc.mtrg.provision.config.ApplicationProperties;
import com.fdc.util.exception.FdcException;
import com.fdc.util.exception.types.FdcSystemException;
import org.apache.commons.collections.functors.ExceptionPredicate;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.messaging.Message;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import javax.validation.Valid;
import java.util.ArrayList;
import java.util.List;

import static org.mockito.Mockito.*;
import static com.fdc.mtrg.provision.utils.TestUtils.*;


@RunWith(MockitoJUnitRunner.class)
public class MasterCardCryptoServiceTest {

    @InjectMocks
    private MasterCardCryptoService masterCardCryptoService = new MasterCardCryptoService();

    @Mock
    private ApplicationProperties applicationProperties;

    @Mock
    private ObjectMapper objectMapper;


    @Mock
    private RestTemplate restTemplate;

    @Mock
    Message<CryptoGramRequest> pCryptoGramRequest;

    @Mock
    private ResponseEntity<CryptoGramResponse> responseEntity;

    @Rule
    public ExpectedException expectedException = ExpectedException.none();

    @Before
    public void before() throws  Exception{
        CryptoGramRequest cryptoRequest = getTransactRequest(CryptoGramRequest.class);
        when(pCryptoGramRequest.getPayload()).thenReturn(cryptoRequest);
    }

    @Test
    public void createCryptoGramTest() throws Exception{
        when(applicationProperties.getMasterCardServiceUrl()).thenReturn(ROOT_URL);

        doReturn(responseEntity).when(restTemplate).exchange(ArgumentMatchers.anyString(),
                ArgumentMatchers.any(HttpMethod.class),
                ArgumentMatchers.any(),
                ArgumentMatchers.<Class<CryptoGramResponse>>any());

        when(responseEntity.getBody()).thenReturn(realObjectMapper.readValue(TRANSACT_RESPONSE_PAYLOAD, CryptoGramResponse.class));

        masterCardCryptoService.createCryptoGram("123", "456", "789", pCryptoGramRequest );
    }

    @Test
    public void CreateCryptoGramTest_NullResult() throws Exception{
        when(applicationProperties.getMasterCardServiceUrl()).thenReturn(ROOT_URL);
        doReturn(responseEntity).when(restTemplate).exchange(ArgumentMatchers.anyString(),
                ArgumentMatchers.any(HttpMethod.class),
                ArgumentMatchers.any(),
                ArgumentMatchers.<Class<CryptoGramResponse>>any());

        when(responseEntity.getBody()).thenReturn(null);

        expectedException.expect(FdcSystemException.class);
        masterCardCryptoService.createCryptoGram("123", "456", "789", pCryptoGramRequest );
    }

    @Test
    public void CreateCryptoTest_RCE_Exception() throws Exception{
        when(applicationProperties.getMasterCardServiceUrl()).thenReturn(ROOT_URL);

        when(restTemplate.exchange(ArgumentMatchers.anyString(),
                ArgumentMatchers.any(HttpMethod.class),
                ArgumentMatchers.any(),
                ArgumentMatchers.<Class<String>>any())).thenThrow(RestClientException.class);

        expectedException.expect(FdcSystemException.class);

        masterCardCryptoService.createCryptoGram("123", "456", "789", pCryptoGramRequest );
    }

    @Test
    public void CreateCryptoTest_BadRequest() throws Exception{
        when(applicationProperties.getMasterCardServiceUrl()).thenReturn(ROOT_URL);

        com.fdc.mtrg.api.Error error = new com.fdc.mtrg.api.Error();
        error.setCategory("Category");
        error.setCode("Code");

        ErrorDeveloperInfo theDeveloperInfo = new ErrorDeveloperInfo();
        theDeveloperInfo.setDeveloperMessage("what a pain!");
        theDeveloperInfo.setMoreInfo("more info here");

        List<ErrorDeveloperInfoFieldError> listOfFieldErrorAreYouKiddingMe = new ArrayList<ErrorDeveloperInfoFieldError>();
        ErrorDeveloperInfoFieldError oneMoreError = new ErrorDeveloperInfoFieldError();
        oneMoreError.setMessage("One more Error MEssage");
        oneMoreError.setField("field for error message");
        listOfFieldErrorAreYouKiddingMe.add(oneMoreError);

        theDeveloperInfo.setFieldError(listOfFieldErrorAreYouKiddingMe);


        error.setDeveloperInfo(theDeveloperInfo);
        error.setMessage("Error Message");

        List<NVP> hostExtraInfos = new ArrayList<>();
        NVP testError = new NVP();
        testError.setValue("test");
        testError.setName("test name");
        hostExtraInfos.add(testError);

        error.setHostExtraInfo(hostExtraInfos);

        HttpClientErrorException.BadRequest returnErrorThrown = (HttpClientErrorException.BadRequest) HttpClientErrorException.BadRequest.create(HttpStatus.BAD_REQUEST,
                "Bad REquest test",
                null,
                realObjectMapper.writeValueAsBytes(error),
                null);

        when(objectMapper.readValue(anyString(), eq(com.fdc.mtrg.api.Error.class))).thenReturn(error);

        when(restTemplate.exchange(ArgumentMatchers.anyString(),
                ArgumentMatchers.any(HttpMethod.class),
                ArgumentMatchers.any(),
                ArgumentMatchers.<Class<CryptoGramResponse>>any())).thenThrow(returnErrorThrown);


        expectedException.expect(FdcException.class);

        masterCardCryptoService.createCryptoGram("123", "456", "789", pCryptoGramRequest );
    }
}