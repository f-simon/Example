package com.fdc.mtrg.provision;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cloud.client.circuitbreaker.EnableCircuitBreaker;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.context.annotation.ImportResource;

@SpringBootApplication
@EnableDiscoveryClient
@EnableCircuitBreaker
@EnableCaching
@ImportResource({"classpath:si/provision-token-flow-si.xml", "classpath:si/provison-token-lifecycle-flow.xml", "classpath:si/provision-asset-flow-si.xml"})
public class ProvisionServicesApplication {

    public static void main(String[] args) {
        SpringApplication.run(ProvisionServicesApplication.class, args);
    }

}
