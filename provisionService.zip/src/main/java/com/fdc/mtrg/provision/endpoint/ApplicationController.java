package com.fdc.mtrg.provision.endpoint;

import com.fdc.mtrg.api.CryptoGramRequest;
import com.fdc.mtrg.api.ProvisionTokenRequest;
import com.fdc.mtrg.api.UpdateTokenRequest;
import com.fdc.mtrg.provision.gateway.ApplicationGateway;
import com.fdc.mtrg.provision.util.Constants;
import com.fdc.util.exception.FdcException;
import com.fdc.util.logging.AroundLog;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.expression.spel.SpelEvaluationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import javax.websocket.server.PathParam;

@RestController
@RequestMapping(path = "/v1/merchants/{merchantId}")
public class ApplicationController {

    private static final Logger logger = LoggerFactory.getLogger(ApplicationController.class);

    @Autowired
    private ApplicationGateway applicationGateway;

    @AroundLog
    @PostMapping(path = "/provision-tokens", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.CREATED)
    public ResponseEntity<?> doTokenization(@RequestBody final ProvisionTokenRequest provisionTokenRequest,
                                            @RequestParam(value = Constants.SEARCH, required = false) final boolean search,
                                            @PathVariable final String merchantId,
                                            @RequestHeader(value = Constants.CLIENT_REQUEST_ID, required = true) final String clientRequestId,
                                            HttpServletResponse response) {

        logger.debug("Request received @ doTokenization API for merchant Partner {} for search {} ", merchantId, search);

        ResponseEntity<?> responseEntity = new ResponseEntity<>(applicationGateway.tokenize(merchantId, search, clientRequestId, MessageBuilder.withPayload(provisionTokenRequest).build()), HttpStatus.CREATED);

        return responseEntity;
    }

    @AroundLog
    @ResponseStatus(HttpStatus.OK)
    @GetMapping(path = "/provision-tokens/assets/{assetId}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getCardMetadata(@PathVariable(Constants.MERCHANT_ID) final String merchantId,
                                             @PathVariable(Constants.ASSET_ID) final String assetId,
                                             @PathParam(Constants.TSP_ID) final String tspId,
                                             @RequestHeader(value = Constants.CLIENT_REQUEST_ID) final String clientRequestId) throws FdcException {

        logger.debug("Request received @ getCardMetadata API for merchant Partner {}", merchantId);

        return new ResponseEntity<>(applicationGateway.getCardMetadata(merchantId, assetId, tspId, clientRequestId), HttpStatus.OK);
    }

    @PostMapping(path = "/provision-tokens/{tokenReferenceId}/cryptograms", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.CREATED)
    public ResponseEntity<?> transact(@PathVariable(Constants.MERCHANT_ID) final String merchantId,
                                      @PathVariable(Constants.TOKEN_REF_ID) final String tokenReferenceId,
                                      @RequestBody final CryptoGramRequest cryptogramRequest,
                                      @RequestHeader(value = Constants.CLIENT_REQUEST_ID, required = true) final String clientRequestId) throws FdcException {

        logger.debug("Request received @ transact API for tokenReferenceId {}", tokenReferenceId);

        return new ResponseEntity<>(applicationGateway.transact(merchantId, tokenReferenceId, clientRequestId, MessageBuilder.withPayload(cryptogramRequest).build()), HttpStatus.CREATED);
    }

    @AroundLog
    @GetMapping(path = "/provision-tokens/{tokenReferenceId}", produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> getToken(@PathVariable final String merchantId,
                                      @PathVariable final String tokenReferenceId,
                                      @RequestParam(name = Constants.TSP_ID, required = true) final String tspId,
                                      @RequestParam(name = Constants.TOKEN_TYPE, defaultValue = Constants.TSP, required = true) final String tokenType,
                                      @RequestHeader(value = Constants.CLIENT_REQUEST_ID, required = true) final String clientRequestId) {

        logger.debug("Request received @ dogetToken API for merchantId {}", merchantId);

        return new ResponseEntity<>(applicationGateway.getToken(merchantId, tokenReferenceId, tspId, tokenType, clientRequestId), HttpStatus.OK);
    }

    @AroundLog
    @PatchMapping(path = "/provision-tokens/{tokenReferenceId}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public ResponseEntity<?> lifeCycle(@RequestBody final UpdateTokenRequest lifeCycle,
                                       @PathVariable final String merchantId,
                                       @PathVariable final String tokenReferenceId,
                                       @RequestHeader(value = Constants.CLIENT_REQUEST_ID, required = true) final String clientRequestId) throws SpelEvaluationException {
        logger.debug("Request received @ dolifeCycle API for merchantId {}  and tokenReferenceId {}", merchantId, tokenReferenceId);
        return new ResponseEntity<>(applicationGateway.doLifeCycle(merchantId, tokenReferenceId, clientRequestId, MessageBuilder.withPayload(lifeCycle).build()));
    }
}
