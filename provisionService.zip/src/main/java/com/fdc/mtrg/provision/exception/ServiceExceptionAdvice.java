package com.fdc.mtrg.provision.exception;

import com.fdc.mtrg.provision.error.ApplicationError;
import com.fdc.util.exception.handler.FdcExceptionHandler;
import com.fdc.util.exception.model.FdcDeveloperInfo;
import com.fdc.util.exception.model.FdcExceptionResponse;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

@ControllerAdvice
public class ServiceExceptionAdvice extends FdcExceptionHandler {


    /**
     * Convert a predefined exception to an HTTP Status code and specify the
     * name of a specific view that will be used to display the error.
     *
     * @return Exception view.
     */
    @ExceptionHandler({DataIntegrityViolationException.class})
    @ResponseStatus(HttpStatus.ACCEPTED)
    @ResponseBody
    public FdcExceptionResponse databaseError(DataIntegrityViolationException ex) {
        final FdcExceptionResponse response = new FdcExceptionResponse();
        response.setCode(ApplicationError.INVALID_REQUEST.getErrorCode());
        response.setMessage(ApplicationError.INVALID_REQUEST.getErrorDescription());
        response.setCategory(ApplicationError.INVALID_REQUEST.getCategory());
        FdcDeveloperInfo developerInfo = new FdcDeveloperInfo(ApplicationError.INVALID_REQUEST.getErrorDescription(), null);
        response.setDeveloperInfo(developerInfo);
        return response;
    }
}


