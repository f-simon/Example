package com.fdc.mtrg.provision.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fdc.mtrg.api.ErrorDeveloperInfoFieldError;
import com.fdc.mtrg.api.NVP;
import com.fdc.mtrg.api.UpdateTokenRequest;
import com.fdc.mtrg.provision.config.ApplicationProperties;
import com.fdc.mtrg.provision.error.ApplicationError;
import com.fdc.mtrg.provision.util.Constants;
import com.fdc.util.exception.FdcException;
import com.fdc.util.exception.types.FdcSystemException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.*;
import org.springframework.integration.annotation.ServiceActivator;
import org.springframework.messaging.Message;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.stereotype.Service;
import org.springframework.validation.FieldError;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;

@Service
public class CreateLifecycleDeleteService {
    private static final Logger logger = LoggerFactory.getLogger(CreateLifecycleDeleteService.class);

    @Autowired
    protected ObjectMapper objectMapper;

    @Autowired
    private ApplicationProperties applicationProperties;

    @Autowired
    @Qualifier("provisionRestTemplate")
    private RestTemplate restTemplate;

    @ServiceActivator
    public HttpStatus doOutboundServiceCall(@Header(Constants.PARTNER_ID) final String merchantId,
                                            @Header(Constants.TOKEN_REFERENCE_ID) final String tokenReferenceId,
                                            @Header(Constants.CLIENT_REQUEST_ID) final String clientRequestId,
                                            Message<UpdateTokenRequest> updateTokenRequest) throws FdcSystemException, FdcException, JsonProcessingException {

        logger.debug("Request received @ doOutboundServiceCall API for merchant Action {} and request {} ", merchantId, updateTokenRequest);

        UpdateTokenRequest payload = updateTokenRequest.getPayload();

        HttpEntity<UpdateTokenRequest> supendRequestEntity = new HttpEntity<>(payload, getHttpHeaders(clientRequestId));

        ResponseEntity<?> returnValue = null;
        try {
            returnValue = this.restTemplate.exchange(getUri(Constants.TRANSACT_URI, merchantId, tokenReferenceId), HttpMethod.PATCH, supendRequestEntity, Object.class);
        } catch (final RestClientException rce) {
            logger.error(rce.getMessage(), rce);

            if (rce instanceof HttpClientErrorException.BadRequest) {
                String responseBodyAsString = ((HttpClientErrorException.BadRequest) rce).getResponseBodyAsString();
                com.fdc.mtrg.api.Error error = objectMapper.readValue(responseBodyAsString, com.fdc.mtrg.api.Error.class);

                List<ErrorDeveloperInfoFieldError> infoFieldErrors;
                infoFieldErrors = error.getDeveloperInfo().getFieldError();
                List<FieldError> fieldErrors = new ArrayList<>();
                if (infoFieldErrors != null) {
                    for (ErrorDeveloperInfoFieldError fieldError : infoFieldErrors) {
                        fieldErrors.add(new FieldError(fieldError.getField(), fieldError.getMessage(), fieldError.getField()));
                    }
                }

                List<NVP> hostExtraInfos = error.getHostExtraInfo();
                List<com.fdc.util.exception.model.NVP> hostExtraInfo = new ArrayList<>();
                if (hostExtraInfos != null) {
                    for (NVP nvp : hostExtraInfos) {
                        com.fdc.util.exception.model.NVP nvp1 = new com.fdc.util.exception.model.NVP();
                        nvp1.setName(nvp.getName());
                        nvp1.setValue(nvp.getValue());
                        hostExtraInfo.add(nvp1);
                    }
                }
                throw new FdcException(error.getCode(), error.getMessage(), fieldErrors, error.getCategory(), hostExtraInfo);
            } else {
                throw new FdcSystemException(ApplicationError.SERVICE_UNAVAILABLE.getErrorCode(), ApplicationError.SERVICE_UNAVAILABLE.getErrorDescription());
            }
        }

        if (returnValue == null) {
            logger.error("Getting null response from Mastercard Adapter for suspend API");
            throw new FdcSystemException(ApplicationError.SERVICE_UNAVAILABLE.getErrorCode(), ApplicationError.SERVICE_UNAVAILABLE.getErrorDescription());
        }
        return returnValue.getStatusCode();
    }

    public HttpHeaders getHttpHeaders(String clientRequestId) {
        final HttpHeaders headers = new HttpHeaders();
        headers.set(Constants.ACCCEPT, Constants.CONTENT_TYPE_JSON);
        headers.set(Constants.CONTENT_TYPE, Constants.APPLICATION_JSON);
        headers.set(Constants.CLIENT_REQUEST_ID, clientRequestId);
        return headers;
    }

    public String getUri(String path, String pMerchantId, String tokenReferenceId) {
        final StringBuilder sb = new StringBuilder(applicationProperties.getMasterCardServiceUrl());
        sb.append(Constants.BASE_URL);
        sb.append(pMerchantId);
        sb.append("/");
        sb.append(path);
        sb.append("/");
        sb.append(tokenReferenceId);
        logger.info("Outbound Url {} ", sb.toString());
        return sb.toString();
    }
}
