package com.fdc.mtrg.provision.validator;

import com.fdc.mtrg.provision.error.ApplicationError;
import com.fdc.mtrg.provision.util.Constants;
import com.fdc.util.exception.FdcException;
import com.fdc.util.exception.model.NVP;
import org.springframework.integration.annotation.Filter;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.stereotype.Service;
import org.springframework.validation.FieldError;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

@Service
public class GetCardMetadataFilter {


    @Filter
    public boolean doValidateRequest(@Header(Constants.PARTNER_ID) final String merchantId,
                                     @Header(Constants.ASSET_ID) final String assetId,
                                     @Header(Constants.TSP_ID) final String tspId,
                                     @Header(Constants.CLIENT_REQUEST_ID) final String clientRequestId) throws FdcException {

        List<String> tspList = Arrays.asList("501", "400");
        if (!tspList.contains(tspId)){
            List<FieldError> fieldErrors = new ArrayList<>();
            fieldErrors.add(new FieldError(GetCardMetadataFilter.class.getName(),
                    Constants.INVALID_TSP_ID, Constants.INVALID_TSP_ID));

            NVP badTspId = new NVP();
            badTspId.setName("tspId");
            badTspId.setValue(tspId);

            List<NVP> hostExtraInfo = Collections.singletonList(badTspId);

            throw new FdcException(ApplicationError.INVALID_REQUEST.getErrorCode(),
                    ApplicationError.INVALID_REQUEST.getErrorDescription(),
                    fieldErrors,
                    ApplicationError.INVALID_REQUEST.getCategory(),
                    hostExtraInfo);
        }

        return true;
    }
}
