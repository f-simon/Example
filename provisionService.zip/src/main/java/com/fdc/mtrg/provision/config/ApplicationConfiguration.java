package com.fdc.mtrg.provision.config;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.joda.JodaModule;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.apache.http.client.HttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import org.springframework.http.MediaType;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.util.Arrays;

@Configuration
@ComponentScan({"com.fdc.mtrg.*"})
@EnableAutoConfiguration
@EnableConfigurationProperties({ApplicationProperties.class})
public class ApplicationConfiguration {

    private static final Logger LOGGER = LoggerFactory.getLogger(ApplicationConfiguration.class);

    @Autowired
    private ApplicationProperties appProps;

    @Bean
    @Scope("prototype")
    public MappingJackson2HttpMessageConverter mappingJackson2HttpMessageConverter() {
        final MappingJackson2HttpMessageConverter jsonConverter = new MappingJackson2HttpMessageConverter();
        final ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.registerModule(new JodaModule());
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        objectMapper.setSerializationInclusion(JsonInclude.Include.NON_EMPTY);
        objectMapper.registerModule(new JavaTimeModule());
        objectMapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
        jsonConverter.setSupportedMediaTypes(Arrays.asList(MediaType.APPLICATION_JSON, MediaType.APPLICATION_JSON_UTF8));
        jsonConverter.setPrettyPrint(true);
        jsonConverter.setObjectMapper(objectMapper);
        return jsonConverter;
    }

    public PoolingHttpClientConnectionManager serviceConnectionManager() throws KeyManagementException, UnrecoverableKeyException, NoSuchAlgorithmException, KeyStoreException, CertificateException, IOException {
        final PoolingHttpClientConnectionManager manager = new PoolingHttpClientConnectionManager();
        manager.setMaxTotal(appProps.getPoolingMaxTotal());
        manager.setDefaultMaxPerRoute(appProps.getPoolingDefaultMaxPerRoute());
        return manager;
    }


    public HttpClient serviceHttpClient() throws Exception {
        final PoolingHttpClientConnectionManager poolingConnManager = this.serviceConnectionManager();
        final HttpClientBuilder builder = HttpClientBuilder.create().setConnectionManager(poolingConnManager);
        return builder.build();
    }


    @ConfigurationProperties(prefix = "com.fdc.mtrg")
    public HttpComponentsClientHttpRequestFactory serviceHttpRequestFactory() throws Exception {
        HttpComponentsClientHttpRequestFactory httpComponentsClientHttpRequestFactory = new HttpComponentsClientHttpRequestFactory(this.serviceHttpClient());
        httpComponentsClientHttpRequestFactory.setConnectTimeout(appProps.getConnectionTimeout());
        httpComponentsClientHttpRequestFactory.setReadTimeout(appProps.getReadTimeout());
        httpComponentsClientHttpRequestFactory.setConnectionRequestTimeout(appProps.getConnectionRequestTimeout());
        return httpComponentsClientHttpRequestFactory;
    }

    @Bean(name = "provisionRestTemplate")
    public RestTemplate serviceRestTemplate() throws Exception {
        final RestTemplate serviceRestTemplate = new RestTemplate();
        serviceRestTemplate.setRequestFactory(serviceHttpRequestFactory());
        MappingJackson2HttpMessageConverter converter = new MappingJackson2HttpMessageConverter();
        serviceRestTemplate.getMessageConverters().add(converter);
        return serviceRestTemplate;
    }
}
