package com.fdc.mtrg.provision.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fdc.mtrg.api.ErrorDeveloperInfoFieldError;
import com.fdc.mtrg.api.GetTokenResponse;
import com.fdc.mtrg.api.NVP;
import com.fdc.mtrg.api.ProvisionTokenResponse;
import com.fdc.mtrg.provision.config.ApplicationProperties;
import com.fdc.mtrg.provision.error.ApplicationError;
import com.fdc.mtrg.provision.util.Constants;
import com.fdc.util.exception.FdcException;
import com.fdc.util.exception.FdcRuntimeException;
import com.fdc.util.exception.types.FdcSystemException;
import com.fdc.util.logging.SimpleAroundLog;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.integration.annotation.ServiceActivator;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.stereotype.Service;
import org.springframework.validation.FieldError;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;

@Service
public class MasterCardGetTokenService {

    private static final Logger logger = LoggerFactory.getLogger(MasterCardGetTokenService.class);

    @Autowired
    @Qualifier("provisionRestTemplate")
    protected RestTemplate restTemplate;

    @Autowired
    protected ApplicationProperties applicationProperties;

    @Autowired
    private ObjectMapper objectMapper;

    @SimpleAroundLog
    @ServiceActivator
    @HystrixCommand(commandKey = "mc-provision-command", threadPoolKey = "mc-provision-thread-pool", ignoreExceptions = FdcRuntimeException.class)
    public ProvisionTokenResponse getToken(@Header(Constants.PARTNER_ID) final String pMerchantId,
                                     @Header(Constants.TOKEN_REFERENCE_ID) final String tokenReferenceId,
                                     @Header(Constants.TSP_ID) String tspId,
                                     @Header(Constants.TOKEN_TYPE) String tokenType,
                                     @Header(Constants.CLIENT_REQUEST_ID) String clientRequestId) throws FdcSystemException, FdcException, JsonProcessingException {

        logger.debug("Request received @ getToken API for merchant Partner {} and request {} ", pMerchantId);

        final ProvisionTokenResponse tokenResponse;
        try {
            HttpEntity<String> tokenRequest = new HttpEntity<String>(getHttpHeaders(clientRequestId));

            tokenResponse = this.restTemplate.exchange(getUri(Constants.TRANSACT_URI, pMerchantId, tokenReferenceId, tspId), HttpMethod.GET, tokenRequest, ProvisionTokenResponse.class).getBody();

        } catch (final RestClientException rce) {
            logger.error(rce.getMessage(), rce);

            if (rce instanceof HttpClientErrorException.BadRequest) {
                String responseBodyAsString = ((HttpClientErrorException.BadRequest) rce).getResponseBodyAsString();
                com.fdc.mtrg.api.Error error = objectMapper.readValue(responseBodyAsString, com.fdc.mtrg.api.Error.class);

                List<ErrorDeveloperInfoFieldError> infoFieldErrors;
                infoFieldErrors = error.getDeveloperInfo().getFieldError();
                List<FieldError> fieldErrors = new ArrayList<>();
                if (infoFieldErrors != null) {
                    for (ErrorDeveloperInfoFieldError fieldError : infoFieldErrors) {
                        fieldErrors.add(new FieldError(fieldError.getField(), fieldError.getMessage(), fieldError.getField()));
                    }
                }

                List<NVP> hostExtraInfos = error.getHostExtraInfo();
                List<com.fdc.util.exception.model.NVP> hostExtraInfo = new ArrayList<>();
                if (hostExtraInfos != null) {
                    for (NVP nvp : hostExtraInfos) {
                        com.fdc.util.exception.model.NVP nvp1 = new com.fdc.util.exception.model.NVP();
                        nvp1.setName(nvp.getName());
                        nvp1.setValue(nvp.getValue());
                        hostExtraInfo.add(nvp1);
                    }
                }
                throw new FdcException(error.getCode(), error.getMessage(), fieldErrors, error.getCategory(), hostExtraInfo);
            } else {
                throw new FdcSystemException(ApplicationError.SERVICE_UNAVAILABLE.getErrorCode(), ApplicationError.SERVICE_UNAVAILABLE.getErrorDescription());
            }
        }

        if (tokenResponse == null) {
            logger.error("Getting null response from Mastercard Adapter for GetToken API");
            throw new FdcSystemException(ApplicationError.SERVICE_UNAVAILABLE.getErrorCode(), ApplicationError.SERVICE_UNAVAILABLE.getErrorDescription());
        }

        return tokenResponse;
    }


    public HttpHeaders getHttpHeaders(String clientRequestId) {
        final HttpHeaders headers = new HttpHeaders();
        headers.set(Constants.ACCCEPT, Constants.CONTENT_TYPE_JSON);
        headers.set(Constants.CONTENT_TYPE, Constants.APPLICATION_JSON);
        headers.set(Constants.CLIENT_REQUEST_ID, clientRequestId);
        return headers;
    }

    public String getUri(String path, String pMerchantId, String tokenReferenceId, String tspId) {
        final StringBuilder sb = new StringBuilder(applicationProperties.getMasterCardServiceUrl());
        sb.append(Constants.BASE_URL);
        sb.append(pMerchantId);
        sb.append("/");
        sb.append(path);
        sb.append("/");
        sb.append(tokenReferenceId);
        sb.append("?");
        sb.append(Constants.TSP_ID);
        sb.append("=");
        sb.append(tspId);
        logger.info("Outbound Url {} ", sb.toString());
        return sb.toString();
    }

}
