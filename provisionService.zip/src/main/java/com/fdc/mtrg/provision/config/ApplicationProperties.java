package com.fdc.mtrg.provision.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.core.io.Resource;

@ConfigurationProperties("com.fdc.mtrg.provision")
public class ApplicationProperties {

    private String masterCardServiceUrl;

    /**
     * Read timeout for the RestTemplate outbound call
     */
    private int readTimeout;

    /**
     * Connect timeout for the RestTemplate outbound call
     */
    private int connectionTimeout;

    private int connectionRequestTimeout;

    private int poolingMaxTotal;

    private int poolingDefaultMaxPerRoute;


    public String getMasterCardServiceUrl() {
        return masterCardServiceUrl;
    }

    public void setMasterCardServiceUrl(String masterCardServiceUrl) {
        this.masterCardServiceUrl = masterCardServiceUrl;
    }

    public int getReadTimeout() {
        return readTimeout;
    }

    public void setReadTimeout(int readTimeout) {
        this.readTimeout = readTimeout;
    }

    public int getConnectionTimeout() {
        return connectionTimeout;
    }

    public void setConnectionTimeout(int connectionTimeout) {
        this.connectionTimeout = connectionTimeout;
    }

    public int getConnectionRequestTimeout() {
        return connectionRequestTimeout;
    }

    public void setConnectionRequestTimeout(int connectionRequestTimeout) {
        this.connectionRequestTimeout = connectionRequestTimeout;
    }

    public int getPoolingMaxTotal() {
        return poolingMaxTotal;
    }

    public void setPoolingMaxTotal(int poolingMaxTotal) {
        this.poolingMaxTotal = poolingMaxTotal;
    }

    public int getPoolingDefaultMaxPerRoute() {
        return poolingDefaultMaxPerRoute;
    }

    public void setPoolingDefaultMaxPerRoute(int poolingDefaultMaxPerRoute) {
        this.poolingDefaultMaxPerRoute = poolingDefaultMaxPerRoute;
    }
}
