package com.fdc.mtrg.provision.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fdc.mtrg.api.GetTokenResponse;
import com.fdc.mtrg.provision.config.ApplicationProperties;
import com.fdc.mtrg.provision.util.Constants;
import com.fdc.util.exception.FdcException;
import com.fdc.util.exception.FdcRuntimeException;
import com.fdc.util.exception.types.FdcSystemException;
import com.fdc.util.logging.SimpleAroundLog;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpHeaders;
import org.springframework.integration.annotation.ServiceActivator;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class VisaGetTokenService {

    private static final Logger logger = LoggerFactory.getLogger(VisaGetTokenService.class);

    @Autowired
    @Qualifier("provisionRestTemplate")
    protected RestTemplate restTemplate;

    @Autowired
    protected ApplicationProperties applicationProperties;

    @Autowired
    private ObjectMapper objectMapper;

    @SimpleAroundLog
    @ServiceActivator
    @HystrixCommand(commandKey = "mc-provision-command", threadPoolKey = "mc-provision-thread-pool", ignoreExceptions = FdcRuntimeException.class)
    public GetTokenResponse getToken(@Header(Constants.PARTNER_ID) final String pMerchantId,
                                     @Header(Constants.TOKEN_REFERENCE_ID) final String tokenReferenceId,
                                     @Header(Constants.TSP_ID) String tspId,
                                     @Header(Constants.TOKEN_TYPE) String tokenType,
                                     @Header(Constants.CLIENT_REQUEST_ID) String clientRequestId) throws FdcSystemException, FdcException, JsonProcessingException {

        logger.debug("Request received @ getToken API for merchant Partner {} and request {} ", pMerchantId);

        return null;
    }


    public HttpHeaders getHttpHeaders(String clientRequestId) {
        final HttpHeaders headers = new HttpHeaders();
        headers.set(Constants.ACCCEPT, Constants.CONTENT_TYPE_JSON);
        headers.set(Constants.CONTENT_TYPE, Constants.APPLICATION_JSON);
        headers.set(Constants.CLIENT_REQUEST_ID, clientRequestId);
        return headers;
    }

    public String getUri(String path, String pMerchantId, String tokenReferenceId) {
        final StringBuilder sb = new StringBuilder(applicationProperties.getMasterCardServiceUrl());
        sb.append(Constants.BASE_URL);
        sb.append(pMerchantId);
        sb.append("/");
        sb.append(path);
        sb.append("/");
        sb.append(tokenReferenceId);
        sb.append("/");
        sb.append(Constants.CRYPTO_GRAMS);
        logger.info("Outbound Url {} ", sb.toString());
        return sb.toString();
    }

}
