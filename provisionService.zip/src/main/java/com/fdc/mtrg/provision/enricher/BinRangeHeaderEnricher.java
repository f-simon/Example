package com.fdc.mtrg.provision.enricher;

import com.fdc.mtrg.api.Provision;
import com.fdc.mtrg.api.ProvisionTokenRequest;
import com.fdc.mtrg.provision.error.ApplicationError;
import com.fdc.mtrg.provision.util.Constants;
import com.fdc.util.exception.FdcException;
import com.fdc.util.exception.types.FdcSystemException;
import com.fdc.util.logging.SimpleAroundLog;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.stereotype.Component;
import org.springframework.validation.FieldError;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.util.ArrayList;
import java.util.List;

@Component
public class BinRangeHeaderEnricher {

    private static final Logger logger = LoggerFactory.getLogger(BinRangeHeaderEnricher.class);


    @SimpleAroundLog
    public String identifyBin(@Header(Constants.PARTNER_ID) final String pMerchantId,
                              @Header(Constants.CLIENT_REQUEST_ID) String clientRequestId,
                              ProvisionTokenRequest pRequestMessage) throws FdcSystemException, FdcException {

        logger.debug("Request received @ identifyBin API for merchant Partner {}", pMerchantId);

        @NotNull @Valid Provision provision = pRequestMessage.getProvision();

        //TODO: this logic is not good. Do Bin range validation

        if (provision.getCard().getCardNumber().startsWith("5") || provision.getCard().getCardNumber().startsWith("2")) {
            return Constants.MASTERCARD;
        } else if (provision.getCard().getCardNumber().startsWith("4")) {
            return Constants.VISA;
        } else if (provision.getCard().getCardNumber().startsWith("6")) {
            return Constants.DISCOVER;
        } else if (provision.getCard().getCardNumber().startsWith("3")) {
            return Constants.AMEX;
        } else {
            List<FieldError> fieldErrors = new ArrayList<>();
            fieldErrors.add(new FieldError("Bin Range Validation", "Bin not in Range", "Invalid validation failed."));
            throw new FdcException(ApplicationError.INVALID_REQUEST.getErrorCode(), ApplicationError.INVALID_REQUEST.getErrorDescription(), fieldErrors);
        }
    }
}