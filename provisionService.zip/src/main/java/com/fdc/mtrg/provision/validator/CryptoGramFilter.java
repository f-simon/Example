package com.fdc.mtrg.provision.validator;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fdc.mtrg.api.CryptoGramRequest;
import com.fdc.mtrg.provision.error.ApplicationError;
import com.fdc.mtrg.provision.util.Constants;
import com.fdc.util.exception.FdcException;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.integration.annotation.Filter;
import org.springframework.messaging.Message;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.stereotype.Service;
import org.springframework.validation.FieldError;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Service
public class CryptoGramFilter {

    private static final Logger logger = LoggerFactory.getLogger(ProvisionTokenFilter.class);

    @Autowired
    private ObjectMapper objectMapper;

    @Filter
    public boolean doValidateRequest(@Header(Constants.PARTNER_ID) final String merchantId,
                                     @Header(Constants.TOKEN_REFERENCE_ID) final String tokenReferenceId,
                                     @Header(Constants.CLIENT_REQUEST_ID) String clientRequestId,
                                     Message<CryptoGramRequest> pRequestMessage) throws FdcException {

        List<FieldError> fieldErrors = new ArrayList<>();

        CryptoGramRequest payload = pRequestMessage.getPayload();

        if (null == payload.getTspId()) {
            fieldErrors.add(new FieldError("Invalid attribute : TSP Id ", "TspId", "Invalid attribute : TspId" ));

            throw new FdcException(ApplicationError.INVALID_REQUEST.getErrorCode(), ApplicationError.INVALID_REQUEST.getErrorDescription(), fieldErrors, ApplicationError.INVALID_REQUEST.getCategory(), null);
        }

        List<String> acceptableTspIds = new ArrayList<>(Arrays.asList("501", "401"));

        if(!acceptableTspIds.contains(payload.getTspId())){
            fieldErrors.add(new FieldError(CryptoGramRequest.class.getName(), Constants.INVALID_TSP_ID, Constants.INVALID_TSP_ID));
            throw new FdcException(ApplicationError.INVALID_REQUEST.getErrorCode(), ApplicationError.INVALID_REQUEST.getErrorDescription(), fieldErrors, ApplicationError.INVALID_REQUEST.getCategory(), null);
        }

        if (StringUtils.isBlank(tokenReferenceId)) {
            fieldErrors.add(new FieldError("Invalid attribute : TokenReferenceId ", "TokenReferenceId", "Invalid attribute : " + tokenReferenceId));

            throw new FdcException(ApplicationError.INVALID_REQUEST.getErrorCode(), ApplicationError.INVALID_REQUEST.getErrorDescription(), fieldErrors, ApplicationError.INVALID_REQUEST.getCategory(), null);
        }

        if (null == payload){
            fieldErrors.add(new FieldError(CryptoGramRequest.class.getName(), Constants.TRANSACT_REQUEST_PAYLOAD, Constants.NULL_PAYLOAD));

            throw new FdcException(ApplicationError.INVALID_REQUEST.getErrorCode(), ApplicationError.INVALID_REQUEST.getErrorDescription(), fieldErrors, ApplicationError.INVALID_REQUEST.getCategory(), null);
        }

        if ((null == payload.getTransactionType()) || StringUtils.isBlank(payload.getTransactionType().getValue())){
            fieldErrors.add(new FieldError(CryptoGramRequest.class.getName(), Constants.TRANSACT_TYPE, Constants.ERROR_FORMAT));

            throw new FdcException(ApplicationError.INVALID_REQUEST.getErrorCode(), ApplicationError.INVALID_REQUEST.getErrorDescription(), fieldErrors, ApplicationError.INVALID_REQUEST.getCategory(), null);
        }

        return true;
    }
}
