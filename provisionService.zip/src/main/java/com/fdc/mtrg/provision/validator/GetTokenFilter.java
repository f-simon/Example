package com.fdc.mtrg.provision.validator;

import com.fdc.mtrg.provision.error.ApplicationError;
import com.fdc.mtrg.provision.util.Constants;
import com.fdc.util.exception.FdcException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.integration.annotation.Filter;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.stereotype.Service;
import org.springframework.validation.FieldError;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

@Service
public class GetTokenFilter {

    private static final Logger logger = LoggerFactory.getLogger(GetTokenFilter.class);
    @Filter
    public boolean doValidateRequest(@Header(Constants.PARTNER_ID) final String merchantId,
                                     @Header(Constants.TOKEN_REFERENCE_ID) final String tokenReferenceId,
                                     @Header(Constants.TSP_ID) String tspId,
                                     @Header(Constants.TOKEN_TYPE) String tokenType,
                                     @Header(Constants.CLIENT_REQUEST_ID) String clientRequestId) throws FdcException {

        logger.debug("Request received @ doValidateRequest API for merchant Partner {} and tokenReferenceId {} ", merchantId, tokenReferenceId);

        Optional<String> mId = Optional.ofNullable(merchantId);
        Optional<String> tuf = Optional.ofNullable(tokenReferenceId);
        Optional<String> tspIdx = Optional.ofNullable(tspId);
        Optional<String> tokType = Optional.ofNullable(tokenType);
        Optional<String> clntRequestId = Optional.ofNullable(clientRequestId);

        List<FieldError> fieldErrors = new ArrayList<>();
        List<String> validTspIds = Arrays.asList("501", "400");

        if (!mId.isPresent()){
            fieldErrors.add(new FieldError("Invalid attribute : ", "merchantId", "Invalid merchantId"));

        }

        if(!tuf.isPresent()){
            fieldErrors.add(new FieldError("Invalid attribute : ", "tokenReferenceId", "Invalid tokenReferenceId"));
        }

        if(!tspIdx.isPresent()){
            fieldErrors.add(new FieldError("Invalid attribute : ", "tspId", "Invalid tspId"));
        } else {
            if (!validTspIds.contains(tspIdx.get())) {
                fieldErrors.add(new FieldError("Invalid attribute : ", "tspId", "Invalid tspId"));
            }
        }

        if(!tokType.isPresent()){
            fieldErrors.add(new FieldError("Invalid attribute : ", "tokType", "Invalid tokType"));
        }else{
            if(! tokType.get().equalsIgnoreCase("TSP")){
                fieldErrors.add(new FieldError("Invalid attribute : ", "tokType", "Invalid tokType"));
            }
        }

        if(!clntRequestId.isPresent()){
            fieldErrors.add(new FieldError("Invalid attribute : ", "clientRequestId", "Invalid clientRequestId"));
        }

        if (!fieldErrors.isEmpty() && fieldErrors.size() > 0) {
            throw new FdcException(ApplicationError.INVALID_REQUEST.getErrorCode(), ApplicationError.INVALID_REQUEST.getErrorDescription(),
                    fieldErrors);
        }

        return true;
    }
}
