package com.fdc.mtrg.provision.service;

import com.fdc.mtrg.api.ProvisionTokenRequest;
import com.fdc.mtrg.api.ProvisionTokenResponse;
import com.fdc.mtrg.provision.util.Constants;
import com.fdc.util.exception.FdcException;
import com.fdc.util.exception.types.FdcSystemException;
import com.fdc.util.logging.SimpleAroundLog;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.integration.annotation.ServiceActivator;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.stereotype.Service;


@Service
public class VisaProvisionService {

    private static final Logger logger = LoggerFactory.getLogger(VisaProvisionService.class);


    @SimpleAroundLog
    @ServiceActivator
    public ProvisionTokenResponse tokenize(@Header(Constants.PARTNER_ID) final String pMerchantId,
                                           @Header(Constants.SEARCH) boolean search,
                                           @Header(Constants.CLIENT_REQUEST_ID) String clientRequestId,
                                           ProvisionTokenRequest pRequestMessage) throws FdcSystemException, FdcException {

        logger.debug("Request received @ tokenize API for merchant Partner {}", pMerchantId);

        ProvisionTokenResponse provisionTokenResponse = new ProvisionTokenResponse();

        return provisionTokenResponse;
    }
}
