package com.fdc.mtrg.provision.error;

public interface FdcServiceError {
    String getStatusCode();

    String getErrorCode();

    String getErrorDescription();

    String getCategory();

    String getDeveloperMessage();

    String getMoreInfo();
}