package com.fdc.mtrg.provision.gateway;

import com.fdc.mtrg.api.*;
import com.fdc.mtrg.provision.util.Constants;
import org.springframework.http.HttpStatus;
import org.springframework.messaging.Message;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.messaging.handler.annotation.Payload;

public interface ApplicationGateway {

    ProvisionTokenResponse tokenize(@Header(Constants.PARTNER_ID) final String merchantId,
                                    @Header(Constants.SEARCH) boolean search,
                                    @Header(Constants.CLIENT_REQUEST_ID) String clientRequestId,
                                    Message<ProvisionTokenRequest> pRequestMessage);

    CryptoGramResponse transact(@Header(Constants.PARTNER_ID) final String merchantId,
                                @Header(Constants.TOKEN_REFERENCE_ID) final String tokenReferenceId,
                                @Header(Constants.CLIENT_REQUEST_ID) String clientRequestId,
                                Message<CryptoGramRequest> pRequestMessage);

    HttpStatus doLifeCycle(@Header(Constants.PARTNER_ID) final String merchantId,
                           @Header(Constants.TOKEN_REFERENCE_ID) final String tokenReferenceId,
                           @Header(Constants.CLIENT_REQUEST_ID) final String clientRequestId,
                           Message<UpdateTokenRequest> lifeCycleMessage);

    @Payload("''")
    GetAssetResponse getCardMetadata(@Header(Constants.PARTNER_ID) final String merchantId,
                                     @Header(Constants.ASSET_ID) final String assetId,
                                     @Header(Constants.TSP_ID) final String tspId,
                                     @Header(Constants.CLIENT_REQUEST_ID) final String clientRequestId);

    @Payload("''")
    ProvisionTokenResponse getToken(@Header(Constants.PARTNER_ID) final String merchantId,
                                    @Header(Constants.TOKEN_REFERENCE_ID) final String tokenReferenceId,
                                    @Header(Constants.TSP_ID) String tspId,
                                    @Header(Constants.TOKEN_TYPE) String tokenType,
                                    @Header(Constants.CLIENT_REQUEST_ID) String clientRequestId);
}
