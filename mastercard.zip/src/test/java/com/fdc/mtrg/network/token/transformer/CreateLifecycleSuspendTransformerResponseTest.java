package com.fdc.mtrg.network.token.transformer;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fdc.mtrg.api.*;
import com.fdc.mtrg.network.token.ms.SuspendRequestSchema;
import com.fdc.mtrg.network.token.ms.SuspendResponseSchema;
import com.fdc.mtrg.network.token.ms.TokenForLCM;
import com.fdc.mtrg.network.token.transformer.CreateLifecycleSuspendTransformer;
import com.fdc.mtrg.network.token.util.Constants;
import com.fdc.util.exception.FdcException;
import com.fdc.util.exception.types.FdcSystemException;
import com.mastercard.developer.encryption.EncryptionException;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@RunWith(MockitoJUnitRunner.class)
public class CreateLifecycleSuspendTransformerResponseTest {

    @Rule
    public ExpectedException expectedException = ExpectedException.none();

    @InjectMocks
    private CreateLifecycleSuspendTransformer lifecycleSuspendTransformer;

    @Mock
    private ObjectMapper objectMapper;

    private SuspendResponseSchema suspendResponseSchema = new SuspendResponseSchema();

    @Before
    public void setUp() {
    }

    @Test()
    public void testDoTransformResponse_ThenReturn_HttpStatus204() throws JsonProcessingException, FdcException {
        List<TokenForLCM> tokenForLCMS = new ArrayList<>();
        TokenForLCM token = new TokenForLCM();
        token.status(Constants.SUSPENDED);
        tokenForLCMS.add(token);
        suspendResponseSchema.setTokens(tokenForLCMS);
        HttpStatus  httpStatus= lifecycleSuspendTransformer.doTransformResposne("test", suspendResponseSchema);
        Assert.assertEquals("Should be equal ", HttpStatus.NO_CONTENT, httpStatus);
    }

    @Test(expected = FdcException.class)
    public void testDoTransformResponse_ThenReturn_Throw_FdcException() throws JsonProcessingException, FdcException {
        List<TokenForLCM> tokenForLCMS = new ArrayList<>();
        TokenForLCM token = new TokenForLCM();
        token.status(Constants.DEACTIVATED);
        tokenForLCMS.add(token);
        suspendResponseSchema.setTokens(tokenForLCMS);
        lifecycleSuspendTransformer.doTransformResposne("test", suspendResponseSchema);
    }

    @Test(expected = FdcSystemException.class)
    public void testDoTransformResponse_ThenReturn_Throw_FdcSystemException() throws JsonProcessingException, FdcException {
        List<TokenForLCM> tokenForLCMS = new ArrayList<>();
        suspendResponseSchema.setTokens(tokenForLCMS);
        lifecycleSuspendTransformer.doTransformResposne("test", suspendResponseSchema);
    }

}
