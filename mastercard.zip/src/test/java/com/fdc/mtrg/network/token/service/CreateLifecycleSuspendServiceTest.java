package com.fdc.mtrg.network.token.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fdc.mtrg.network.token.config.ApplicationProperties;
import com.fdc.mtrg.network.token.error.ApplicationError;
import com.fdc.mtrg.network.token.ms.SuspendRequestSchema;
import com.fdc.mtrg.network.token.ms.SuspendResponseSchema;
import com.fdc.mtrg.network.token.ms.TokenForLCM;
import com.fdc.util.exception.FdcException;
import com.fdc.util.exception.types.FdcSystemException;
import com.mastercard.developer.encryption.EncryptionException;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static com.fdc.mtrg.network.token.utils.TestUtils.ROOT_URL;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;


@RunWith(MockitoJUnitRunner.class)
public class CreateLifecycleSuspendServiceTest {

    @Rule
    public ExpectedException expectedException = ExpectedException.none();

    @InjectMocks
    private CreateLifecycleSuspendService lifecycleSuspendService = new CreateLifecycleSuspendService();

    @Mock
    private ObjectMapper objectMapper;

    @Mock
    private ApplicationProperties applicationProperties;

    @Mock
    private RestTemplate restTemplate;

    @Mock
    private SuspendRequestSchema suspendRequestSchema;

    @Mock
    private SuspendResponseSchema suspendResponseSchema;

    @Before
    public void setUp() {
        when(applicationProperties.getServiceUrl()).thenReturn(ROOT_URL);

    }

    @Test
    public void testDoOutboundServiceCall_ThenReturnSuspendResponseSchema() throws FdcSystemException, FdcException {

        doReturn(new ResponseEntity<>(suspendResponseSchema, HttpStatus.OK)).when(restTemplate)
                .exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(Class.class));

        suspendResponseSchema = lifecycleSuspendService.doOutboundServiceCall("test", suspendRequestSchema);

        Assert.assertNotNull(suspendResponseSchema);
    }

    @Test
    public void testDoOutboundServiceCall_Then_Throw_RestClientException() throws FdcSystemException, FdcException {
        doThrow(RestClientException.class).when(restTemplate)
                .exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(Class.class));

        expectedException.expect(FdcSystemException.class);
        expectedException.expectMessage(ApplicationError.SERVICE_UNAVAILABLE.getErrorDescription());

        lifecycleSuspendService.doOutboundServiceCall("test", suspendRequestSchema);
    }

    private void setData() {
        suspendRequestSchema = new SuspendRequestSchema();
        suspendRequestSchema.setRequestId("17417fb2-704f-4ac7-a559-3de0d7c95ea8");
        suspendRequestSchema.setPaymentAppInstanceId("123456789");
        suspendRequestSchema.setCausedBy("CARDHOLDER");
        suspendRequestSchema.setReason("Lost/stolen device");
        suspendRequestSchema.setReasonCode("DEVICE_LOST");

        List<String> tokenReferenceIds = new ArrayList<>
                (Arrays.asList("DWSPMC000000000132d72d4fcb2f4136a0532d3093ff1a45"));

        suspendRequestSchema.setTokenUniqueReferences(tokenReferenceIds);

        //
        suspendResponseSchema = new SuspendResponseSchema();
        suspendResponseSchema.setResponseId("17417fb2-704f-4ac7-a559-3de0d7c95ea8");

        TokenForLCM tokenForLCM = new TokenForLCM();
        List<TokenForLCM> tokens = new ArrayList<>();

        tokenForLCM.setTokenUniqueReference("DWSPMC000000000132d72d4fcb2f4136a0532d3093ff1a45");

        tokenForLCM.setStatus("SUSPENDED");

        List<String> suspendedBy = new ArrayList<>(Arrays.asList("ISSUER", "TOKEN_REQUESTOR"));

        tokenForLCM.setSuspendedBy(suspendedBy);
        tokens.add(tokenForLCM);

        TokenForLCM tokenForLCM1 = new TokenForLCM();
        tokenForLCM1.setTokenUniqueReference("DWSPMC000000000132d72d4fcb2f4136a0532d3093ff1a47");
        tokenForLCM1.setStatus("SUSPENDED");

        List<String> suspendedBy1 = new ArrayList<>(Arrays.asList("ISSUER", "CARDHOLDER"));

        tokenForLCM1.setSuspendedBy(suspendedBy1);
        tokens.add(tokenForLCM1);

        suspendResponseSchema.setTokens(tokens);
    }
}
