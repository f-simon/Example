package com.fdc.mtrg.network.token.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fdc.mtrg.network.token.config.ApplicationProperties;
import com.fdc.mtrg.network.token.error.ApplicationError;
import com.fdc.mtrg.network.token.ms.DeleteRequestSchema;
import com.fdc.mtrg.network.token.ms.DeleteResponseSchema;
import com.fdc.mtrg.network.token.ms.SuspendResponseSchema;
import com.fdc.mtrg.network.token.ms.TokenForLCM;
import com.fdc.util.exception.FdcException;
import com.fdc.util.exception.types.FdcSystemException;
import com.mastercard.developer.encryption.EncryptionException;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static com.fdc.mtrg.network.token.utils.TestUtils.ROOT_URL;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class CreateLifecycleDeleteServiceTest {

    @Rule
    public ExpectedException expectedException = ExpectedException.none();

    @InjectMocks
    private CreateLifecycleDeleteService lifecycleDeleteService = new CreateLifecycleDeleteService();

    @Mock
    private ObjectMapper objectMapper;

    @Mock
    private ApplicationProperties applicationProperties;

    @Mock
    private RestTemplate restTemplate;

    @Mock
    private DeleteRequestSchema deleteRequestSchema;

    @Mock
    private DeleteResponseSchema deleteResponseSchema;

    @Before
    public void setUp() {
        when(applicationProperties.getServiceUrl()).thenReturn(ROOT_URL);
        setData();
    }


    @Test
    public void testDoOutboundServiceCall_ThenReturnSuspendResponseSchema() throws EncryptionException, FdcSystemException, FdcException {

        doReturn(new ResponseEntity<>(deleteResponseSchema, HttpStatus.OK)).when(restTemplate)
                .exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(Class.class));

        deleteResponseSchema = lifecycleDeleteService.doOutboundServiceCall("test", deleteRequestSchema);
        Assert.assertNotNull(deleteResponseSchema);
    }

    @Test
    public void testDoOutboundServiceCall_Then_Throw_RestClientException() throws FdcSystemException, FdcException {
        doThrow(RestClientException.class).when(restTemplate)
                .exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(Class.class));

        expectedException.expect(FdcSystemException.class);
        expectedException.expectMessage(ApplicationError.SERVICE_UNAVAILABLE.getErrorDescription());

        lifecycleDeleteService.doOutboundServiceCall("test", deleteRequestSchema);
    }

    private void setData() {
        deleteRequestSchema = new DeleteRequestSchema();
        deleteRequestSchema.setRequestId("17417fb2-704f-4ac7-a559-3de0d7c95ea8");
        deleteRequestSchema.setPaymentAppInstanceId("123456789");
        deleteRequestSchema.setCausedBy("TOKEN_REQUESTOR");
        deleteRequestSchema.setReason("Lost/stolen device");
        deleteRequestSchema.setReasonCode("SUSPECTED_FRAUD");

        List<String> tokenReferenceIds = new ArrayList<>
                (Arrays.asList("DWSPMC000000000132d72d4fcb2f4136a0532d3093ff1a45", "DWSPMC000000000132d72d4fcb2f4136a0532d3093ff1a47"));

        deleteRequestSchema.setTokenUniqueReferences(tokenReferenceIds);

        //
        deleteResponseSchema = new DeleteResponseSchema();

        deleteResponseSchema.setResponseId("17417fb2-704f-4ac7-a559-3de0d7c95ea8");

        TokenForLCM tokenForLCM = new TokenForLCM();
        List<TokenForLCM> tokens = new ArrayList<>();

        tokenForLCM.setTokenUniqueReference("DWSPMC000000000132d72d4fcb2f4136a0532d3093ff1a45");

        tokenForLCM.setStatus("SUSPENDED");

        List<String> suspendedBy = new ArrayList<>(Arrays.asList("ISSUER", "TOKEN_REQUESTOR"));

        tokenForLCM.setSuspendedBy(suspendedBy);
        tokens.add(tokenForLCM);

        TokenForLCM tokenForLCM1 = new TokenForLCM();
        tokenForLCM1.setTokenUniqueReference("DWSPMC000000000132d72d4fcb2f4136a0532d3093ff1a47");
        tokenForLCM1.setStatus("SUSPENDED");

        List<String> suspendedBy1 = new ArrayList<>(Arrays.asList("ISSUER", "CARDHOLDER"));

        tokenForLCM1.setSuspendedBy(suspendedBy1);
        tokens.add(tokenForLCM1);

        deleteResponseSchema.setTokens(tokens);
    }
}
