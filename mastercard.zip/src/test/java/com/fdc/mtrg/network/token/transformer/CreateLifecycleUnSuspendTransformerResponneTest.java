package com.fdc.mtrg.network.token.transformer;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fdc.mtrg.network.token.ms.SuspendResponseSchema;
import com.fdc.mtrg.network.token.ms.TokenForLCM;
import com.fdc.mtrg.network.token.ms.UnSuspendResponseSchema;
import com.fdc.mtrg.network.token.util.Constants;
import com.fdc.util.exception.FdcException;
import com.fdc.util.exception.types.FdcSystemException;
import com.mastercard.developer.encryption.EncryptionException;
import org.hamcrest.Matchers;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.doReturn;

@RunWith(MockitoJUnitRunner.class)
public class CreateLifecycleUnSuspendTransformerResponneTest {

    @Rule
    public ExpectedException expectedException = ExpectedException.none();

    @InjectMocks
    private CreateLifecycleUnSuspendTransformer lifecycleUnSuspendTransformer;

    @Mock
    private ObjectMapper objectMapper;

    private UnSuspendResponseSchema unSuspendResponseSchema = new UnSuspendResponseSchema();

    @Before
    public void setUp() {
    }

    @Test()
    public void testDoTransformResponse_ThenReturnUpdateTokenResponse() throws JsonProcessingException, FdcException {
        List<TokenForLCM> tokenForLCMS = new ArrayList<>();
        TokenForLCM token = new TokenForLCM();
        token.status(Constants.ACTIVE);
        tokenForLCMS.add(token);
        unSuspendResponseSchema.setTokens(tokenForLCMS);
        HttpStatus httpStatus = lifecycleUnSuspendTransformer.doTransformResposne("test", unSuspendResponseSchema);
        Assert.assertEquals("Should be equal ", HttpStatus.NO_CONTENT, httpStatus);
    }

    @Test(expected = FdcException.class)
    public void testDoTransformResponse_ThenReturn_Throw_FdcException() throws JsonProcessingException, FdcException {
        List<TokenForLCM> tokenForLCMS = new ArrayList<>();
        TokenForLCM token = new TokenForLCM();
        token.status(Constants.DEACTIVATED);
        tokenForLCMS.add(token);
        unSuspendResponseSchema.setTokens(tokenForLCMS);
        lifecycleUnSuspendTransformer.doTransformResposne("test", unSuspendResponseSchema);
    }

    @Test(expected = FdcSystemException.class)
    public void testDoTransformResponse_ThenReturn_Throw_FdcSystemException() throws JsonProcessingException, FdcException {
        List<TokenForLCM> tokenForLCMS = new ArrayList<>();
        unSuspendResponseSchema.setTokens(tokenForLCMS);
        lifecycleUnSuspendTransformer.doTransformResposne("test", unSuspendResponseSchema);
    }


}