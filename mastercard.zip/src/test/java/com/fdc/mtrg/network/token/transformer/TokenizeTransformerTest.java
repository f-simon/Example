package com.fdc.mtrg.network.token.transformer;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fdc.mtrg.api.*;
import com.fdc.mtrg.network.token.entity.MerchantTridMapping;
import com.fdc.mtrg.network.token.ms.*;
import com.fdc.mtrg.network.token.repository.MerchantTridRepository;
import com.fdc.util.exception.FdcException;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.cache.CacheManager;
import org.springframework.messaging.Message;

import java.util.ArrayList;
import java.util.List;

import static com.fdc.mtrg.network.token.utils.TestUtils.*;
import static org.junit.Assert.*;
import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class TokenizeTransformerTest {
    @Rule
    public ExpectedException expectedException = ExpectedException.none();

    @Mock
    private ObjectMapper objectMapper;

    @Mock
    Message<ProvisionTokenRequest> pRequestMessage;

    @InjectMocks
    private TokenizeTransformer tokenizeTransformer;

    private ProvisionTokenRequest provisionTokenRequest;

    @Mock
    private MerchantTridRepository merchantTridRepository;

    @Mock
    private CacheManager cacheManager;

    @Before
    public void before() throws  Exception{
        provisionTokenRequest = getTokenRequest(ProvisionTokenRequest.class);
        when(pRequestMessage.getPayload()).thenReturn(provisionTokenRequest);
        when(objectMapper.writeValueAsString(any())).thenReturn(REQUEST_PAYLOAD);
    }

    @Test
    public void testDoTransformRequest() throws Exception {
        List<MerchantTridMapping> merchantTridMappings = new ArrayList<>();
        MerchantTridMapping merchantTridMapping = new MerchantTridMapping();
        merchantTridMapping.setMerchantId("TEST");
        merchantTridMapping.setTokenRequestorId("123456789");
        merchantTridMappings.add(merchantTridMapping);
        when(merchantTridRepository.findByMerchantIdAndTsp(anyString(), anyString())).thenReturn(merchantTridMappings);
        TokenizeRequest tokenizeRequest = tokenizeTransformer.doTransformRequest(PARTNER_ID, pRequestMessage);

        assertNotNull(tokenizeRequest);
        //assertNotNull(tokenizeRequest.getRequestId());
        assertNotNull(tokenizeRequest.getTaskId());

        FundingAccountInfo fundingAccountInfo = tokenizeRequest.getFundingAccountInfo();
        assertNotNull(fundingAccountInfo);

        EncryptedPayload encryptedPayload = fundingAccountInfo.getEncryptedPayload();
        assertNotNull(encryptedPayload);
        //data are not encrypted thus:
        assertNull(encryptedPayload.getEncryptedKey());
        assertNull(encryptedPayload.getIv());

        EncryptedData encryptedData = encryptedPayload.getEncryptedData();
        assertNotNull(encryptedData);

        CardAccountData cardAccountData = encryptedData.getCardAccountData();
        assertNotNull(cardAccountData);
        assertEquals(provisionTokenRequest.getProvision().getCard().getCardNumber(), cardAccountData.getAccountNumber());

        AccountHolderData accountHolderData = encryptedData.getAccountHolderData();
        assertNotNull(accountHolderData);
        assertEquals(provisionTokenRequest.getProvision().getCard().getNameOnCard(), accountHolderData.getAccountHolderName());

        AccountHolderAddress accountHolderAddress = accountHolderData.getAccountHolderAddress();
        assertNotNull(accountHolderAddress);
        assertEquals(provisionTokenRequest.getProvision().getCard().getBillingAddress().getStreetAddress(), accountHolderAddress.getLine1());

        AccountHolderMobilePhoneNumber accountHolderMobilePhoneNumber = accountHolderData.getAccountHolderMobilePhoneNumber();
        assertNotNull(accountHolderMobilePhoneNumber);

        DecisioningData decisioningData = tokenizeRequest.getDecisioningData();
        DeviceDetails device = pRequestMessage.getPayload().getProvision().getDeviceDetails();
        assertNotNull(decisioningData);
        assertEquals(device.getAccountScore(), decisioningData.getAccountScore());
        assertEquals(device.getAccountScore(), decisioningData.getDeviceScore());
        assertEquals("01", decisioningData.getRecommendationAlgorithmVersion());
    }

    @Test
    public void testDoTransformRequest_JsonProcessingException() throws Exception {
        when(objectMapper.writeValueAsString(any())).thenThrow(JsonProcessingException.class);
        expectedException.expect(FdcException.class);

        tokenizeTransformer.doTransformRequest(PARTNER_ID, pRequestMessage);
    }

    @Test
    public void testDoTransformResponse() throws Exception {
        TokenizeResponse tokenizeResponse = getTokenResponse(TokenizeResponse.class);
        ProvisionTokenResponse provisionTokenResponse = tokenizeTransformer.doTransformResponse(PARTNER_ID, tokenizeResponse);

        assertNotNull(provisionTokenResponse);

        Provision provision = provisionTokenResponse.getProvision();
        assertNotNull(provision);

        TokenInfo tokenInfo = provision.getTokenInfo();
        assertNotNull(tokenInfo);
        assertEquals(TokenStatus.APPROVED, tokenInfo.getDecision());
        assertEquals(tokenizeResponse.getTokenDetail().getEncryptedData().getPaymentAccountReference(), tokenInfo.getToken().getPaymentAccountReferenceId());
    }

    @Test
    public void testDoTransformResponse_JsonProcessingException() throws Exception {
        when(objectMapper.writeValueAsString(any())).thenThrow(JsonProcessingException.class);
        expectedException.expect(FdcException.class);

        tokenizeTransformer.doTransformResponse(PARTNER_ID, getTokenResponse(TokenizeResponse.class));
    }
}
