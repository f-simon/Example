package com.fdc.mtrg.network.token.service;

import com.fdc.mtrg.api.CryptoGramRequest;
import com.fdc.mtrg.network.token.config.ApplicationProperties;
import com.fdc.mtrg.network.token.error.ApplicationError;
import com.fdc.mtrg.network.token.ms.TransactRequest;
import com.fdc.mtrg.network.token.ms.TransactResponse;

import com.fdc.mtrg.network.token.ms.error.Errors;
import com.fdc.mtrg.network.token.transformer.TransactTransformer;

import com.fdc.util.exception.FdcException;
import com.fdc.util.exception.types.FdcSystemException;
import com.mastercard.developer.encryption.EncryptionException;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.mockito.ArgumentMatchers;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.messaging.Message;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static com.fdc.mtrg.network.token.utils.TestUtils.*;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class TransactServiceTest {

    @InjectMocks
    private TransactService transactService = new TransactService();

    @Rule
    public ExpectedException expectedException = ExpectedException.none();

    @Mock
    private ObjectMapper objectMapper;

    private TransactTransformer transactTransformer;

    private TransactRequest transactRequest;

    @Mock
    private TransactResponse transactResponse;

    @Mock
    private RestTemplate restTemplate;

    @Mock
    private ResponseEntity<String> responseEntity;

    @Mock
    private ApplicationProperties applicationProperties;

    @Mock
    Message<CryptoGramRequest> pCryptoGramRequest;

    @Before
    public void before() throws  Exception{
        transactTransformer = new TransactTransformer();
        CryptoGramRequest cryptoRequest = getTransactRequest(CryptoGramRequest.class);

        when(pCryptoGramRequest.getPayload()).thenReturn(cryptoRequest);

        transactRequest = transactTransformer.doTransformRequest(PARTNER_ID, "Test", pCryptoGramRequest);
    }

    @Test
    public void doOutboundServiceCallTest() throws Exception{
        when(applicationProperties.getServiceUrl()).thenReturn(ROOT_URL);
        when(responseEntity.getBody()).thenReturn(TRANSACT_RESPONSE_PAYLOAD);
        TransactService spyTransactService = spy(transactService);

        when(restTemplate.exchange(ArgumentMatchers.anyString(),
                ArgumentMatchers.any(HttpMethod.class),
                ArgumentMatchers.any(),
                ArgumentMatchers.<Class<String>>any())).thenReturn(responseEntity);

        doReturn(transactResponse).when(spyTransactService).decrypt(anyString(), any());
        spyTransactService.doOutboundServiceCall(anyString(), eq(transactRequest));

        verify(restTemplate).exchange(ArgumentMatchers.anyString(),
                ArgumentMatchers.any(HttpMethod.class),
                ArgumentMatchers.any(),
                ArgumentMatchers.<Class<String>>any());

        verify(spyTransactService).decrypt(anyString(), any());
    }

    @Test
    public void testTransact_MDES_Errors() throws Exception{
        when(applicationProperties.getServiceUrl()).thenReturn(ROOT_URL);
        when(responseEntity.getBody()).thenReturn(TRANSACT_RESPONSE_PAYLOAD);
        TransactService spyTransactService = spy(transactService);

        TransactResponse testResponse = new TransactResponse();
        testResponse.setErrorCode("ErrorTest");

        List<Errors> testErrors = new ArrayList<Errors>();
        Errors singleTestError = new Errors();
        singleTestError.setDescription("errorDescriptiontest");
        singleTestError.setReasonCode("errorCodeTest");
        testErrors.add(singleTestError);

        testResponse.setErrors(testErrors);

        TransactResponse spyResponse = spy(testResponse);

        when(restTemplate.exchange(ArgumentMatchers.anyString(),
                ArgumentMatchers.any(HttpMethod.class),
                ArgumentMatchers.any(),
                ArgumentMatchers.<Class<String>>any())).thenReturn(responseEntity);

        doReturn(spyResponse).when(spyTransactService).decrypt(anyString(), any());

        expectedException.expect(FdcException.class);
        expectedException.expectMessage(ApplicationError.INVALID_REQUEST.getErrorDescription());

        spyTransactService.doOutboundServiceCall(anyString(), eq(transactRequest));
    }

    @Test
    public void testTransact_RestClientException() throws Exception {
        when(applicationProperties.getServiceUrl()).thenReturn(ROOT_URL);
        when(restTemplate.exchange(ArgumentMatchers.anyString(),
                ArgumentMatchers.any(HttpMethod.class),
                ArgumentMatchers.any(),
                ArgumentMatchers.<Class<String>>any())).thenThrow(RestClientException.class);
        expectedException.expect(FdcSystemException.class);
        expectedException.expectMessage(ApplicationError.SERVICE_UNAVAILABLE.getErrorDescription());

        transactService.doOutboundServiceCall(PARTNER_ID, transactRequest);
    }

    @Test
    public void testTransact_ServiceUnavailable() throws Exception{
        when(applicationProperties.getServiceUrl()).thenReturn(ROOT_URL);
        when(responseEntity.getBody()).thenReturn(TRANSACT_RESPONSE_PAYLOAD);
        TransactService spyTransactService = spy(transactService);
        when(restTemplate.exchange(ArgumentMatchers.anyString(),
                ArgumentMatchers.any(HttpMethod.class),
                ArgumentMatchers.any(),
                ArgumentMatchers.<Class<String>>any())).thenReturn(responseEntity);

        doReturn(null).when(spyTransactService).decrypt(anyString(), any());

        expectedException.expect(FdcSystemException.class);
        expectedException.expectMessage(ApplicationError.SERVICE_UNAVAILABLE.getErrorDescription());
        spyTransactService.doOutboundServiceCall(PARTNER_ID, transactRequest);
    }

    @Test
    public void testTransact_EncryptionException() throws Exception {
        when(applicationProperties.getServiceUrl()).thenReturn(ROOT_URL);
        when(responseEntity.getBody()).thenReturn(TRANSACT_RESPONSE_PAYLOAD);
        TransactService spyTransactService = spy(transactService);
        when(restTemplate.exchange(ArgumentMatchers.anyString(),
                ArgumentMatchers.any(HttpMethod.class),
                ArgumentMatchers.any(),
                ArgumentMatchers.<Class<String>>any())).thenReturn(responseEntity);
        doThrow(EncryptionException.class).when(spyTransactService).decrypt(anyString(), any());

        expectedException.expect(FdcException.class);
        expectedException.expectMessage(ApplicationError.TRANSACT_FAILED.getErrorDescription());

        spyTransactService.doOutboundServiceCall(PARTNER_ID, transactRequest);
    }


    @Test
    public void testTransact_IOException() throws Exception {
        when(applicationProperties.getServiceUrl()).thenReturn(ROOT_URL);
        when(responseEntity.getBody()).thenReturn(TRANSACT_RESPONSE_PAYLOAD);
        TransactService spyTransactService = spy(transactService);
        when(restTemplate.exchange(ArgumentMatchers.anyString(),
                ArgumentMatchers.any(HttpMethod.class),
                ArgumentMatchers.any(),
                ArgumentMatchers.<Class<String>>any())).thenReturn(responseEntity);

        doThrow(IOException.class).when(spyTransactService).decrypt(anyString(), any());

        expectedException.expect(FdcException.class);
        expectedException.expectMessage(ApplicationError.IO_EXCEPTION.getErrorDescription());

        spyTransactService.doOutboundServiceCall(PARTNER_ID, transactRequest);
    }
}