package com.fdc.mtrg.network.token.endpoint;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fdc.mtrg.api.ProvisionTokenResponse;
import com.fdc.mtrg.api.SearchTokenResponse;
import com.fdc.mtrg.network.token.gateway.ApplicationGateway;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.Jackson2ObjectMapperBuilder;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import javax.servlet.http.HttpServletRequest;

import static com.fdc.mtrg.network.token.utils.TestUtils.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;
import static org.springframework.boot.test.context.SpringBootTest.WebEnvironment.MOCK;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = MOCK, classes = {ApplicationGateway.class, SearchTokenResponse.class, ProvisionTokenResponse.class, HttpServletRequest.class})
public class ApplicationControllerTest {
    private final static String SEARCH_TOKENS_TRUE = URL_PATH + "?search=true";
    private final static String SEARCH_TOKENS_FALSE = URL_PATH + "?search=false";

    @Rule
    public ExpectedException expectedException = ExpectedException.none();

    @Mock
    private ApplicationGateway applicationGateway;

    @Mock
    private SearchTokenResponse searchTokenResponse;

    @Mock
    private ProvisionTokenResponse provisionTokenResponse;

    @Mock
    private HttpServletRequest httpServletRequest;

    @InjectMocks
    private ApplicationController applicationController;

    private MockMvc mockMvc;

    @Before
    public void before() {
        when(applicationGateway.searchTokens(anyString(), any())).thenReturn(provisionTokenResponse);
        when(applicationGateway.tokenize(anyString(), any())).thenReturn(provisionTokenResponse);
        when(this.httpServletRequest.getMethod()).thenReturn("POST");
        final ObjectMapper objectMapper = new Jackson2ObjectMapperBuilder().build();
        final MappingJackson2HttpMessageConverter mappingJackson2HttpMessageConverter = new MappingJackson2HttpMessageConverter(objectMapper);
        this.mockMvc = MockMvcBuilders.standaloneSetup(applicationController).setMessageConverters(mappingJackson2HttpMessageConverter).build();
    }

    @Test
    @Ignore
    public void testDoTokenization_invoke_tokenize_only() throws Exception {
        when(this.httpServletRequest.getRequestURL()).thenReturn(new StringBuffer(ROOT_URL + SEARCH_TOKENS_FALSE));
        mockMvc.perform(post(SEARCH_TOKENS_FALSE).contentType(MediaType.APPLICATION_JSON)
        .content(REQUEST_PAYLOAD));

        verify(applicationGateway).tokenize(anyString(), any());
        verify(applicationGateway, times(0)).searchTokens(anyString(), any());
    }

    @Test
    @Ignore
    public void testDoTokenization_invoke_search_tokens_only() throws Exception {
        when(this.httpServletRequest.getRequestURL()).thenReturn(new StringBuffer(ROOT_URL + SEARCH_TOKENS_TRUE));
        mockMvc.perform(post(SEARCH_TOKENS_TRUE).contentType(MediaType.APPLICATION_JSON)
                .content(REQUEST_PAYLOAD));

        verify(applicationGateway).searchTokens(anyString(), any());
        verify(applicationGateway, times(0)).tokenize(anyString(), any());
    }
}
