package com.fdc.mtrg.network.token.transformer;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fdc.mtrg.api.*;
import com.fdc.mtrg.api.Token;
import com.fdc.mtrg.network.token.ms.*;
import com.fdc.util.exception.FdcException;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.messaging.Message;

import static com.fdc.mtrg.network.token.utils.TestUtils.*;
import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class TransactTransformerTest {

    private CryptoGramRequest cryptoGramRequest;

    @InjectMocks
    private TransactTransformer transactTransformer;

    @Mock
    private ObjectMapper objectMapper;

    @Mock
    Message<CryptoGramRequest> pRequestMessage;

    @Before
    public void before() throws  Exception{
        cryptoGramRequest = getTransactRequest(CryptoGramRequest.class);
        when(pRequestMessage.getPayload()).thenReturn(cryptoGramRequest);
       // when(objectMapper.writeValueAsString(any())).thenReturn(TRANSACT_REQUEST_PAYLOAD);
    }

    @Test
    public void testDoTransformRequest() throws Exception{
        TransactRequest transactRequest = transactTransformer.doTransformRequest(PARTNER_ID, TOKEN_REFERENCE_ID, pRequestMessage);

        assertNotNull(transactRequest);
        //assertNotNull(transactRequest.getRequestId());
        assertNotNull(transactRequest.getTokenUniqueReference());
        assertNotNull(transactRequest.getDsrpType());
        assertNotNull((transactRequest.getUnpredictableNumber()));
    }

    @Test
    public void testDoTransformResponse() throws Exception {
        TransactResponse transactResponse = getTransactResponse(TransactResponse.class);
        CryptoGramResponse cryptoGramResponse = transactTransformer.doTransformResponse(PARTNER_ID, transactResponse);

        assertNotNull(cryptoGramResponse);

        CryptoGram crypto = cryptoGramResponse.getCrypto();
        assertNotNull(crypto);

        Token tokenInfo = cryptoGramResponse.getToken();

        assertNotNull(tokenInfo);
        assertNotNull(tokenInfo.getPaymentToken());
    }
}