package com.fdc.mtrg.network.token.transformer;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fdc.mtrg.network.token.ms.GetTokenRequestSchema;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class GetTokenTransformerRequestTest {
    @Rule
    public ExpectedException expectedException = ExpectedException.none();

    @InjectMocks
    private GetTokenTransformer getTokenTransformer;

    private GetTokenRequestSchema getTokenRequestSchema;


    @Test
    public void testGetTokenTransFormerRequest_ThenReturn_GetTokenRequestSchema (){
        getTokenRequestSchema = getTokenTransformer.doTransformRequest("test", "DWSDWSPMC000000000132d72d4fcb2f4136a0532d3093ff1a45");

        Assert.assertNotNull(getTokenRequestSchema);
        Assert.assertNotNull(getTokenRequestSchema.getTokenUniqueReference());
    }
}
