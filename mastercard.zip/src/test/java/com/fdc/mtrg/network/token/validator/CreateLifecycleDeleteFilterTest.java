package com.fdc.mtrg.network.token.validator;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fdc.mtrg.api.*;
import com.fdc.util.exception.FdcException;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;

import static org.assertj.core.api.Assertions.assertThat;

@RunWith(MockitoJUnitRunner.class)
public class CreateLifecycleDeleteFilterTest {
    @InjectMocks
    private UpdateTokenRequest updateTokenRequest;

    @Mock
    private ObjectMapper objectMapper;

    @InjectMocks
    private CreateLifecycleDeleteFilter lifecycleDeleteFilter;

    @Before
    public void setUp() {
        setData();
    }

    @Test()
    public void testDoValidateRequest_ThenReturnTrue() throws FdcException, JsonProcessingException {
        Message<UpdateTokenRequest> msg = MessageBuilder.withPayload(updateTokenRequest).build();
        boolean returnValue = lifecycleDeleteFilter.doValidateRequest("test", "test", msg);
        assertThat(returnValue).isTrue();
    }

    @Test(expected = FdcException.class)
    public void testDoValidateRequest_ThenThrowException() throws FdcException, JsonProcessingException {
        Message<UpdateTokenRequest> msg = MessageBuilder.withPayload(new UpdateTokenRequest()).build();
        boolean returnValue = lifecycleDeleteFilter.doValidateRequest("test", "test", msg);
        assertThat(returnValue).isTrue();
    }

    @Test(expected = FdcException.class)
    public void testDoValidateRequest_without_CauseBy_ThenThrowException() throws FdcException, JsonProcessingException {
        Message<UpdateTokenRequest> msg = MessageBuilder.withPayload(updateTokenRequest).build();
        updateTokenRequest.getUpdateReason().setCausedBy(null);
        boolean returnValue = lifecycleDeleteFilter.doValidateRequest("test", "test", msg);
        assertThat(returnValue).isTrue();
    }

    @Test(expected = FdcException.class)
    public void testDoValidateRequest_without_ReasonCode_ThenThrowException() throws FdcException, JsonProcessingException {
        Message<UpdateTokenRequest> msg = MessageBuilder.withPayload(updateTokenRequest).build();
        updateTokenRequest.getUpdateReason().setReasonCode(null);
        boolean returnValue = lifecycleDeleteFilter.doValidateRequest("test", "test", msg);
        assertThat(returnValue).isTrue();
    }

    @Test(expected = FdcException.class)
    public void testDoValidateRequest_without_TSPID_ThenThrowException() throws FdcException, JsonProcessingException {
        Message<UpdateTokenRequest> msg = MessageBuilder.withPayload(updateTokenRequest).build();
        updateTokenRequest.getUpdateReason().setTspId(null);
        boolean returnValue = lifecycleDeleteFilter.doValidateRequest("test", "test", msg);
        assertThat(returnValue).isTrue();
    }

    @Test(expected = FdcException.class)
    public void testDoValidateRequest_without_VALID_TSPID_ThenThrowException() throws FdcException, JsonProcessingException {
        Message<UpdateTokenRequest> msg = MessageBuilder.withPayload(updateTokenRequest).build();
        updateTokenRequest.getUpdateReason().setTspId("405");
        boolean returnValue = lifecycleDeleteFilter.doValidateRequest("test", "DWS",msg);
    }


    private void setData() {
        updateTokenRequest = new UpdateTokenRequest();
        updateTokenRequest.setOperation(Operation.SUSPEND);

        UpdateReason updateReason = new UpdateReason();
        updateReason.setCausedBy(CausedBy.CARDHOLDER);
        updateReason.setReason("Lost/stolen device");
        updateReason.setReasonCode(ReasonCode.FRAUD);
        updateReason.setTspId(TSPID.MASTERCARD.getValue());

        updateTokenRequest.setUpdateReason(updateReason);
    }

}
