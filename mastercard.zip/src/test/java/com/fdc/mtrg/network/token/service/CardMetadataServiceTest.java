package com.fdc.mtrg.network.token.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fdc.mtrg.network.token.config.ApplicationProperties;
import com.fdc.mtrg.network.token.error.ApplicationError;
import com.fdc.mtrg.network.token.ms.AssetResponse;
import com.fdc.util.exception.FdcException;
import com.fdc.util.exception.types.FdcSystemException;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import static com.fdc.mtrg.network.token.utils.TestUtils.*;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.*;
import static org.mockito.MockitoAnnotations.initMocks;

@RunWith(MockitoJUnitRunner.class)
public class CardMetadataServiceTest {

    @Rule
    public ExpectedException expectedException = ExpectedException.none();

    @Mock
    private ApplicationProperties applicationProperties;

    @Mock
    private ResponseEntity<AssetResponse> responseEntity;

    @Mock
    private RestTemplate restTemplate;

    @InjectMocks
    private GetCardMetadataService metadataService = new GetCardMetadataService();

    public final static String ROOT_URL = "http://localhost:8080/";

    @Test
    public void testAsset() throws Exception {

        when(applicationProperties.getServiceUrl()).thenReturn(ROOT_URL);
        ObjectMapper objectMapper = new ObjectMapper();
        AssetResponse assetResponse = objectMapper.readValue(ASSET_PAYLOAD, AssetResponse.class);
        when(responseEntity.getBody()).thenReturn(assetResponse);

        GetCardMetadataService spyMetadataService = spy(metadataService);

        when(restTemplate.exchange(ArgumentMatchers.anyString(),
                ArgumentMatchers.any(HttpMethod.class),
                ArgumentMatchers.any(),
                ArgumentMatchers.<Class<AssetResponse>>any())).thenReturn(responseEntity);

        spyMetadataService.getCardMetadata(PARTNER_ID, GOOD_ASSET_ID);

        verify(restTemplate).exchange(ArgumentMatchers.anyString(),
                ArgumentMatchers.any(HttpMethod.class),
                ArgumentMatchers.any(),
                ArgumentMatchers.<Class<AssetResponse>>any());


        assertEquals(assetResponse, responseEntity.getBody());
    }

    @Test
    public void testAsset_RestClientException() throws Exception {
        when(applicationProperties.getServiceUrl()).thenReturn(ROOT_URL);
        when(restTemplate.exchange(ArgumentMatchers.anyString(),
                ArgumentMatchers.any(HttpMethod.class),
                ArgumentMatchers.any(),
                ArgumentMatchers.<Class<String>>any())).thenThrow(RestClientException.class);
        expectedException.expect(FdcSystemException.class);
        expectedException.expectMessage(ApplicationError.SERVICE_UNAVAILABLE.getErrorDescription());

        metadataService.getCardMetadata(PARTNER_ID, BAD_ASSET_ID);
    }

    @Test
    public void testAsset_asset_not_found() throws Exception {
        when(applicationProperties.getServiceUrl()).thenReturn(ROOT_URL);
        doThrow(RestClientException.class).when(restTemplate)
                .exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), eq(AssetResponse.class));

        expectedException.expect(FdcSystemException.class);
        expectedException.expectMessage(ApplicationError.SERVICE_UNAVAILABLE.getErrorDescription());

        GetCardMetadataService spyMetadataService = spy(metadataService);
        spyMetadataService.getCardMetadata(PARTNER_ID, BAD_ASSET_ID);
    }
}