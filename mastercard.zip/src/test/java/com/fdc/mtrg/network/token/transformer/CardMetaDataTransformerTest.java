package com.fdc.mtrg.network.token.transformer;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fdc.mtrg.api.GetAssetResponse;
import com.fdc.mtrg.network.token.ms.AssetResponse;
import org.junit.Ignore;
import org.junit.Rule;
import org.junit.Test;
import org.junit.jupiter.api.BeforeEach;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;

import java.io.IOException;

import static com.fdc.mtrg.network.token.utils.TestUtils.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

@RunWith(MockitoJUnitRunner.class)
public class CardMetaDataTransformerTest {

    @Rule
    public ExpectedException expectedException = ExpectedException.none();

    @Mock
    private ObjectMapper objectMapper;

    @InjectMocks
    private GetCardMetadataTransformer metadataTransformer;

    @BeforeEach
    public void init() throws IOException {
        initMocks(this);
        when(objectMapper.writeValueAsString(any())).thenReturn(ASSET_PAYLOAD);
    }

    @Test
    public void testDoTransformResponse() throws Exception {
        AssetResponse assetResponse = getAssetResponse(AssetResponse.class);

        Message<AssetResponse> assetResponseEntity = MessageBuilder.withPayload(assetResponse).build();

        GetAssetResponse getAssetResponse = metadataTransformer.doCardMetadataTransformResposne(PARTNER_ID, assetResponseEntity);
        assertNotNull(getAssetResponse);
        //assertNotNull(getAssetResponse.getTransactionId());
        assertNotNull(getAssetResponse.getMediaContents());

        assertNotNull(getAssetResponse.getMediaContents().getMimeType());
        assertNotNull(getAssetResponse.getMediaContents().getHeight());
        assertNotNull(getAssetResponse.getMediaContents().getWidth());
        assertNotNull(getAssetResponse.getMediaContents().getData());
    }
}
