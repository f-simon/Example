package com.fdc.mtrg.network.token.transformer;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fdc.mtrg.api.*;
import com.fdc.mtrg.network.token.ms.SuspendRequestSchema;
import com.fdc.mtrg.network.token.ms.UnSuspendRequestSchema;
import com.fdc.mtrg.network.token.transformer.CreateLifecycleUnSuspendTransformer;
import com.fdc.util.exception.FdcException;
import com.mastercard.developer.encryption.EncryptionException;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@RunWith(MockitoJUnitRunner.class)
public class CreateLifecycleUnSuspendTransformerRequestTest {

    @Rule
    public ExpectedException expectedException = ExpectedException.none();

    @InjectMocks
    private CreateLifecycleUnSuspendTransformer lifecycleUnSuspendTransformer;

    @Mock
    private ObjectMapper objectMapper;

    @Mock
    private UpdateTokenRequest updateTokenRequest;

    @Before
    public void setUp() {
        setData();
    }

    @Test()
    public void testDoTransformRequest_ThenReturnSuspendRequestSchema()throws FdcException, JsonProcessingException, EncryptionException {

        String causedBy = "CARDHOLDER";
        String reason = "Lost/stolen device";
        String reasonCode = "FRAUD";
        String paymentAppInstanceId = "123456789";
        String responseHost =  "api.firstdata.com";

        Message<UpdateTokenRequest> msg = MessageBuilder.withPayload(updateTokenRequest).build();
        UnSuspendRequestSchema returnRequestSchema  = lifecycleUnSuspendTransformer.doTransformRequest("test", "DWSPMC000000000132d72d4fcb2f4136a0532d3093ff1a45", msg);

        //Assert.assertNotNull(returnRequestSchema.getRequestId());
        Assert.assertNotNull(returnRequestSchema.getTokenUniqueReferences());
        Assert.assertEquals("Not equal", causedBy, returnRequestSchema.getCausedBy());
        Assert.assertEquals("Not equal", reason, returnRequestSchema.getReason());
        Assert.assertEquals("Not equal", reasonCode, returnRequestSchema.getReasonCode());
    }

    private void setData() {
        TokenInfo tokenInfo = new TokenInfo();
        updateTokenRequest = new UpdateTokenRequest();
        updateTokenRequest.setOperation(Operation.SUSPEND);

        UpdateReason updateReason = new UpdateReason();
        updateReason.setCausedBy(CausedBy.CARDHOLDER);
        updateReason.setReason("Lost/stolen device");
        updateReason.setReasonCode(ReasonCode.FRAUD);
        updateReason.setTspId(TSPID.MASTERCARD.getValue());

        updateTokenRequest.setUpdateReason(updateReason);
    }

}
