package com.fdc.mtrg.network.token.validator;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fdc.mtrg.api.CryptoGramRequest;
import com.fdc.mtrg.api.ProvisionTokenRequest;
import com.fdc.mtrg.network.token.error.ApplicationError;
import com.fdc.mtrg.network.token.util.Constants;
import com.fdc.util.exception.FdcException;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.messaging.Message;
import org.springframework.test.context.TestPropertySource;
import org.springframework.validation.FieldError;

import java.util.List;

import static com.fdc.mtrg.network.token.utils.TestUtils.*;
import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class TransactFilterTest {

    private CryptoGramRequest cryptoGramRequest;

    @InjectMocks
    private TransactFilter transactFilter;

    @Mock
    Message<CryptoGramRequest> pTransactMessage;

    @Before
    public void before() throws Exception {
        cryptoGramRequest = getTransactRequest(CryptoGramRequest.class);
        when(pTransactMessage.getPayload()).thenReturn(cryptoGramRequest);
    }

    @Test
    public void testDoValidateRequest() throws Exception {
        assertTrue(transactFilter.doValidateRequest(PARTNER_ID, TOKEN_REFERENCE_ID, pTransactMessage));
    }

    @Test
    public void testDoValidateRequest_invalid_payload_null() {
        when(pTransactMessage.getPayload()).thenReturn(null);
        try {
            transactFilter.doValidateRequest(PARTNER_ID, TOKEN_REFERENCE_ID, pTransactMessage);
        } catch (Exception ex) {
            assertTrue(ex instanceof FdcException);
            FdcException fdcException = (FdcException) ex;
            assertEquals(ApplicationError.INVALID_REQUEST.getErrorCode(), fdcException.getCode());
            assertEquals(ApplicationError.INVALID_REQUEST.getErrorDescription(), fdcException.getMessage());

            List<FieldError> fieldErrors = fdcException.getFieldError();
            assertNotNull(fieldErrors);

            FieldError fieldError = fieldErrors.get(0);
            assertEquals(Constants.TRANSACT_REQUEST_PAYLOAD, fieldError.getField());
            assertEquals(Constants.NULL_PAYLOAD, fieldError.getDefaultMessage());
        }
    }

    @Test
    public void testDoValidateRequest_invalid_attribute(){

        try {
            transactFilter.doValidateRequest(PARTNER_ID, null, pTransactMessage);
        } catch (Exception ex) {
            assertTrue(ex instanceof FdcException);
            FdcException fdcException = (FdcException) ex;
            assertEquals(ApplicationError.INVALID_REQUEST.getErrorCode(), fdcException.getCode());
            assertEquals(ApplicationError.INVALID_REQUEST.getErrorDescription(), fdcException.getMessage());
        }
    }
}