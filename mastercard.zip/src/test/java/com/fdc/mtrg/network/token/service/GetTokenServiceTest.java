package com.fdc.mtrg.network.token.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fdc.mtrg.network.token.config.ApplicationProperties;
import com.fdc.mtrg.network.token.error.ApplicationError;
import com.fdc.mtrg.network.token.ms.GetTokenRequestSchema;
import com.fdc.mtrg.network.token.ms.GetTokenResponseSchema;
import com.fdc.util.exception.FdcException;
import com.fdc.util.exception.types.FdcSystemException;
import com.mastercard.developer.encryption.EncryptionException;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;

import static com.fdc.mtrg.network.token.utils.TestUtils.ROOT_URL;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class GetTokenServiceTest {
    @Rule
    public ExpectedException expectedException = ExpectedException.none();

    @InjectMocks
    private GetTokenService SUT = new GetTokenService();

    @Mock
    private RestTemplate restTemplate;

    @Mock
    private GetTokenRequestSchema getTokenRequestSchema;

    @Mock
    GetTokenResponseSchema getTokenResponseSchema;

    @Mock
    private ObjectMapper objectMapper;

    @Mock
    private ApplicationProperties applicationProperties;

     private String getTokenResponseJson = null;

    @Before
    public void setUp() throws JsonProcessingException {
        when(applicationProperties.getServiceUrl()).thenReturn(ROOT_URL);
        setData();
    }


    @Test
    public void testDoOutboundServiceCall_ThenReturnGetTokenResponseSchema() throws FdcException, IOException, EncryptionException {
        doReturn(new ResponseEntity<>(getTokenResponseJson, HttpStatus.OK)).when(restTemplate)
                .exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(Class.class));

        GetTokenService getSpyTokenService = spy(SUT);
        doReturn(getTokenResponseSchema).when(getSpyTokenService).decrypt(anyString(), any());
        getSpyTokenService.doOutboundServiceCall("test",getTokenRequestSchema);

        verify(restTemplate).exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(Class.class));
        verify(getSpyTokenService).decrypt(anyString(), any());

    }

    @Test
    public void testDoOutboundServiceCall_Then_Throw_RestClientException() throws FdcException {
        doThrow(RestClientException.class).when(restTemplate)
                .exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(Class.class));

        expectedException.expect(FdcSystemException.class);
        expectedException.expectMessage(ApplicationError.SERVICE_UNAVAILABLE.getErrorDescription());

        SUT.doOutboundServiceCall("test",getTokenRequestSchema);

    }

    @Test
    public void testDoOutboundServiceCall_Then_Throw_EncryptionException() throws EncryptionException, FdcException, IOException {

        doReturn(new ResponseEntity<>(getTokenResponseJson, HttpStatus.OK)).when(restTemplate)
                .exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(Class.class));

        GetTokenService getSpyTokenService = spy(SUT);
        doThrow(EncryptionException.class).when(getSpyTokenService).decrypt(anyString(), any());

        expectedException.expect(FdcException.class);
        expectedException.expectMessage(ApplicationError.TOKENIZATION_FAILED.getErrorDescription());

        getSpyTokenService.doOutboundServiceCall("test",getTokenRequestSchema);

    }

    @Test
    public void testDoOutboundServiceCall_Then_Throw_IOException() throws EncryptionException, FdcException, IOException {

        doReturn(new ResponseEntity<>(getTokenResponseJson, HttpStatus.OK)).when(restTemplate)
                .exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(Class.class));

        GetTokenService getSpyTokenService = spy(SUT);
        doThrow(IOException.class).when(getSpyTokenService).decrypt(anyString(), any());

        expectedException.expect(FdcException.class);
        expectedException.expectMessage(ApplicationError.TOKENIZATION_FAILED.getErrorDescription());

        getSpyTokenService.doOutboundServiceCall("test",getTokenRequestSchema);

    }



    public void setData() throws JsonProcessingException {
        getTokenRequestSchema = new GetTokenRequestSchema();
        getTokenRequestSchema.setRequestId("123456");
        getTokenRequestSchema.setPaymentAppInstanceId("123456789");
        getTokenRequestSchema.setTokenUniqueReference("DWSPMC000000000132d72d4fcb2f4136a0532d3093ff1a45");
        getTokenRequestSchema.setIncludeTokenDetail("true");

        //
        getTokenResponseJson = "{\"responseHost\":\"site.1.sample.service.mastercard.com\",\"responseId\":\"856fe8e16e65d28f6f947b226df5d1d5\"," +
                "\"token\":{\"tokenUniqueReference\":\"DWSDWSPMC000000000132d72d4fcb2f4136a0532d3093ff1a45\",\"status\":\"ACTIVE\"," +
                "\"statusTimestamp\":\"2017-09-06T00:00:00.000Z\",\"productConfig\":{\"brandLogoAssetId\":\"800200c9-629d-11e3-949a-0739d27e5a67\"," +
                "\"issuerLogoAssetId\":\"629d00c9-549a-21e3-129c-0739b35e5a38\",\"isCoBranded\":\"true\",\"coBrandName\":\"Test CoBrand Name\"," +
                "\"coBrandLogoAssetId\":\"Test coBrand Logo AssetId\",\"cardBackgroundCombinedAssetId\":\"739d27e5-629d-11e3-949a-0800200c9a66\"," +
                "\"iconAssetId\":\"800d00c3-549a-41e3-223b-0739b35e5187\",\"foregroundColor\":\"000000\",\"issuerName\":\"Issuing Bank\"," +
                "\"shortDescription\":\"Bank Rewards MasterCard\",\"longDescription\":\"Bank Rewards MasterCard with the super duper rewards program\"," +
                "\"customerServiceUrl\":\"https://bank.com/customerservice\",\"customerServiceEmail\":\"customerservice@bank.com\"," +
                "\"customerServicePhoneNumber\":\"123-456-7898\",\"issuerMobileApp\":{},\"onlineBankingLoginUrl\":\"https://bank.com/online\"," +
                "\"privacyPolicyUrl\":\"https://bank.com/privacy\",\"issuerProductConfigCode\":\"123456\"}," +
                "\"tokenInfo\":{\"tokenPanSuffix\":\"1234\",\"accountPanSuffix\":\"5675\",\"tokenExpiry\":\"0223\"," +
                "\"accountPanExpiry\":\"0223\",\"dsrpCapable\":\"true\",\"tokenAssuranceLevel\":\"1\",\"productCategory\":\"CREDIT\"}}," +
                "\"tokenDetail\":{\"tokenUniqueReference\":\"DWSDWSPMC000000000132d72d4fcb2f4136a0532d3093ff1a45\"," +
                "\"encryptedData\":{\"tokenNumber\":\"5123456789012345\",\"expiryMonth\":\"12\",\"expiryYear\":\"22\"," +
                "\"paymentAccountReference\":\"500181d9f8e0629211e3949a08002\"}}}";


        objectMapper = new ObjectMapper();
        getTokenResponseSchema = objectMapper.readValue(getTokenResponseJson, GetTokenResponseSchema.class);
    }
}
