package com.fdc.mtrg.network.token.transformer;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fdc.mtrg.api.Card;
import com.fdc.mtrg.api.ProvisionTokenResponse;
import com.fdc.mtrg.network.token.ms.GetTokenResponseSchema;
import com.fdc.util.exception.FdcException;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doReturn;

@RunWith(MockitoJUnitRunner.class)
public class GetTokenTransformerResponseTest {

    @Rule
    public ExpectedException expectedException = ExpectedException.none();

    @InjectMocks
    private GetTokenTransformer getTokenTransformer;

    @Mock
    private ObjectMapper objectMapper;

    private GetTokenResponseSchema getTokenResponseSchema;
    private ProvisionTokenResponse provisionTokenResponse;

    @Before
    public void setUp() throws JsonProcessingException {
        setData();
    }

    @Test()
    public void testGetTokenTransformerResponse_ThenReturnProvisionResponse() throws FdcException, JsonProcessingException {

        provisionTokenResponse = getTokenTransformer.doTransformResposne("test", getTokenResponseSchema);
        Assert.assertNotNull(provisionTokenResponse);
        Assert.assertNotNull(provisionTokenResponse.getProvision().getCard().getAlias());
        Assert.assertNotNull(provisionTokenResponse.getProvision().getCard().getExpiryDate());
        Assert.assertNotNull(provisionTokenResponse.getProvision().getCard().getCardBrandLogoAssetId());
        Assert.assertNotNull(provisionTokenResponse.getProvision().getCard().getCardBrandDescription());
        Assert.assertNotNull(provisionTokenResponse.getProvision().getTokenInfo().getToken().getAlias());
        Assert.assertNotNull(provisionTokenResponse.getProvision().getTokenInfo().getToken().getExpiryDate());
        Assert.assertNotNull(provisionTokenResponse.getProvision().getTokenInfo().getToken().getTokenReferenceId());
        Assert.assertNotNull(provisionTokenResponse.getProvision().getTokenInfo().getToken().getTspId());
        Assert.assertNotNull(provisionTokenResponse.getProvision().getTokenInfo().getToken().getPaymentToken());
        Assert.assertNotNull(provisionTokenResponse.getProvision().getTokenInfo().getToken().getPaymentAccountReferenceId());

    }

    @Test()
    public void testGetTokenTransformerResponse__Without_TransactionId () throws FdcException, JsonProcessingException {

        getTokenResponseSchema.setResponseId(null);
        provisionTokenResponse = getTokenTransformer.doTransformResposne("test", getTokenResponseSchema);

        Assert.assertNull("Not null", provisionTokenResponse.getProvision().getTransactionId());
    }


    public void setData() throws JsonProcessingException {
        String getTokenResponseJson = "{\"responseHost\":\"site.1.sample.service.mastercard.com\",\"responseId\":\"856fe8e16e65d28f6f947b226df5d1d5\"," +
                "\"token\":{\"tokenUniqueReference\":\"DWSDWSPMC000000000132d72d4fcb2f4136a0532d3093ff1a45\",\"status\":\"ACTIVE\"," +
                "\"statusTimestamp\":\"2017-09-06T00:00:00.000Z\",\"productConfig\":{\"brandLogoAssetId\":\"800200c9-629d-11e3-949a-0739d27e5a67\"," +
                "\"issuerLogoAssetId\":\"629d00c9-549a-21e3-129c-0739b35e5a38\",\"isCoBranded\":\"true\",\"coBrandName\":\"Test CoBrand Name\"," +
                "\"coBrandLogoAssetId\":\"Test coBrand Logo AssetId\",\"cardBackgroundCombinedAssetId\":\"739d27e5-629d-11e3-949a-0800200c9a66\"," +
                "\"iconAssetId\":\"800d00c3-549a-41e3-223b-0739b35e5187\",\"foregroundColor\":\"000000\",\"issuerName\":\"Issuing Bank\"," +
                "\"shortDescription\":\"Bank Rewards MasterCard\",\"longDescription\":\"Bank Rewards MasterCard with the super duper rewards program\"," +
                "\"customerServiceUrl\":\"https://bank.com/customerservice\",\"customerServiceEmail\":\"customerservice@bank.com\"," +
                "\"customerServicePhoneNumber\":\"123-456-7898\",\"issuerMobileApp\":{},\"onlineBankingLoginUrl\":\"https://bank.com/online\"," +
                "\"privacyPolicyUrl\":\"https://bank.com/privacy\",\"issuerProductConfigCode\":\"123456\"}," +
                "\"tokenInfo\":{\"tokenPanSuffix\":\"1234\",\"accountPanSuffix\":\"5675\",\"tokenExpiry\":\"0223\"," +
                "\"accountPanExpiry\":\"0223\",\"dsrpCapable\":\"true\",\"tokenAssuranceLevel\":\"1\",\"productCategory\":\"CREDIT\"}}," +
                "\"tokenDetail\":{\"tokenUniqueReference\":\"DWSDWSPMC000000000132d72d4fcb2f4136a0532d3093ff1a45\"," +
                "\"encryptedData\":{\"tokenNumber\":\"5123456789012345\",\"expiryMonth\":\"12\",\"expiryYear\":\"22\"," +
                "\"paymentAccountReference\":\"500181d9f8e0629211e3949a08002\"}}}";


         objectMapper = new ObjectMapper();
         getTokenResponseSchema = objectMapper.readValue(getTokenResponseJson, GetTokenResponseSchema.class);
    }


}
