package com.fdc.mtrg.network.token.validator;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fdc.mtrg.api.*;
import com.fdc.mtrg.network.token.error.ApplicationError;
import com.fdc.mtrg.network.token.validator.CreateLifecycleSuspendFilter;
import com.fdc.util.exception.FdcException;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

@RunWith(MockitoJUnitRunner.class)
public class CreateLifecycleSuspendFilterTest {

    @Mock
    private UpdateTokenRequest updateTokenRequest;

    @Mock
    private ObjectMapper objectMapper;

    @InjectMocks
    private CreateLifecycleSuspendFilter lifecycleSuspendFilter;

    @Before
    public void setUp() {
        setData();

    }
    @Test()
    public void testDoValidateRequest_ThenReturnTrue() throws FdcException, JsonProcessingException {
        Message<UpdateTokenRequest> msg = MessageBuilder.withPayload(updateTokenRequest).build();
        boolean returnValue = lifecycleSuspendFilter.doValidateRequest("test", "DWSPMC000000000132d72d4fcb2f4136a0532d3093ff1a45", msg);
    }

    @Test(expected = FdcException.class)
    public void testDoValidateRequest_ThenThrowException() throws FdcException, JsonProcessingException {
        Message<UpdateTokenRequest> msg = MessageBuilder.withPayload(new UpdateTokenRequest()).build();
        boolean returnValue = lifecycleSuspendFilter.doValidateRequest("test","DWSPMC000000000132d72d4fcb2f4136a0532d3093ff1a45", msg);
    }

    @Test(expected = FdcException.class)
    public void testDoValidateRequest_without_CauseBy_ThenThrowException() throws FdcException, JsonProcessingException {
        Message<UpdateTokenRequest> msg = MessageBuilder.withPayload(updateTokenRequest).build();
        updateTokenRequest.getUpdateReason().setCausedBy(null);
        boolean returnValue = lifecycleSuspendFilter.doValidateRequest("test", "DWSDWSPMC000000000132d72d4fcb2f4136a0532d3093ff1a45", msg);
    }

    @Test(expected = FdcException.class)
    public void testDoValidateRequest_without_ReasonCode_ThenThrowException() throws FdcException, JsonProcessingException {
        Message<UpdateTokenRequest> msg = MessageBuilder.withPayload(updateTokenRequest).build();
        updateTokenRequest.getUpdateReason().setReasonCode(null);
        boolean returnValue = lifecycleSuspendFilter.doValidateRequest("test", "DWSDWSPMC000000000132d72d4fcb2f4136a0532d3093ff1a45", msg);

    }

    @Test(expected = FdcException.class)
    public void testDoValidateRequest_without_TSPID_ThenThrowException() throws FdcException, JsonProcessingException {
        Message<UpdateTokenRequest> msg = MessageBuilder.withPayload(updateTokenRequest).build();
        updateTokenRequest.getUpdateReason().setTspId(null);
        boolean returnValue = lifecycleSuspendFilter.doValidateRequest("test", "DWS",msg);
    }

    @Test(expected = FdcException.class)
    public void testDoValidateRequest_without_VALID_TSPID_ThenThrowException() throws FdcException, JsonProcessingException {
        Message<UpdateTokenRequest> msg = MessageBuilder.withPayload(updateTokenRequest).build();
        updateTokenRequest.getUpdateReason().setTspId("405");
        boolean returnValue = lifecycleSuspendFilter.doValidateRequest("test", "DWS",msg);
    }



    private void setData() {
        updateTokenRequest = new UpdateTokenRequest();
        updateTokenRequest.setOperation(Operation.SUSPEND);

        UpdateReason updateReason = new UpdateReason();
        updateReason.setCausedBy(CausedBy.CARDHOLDER);
        updateReason.setReason("Lost/stolen device");
        updateReason.setReasonCode(ReasonCode.FRAUD);
        updateReason.setTspId(TSPID.MASTERCARD.getValue());

        updateTokenRequest.setUpdateReason(updateReason);
    }
}
