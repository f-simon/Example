package com.fdc.mtrg.network.token.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fdc.mtrg.api.ProvisionTokenRequest;
import com.fdc.mtrg.network.token.config.ApplicationProperties;
import com.fdc.mtrg.network.token.entity.MerchantTridMapping;
import com.fdc.mtrg.network.token.error.ApplicationError;
import com.fdc.mtrg.network.token.ms.*;
import com.fdc.mtrg.network.token.ms.search.SearchTokensResponseSchema;
import com.fdc.mtrg.network.token.ms.search.Token;
import com.fdc.mtrg.network.token.repository.MerchantTridRepository;
import com.fdc.mtrg.network.token.transformer.TokenizeTransformer;
import com.fdc.util.exception.FdcException;
import com.fdc.util.exception.types.FdcSystemException;
import com.mastercard.developer.encryption.EncryptionException;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.messaging.Message;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static com.fdc.mtrg.network.token.cache.CacheConfigurations.MERCHANT_TRID_TSP_CACHE;
import static com.fdc.mtrg.network.token.utils.TestUtils.*;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class TokenizeServiceTest {

    @Rule
    public ExpectedException expectedException = ExpectedException.none();

    @Mock
    private ApplicationProperties applicationProperties;

    @Mock
    private RestTemplate restTemplate;

    @Mock
    Message<ProvisionTokenRequest> pRequestMessage;

    @Mock
    private ResponseEntity<String> responseEntity;

    @Mock
    private ResponseEntity<SearchTokensResponseSchema> searchResponseEntity;

    @Mock
    private SearchTokensResponseSchema searchTokensResponseSchema;

    @Mock
    private Token token;

    @InjectMocks
    private TokenizeTransformer tokenizeTransformer = new TokenizeTransformer();

    @InjectMocks
    private TokenizeService tokenizeService = new TokenizeService();

    private TokenizeRequest tokenizeRequest;

    @Mock
    private ObjectMapper objectMapper;

    @Mock
    private MerchantTridRepository merchantTridRepository;

    @Mock
    private CacheManager cacheManager;

    @Before
    public void before() throws Exception {
        ProvisionTokenRequest provisionTokenRequest = getTokenRequest(ProvisionTokenRequest.class);
        when(pRequestMessage.getPayload()).thenReturn(provisionTokenRequest);
        List<Token> tokenList = new ArrayList<>();
        tokenList.add(token);
        List<MerchantTridMapping> merchantTridMappings = new ArrayList<>();
        MerchantTridMapping merchantTridMapping = new MerchantTridMapping();
        merchantTridMapping.setMerchantId("TEST");
        merchantTridMapping.setTokenRequestorId("123456789");
        merchantTridMappings.add(merchantTridMapping);
        when(merchantTridRepository.findByMerchantIdAndTsp(anyString(), anyString())).thenReturn(merchantTridMappings);
        tokenizeRequest = tokenizeTransformer.doTransformRequest(PARTNER_ID, pRequestMessage);
    }

    @Test
    public void testTokenize() throws Exception {
        when(applicationProperties.getServiceUrl()).thenReturn(ROOT_URL);
        ObjectMapper objectMapper1 = new ObjectMapper();
        TokenizeResponse tokenizeResponse = objectMapper1.readValue(TOKENIZATION_RESPOSNE.getBytes(), TokenizeResponse.class);
        when(responseEntity.getBody()).thenReturn(TOKENIZATION_RESPOSNE);
        TokenizeService spyTokenizeService = spy(tokenizeService);
        when(restTemplate.exchange(ArgumentMatchers.anyString(),
                ArgumentMatchers.any(HttpMethod.class),
                ArgumentMatchers.any(),
                ArgumentMatchers.<Class<String>>any())).thenReturn(responseEntity);
        doReturn(tokenizeResponse).when(spyTokenizeService).decrypt(anyString(), any());
        spyTokenizeService.tokenize(PARTNER_ID, tokenizeRequest);

        verify(restTemplate).exchange(ArgumentMatchers.anyString(),
                ArgumentMatchers.any(HttpMethod.class),
                ArgumentMatchers.any(),
                ArgumentMatchers.<Class<String>>any());
        verify(spyTokenizeService).decrypt(anyString(), any());
    }

    @Test
    public void testTokenize_RestClientException() throws Exception {
        when(applicationProperties.getServiceUrl()).thenReturn(ROOT_URL);
        when(restTemplate.exchange(ArgumentMatchers.anyString(),
                ArgumentMatchers.any(HttpMethod.class),
                ArgumentMatchers.any(),
                ArgumentMatchers.<Class<String>>any())).thenThrow(RestClientException.class);
        expectedException.expect(FdcSystemException.class);
        expectedException.expectMessage(ApplicationError.SERVICE_UNAVAILABLE.getErrorDescription());

        tokenizeService.tokenize(PARTNER_ID, tokenizeRequest);
    }

    @Test
    public void testTokenize_EncryptionException() throws Exception {
        when(applicationProperties.getServiceUrl()).thenReturn(ROOT_URL);
        when(responseEntity.getBody()).thenReturn(RESPONSE_PAYLOAD);
        TokenizeService spyTokenizeService = spy(tokenizeService);
        when(restTemplate.exchange(ArgumentMatchers.anyString(),
                ArgumentMatchers.any(HttpMethod.class),
                ArgumentMatchers.any(),
                ArgumentMatchers.<Class<String>>any())).thenReturn(responseEntity);
        doThrow(EncryptionException.class).when(spyTokenizeService).decrypt(anyString(), any());

        expectedException.expect(FdcException.class);
        expectedException.expectMessage(ApplicationError.TOKENIZATION_FAILED.getErrorDescription());

        spyTokenizeService.tokenize(PARTNER_ID, tokenizeRequest);
    }

    @Test(expected = FdcException.class)
    public void testTokenize_IOException() throws Exception {
        when(applicationProperties.getServiceUrl()).thenReturn(ROOT_URL);
        when(responseEntity.getBody()).thenReturn(RESPONSE_PAYLOAD);
        TokenizeService spyTokenizeService = spy(tokenizeService);
        when(restTemplate.exchange(ArgumentMatchers.anyString(),
                ArgumentMatchers.any(HttpMethod.class),
                ArgumentMatchers.any(),
                ArgumentMatchers.<Class<String>>any())).thenReturn(responseEntity);
        doThrow(IOException.class).when(spyTokenizeService).decrypt(anyString(), any());

        spyTokenizeService.tokenize(PARTNER_ID, tokenizeRequest);
    }

    @Test
    public void testSearchTokens() throws Exception {
        when(applicationProperties.getServiceUrl()).thenReturn(ROOT_URL);
        when(restTemplate.exchange(ArgumentMatchers.anyString(),
                ArgumentMatchers.any(HttpMethod.class),
                ArgumentMatchers.any(),
                ArgumentMatchers.<Class<SearchTokensResponseSchema>>any())).thenReturn(searchResponseEntity);
        when(searchResponseEntity.getBody()).thenReturn(searchTokensResponseSchema);
        tokenizeService.searchTokens(PARTNER_ID, tokenizeRequest);

        verify(restTemplate).exchange(ArgumentMatchers.anyString(),
                ArgumentMatchers.any(HttpMethod.class),
                ArgumentMatchers.any(),
                ArgumentMatchers.<Class<String>>any());
    }

    @Test
    public void testSearchTokens_RestClientException() throws Exception {
        when(applicationProperties.getServiceUrl()).thenReturn(ROOT_URL);
        when(restTemplate.exchange(ArgumentMatchers.anyString(),
                ArgumentMatchers.any(HttpMethod.class),
                ArgumentMatchers.any(),
                ArgumentMatchers.<Class<String>>any())).thenThrow(RestClientException.class);
        expectedException.expect(FdcSystemException.class);
        expectedException.expectMessage(ApplicationError.SERVICE_UNAVAILABLE.getErrorDescription());

        tokenizeService.searchTokens(PARTNER_ID, tokenizeRequest);
    }

    @Test
    public void testSearchTokens_card_not_found() throws Exception {
        when(applicationProperties.getServiceUrl()).thenReturn(ROOT_URL);
        when(restTemplate.exchange(ArgumentMatchers.anyString(),
                ArgumentMatchers.any(HttpMethod.class),
                ArgumentMatchers.any(),
                ArgumentMatchers.<Class<SearchTokensResponseSchema>>any())).thenReturn(searchResponseEntity);
        when(searchResponseEntity.getBody()).thenReturn(searchTokensResponseSchema);
        //when(searchTokensResponseSchema.getTokens()).thenReturn(null);
        //expectedException.expect(FdcException.class);
        //expectedException.expectMessage(ApplicationError.CARD_NOT_FOUND.getErrorDescription());

        tokenizeRequest = new TokenizeRequest();
        FundingAccountInfo fundingAccountInfo = new FundingAccountInfo();
        EncryptedPayload encryptedPayload = new EncryptedPayload();
        EncryptedData encryptedData = new EncryptedData();
        CardAccountData cardAccountData = new CardAccountData();
        cardAccountData.setAccountNumber("11111");
        encryptedData.setAccountNumber("123456789");
        encryptedData.setCardAccountData(cardAccountData);
        encryptedPayload.setEncryptedData(encryptedData);
        fundingAccountInfo.setEncryptedPayload(encryptedPayload);
        tokenizeRequest.setFundingAccountInfo(fundingAccountInfo);
        tokenizeService.searchTokens(PARTNER_ID, tokenizeRequest);
    }

    @Test
    public void testDecrypt_RestClientException() throws Exception {
        String payload = "{\"requestId\":\"1234\", \"token\":\"5678\"}";
        expectedException.expect(IllegalArgumentException.class);
        expectedException.expectMessage("Can't decrypt without decryption key!");

        tokenizeService.decrypt(payload, String.class);
    }

}
