package com.fdc.mtrg.network.token.utils;

import com.fasterxml.jackson.databind.ObjectMapper;

public class TestUtils {
    public final static String ROOT_URL = "http://localhost:8080";
    public final static String URL_PATH = "/v1/merchants/1234/provision-tokens";
    public final static String PARTNER_ID = "merchantId";
    public final static String TOKEN_REFERENCE_ID = "tokenReferenceId";
    public final static String GOOD_ASSET_ID = "3789637f-32a1-4810-a138-4bf34501c509";
    public final static String BAD_ASSET_ID = "3789637f-32a1-4810-a138-4bf34501c5090";
    public final static String ASSET_PAYLOAD_FIRST48 = "Ppefulr4Ydre1RYhpmkWCtOFwnRHIt7b28NSMbASV1RmplzJ";

    public final static String BAD_ASSET_PAYLOAD = "{\"code\":\"400012\",\"message\":\"Error:BadAssetId.\"," +
            "\"category\":\"common\",\"developerInfo\":{\"developerMessage\":\"Error:BadAssetId.\",\"fieldError\":" +
            "[{\"field\":\"AssetId\",\"message\":\"InvalidAssetId:3789637f-32a1-4810-a138-4bf34501c5090\"}]}}";
    public final static String ASSET_PAYLOAD = "{\"mediaContents\":[{\"type\":\"image/png\",\"height\":\"375\",\"width\":\"375\"," +
            "\"data\":\"iVBORw0KGgoAAAANSUhEUgAAAXcAAAF3" +
            "CAIAAADRopypAAAABGdBTUEAANbY1E9YMgAAAAlwSFlzAAAASAAAAEgARslrPgAAGtNJREFUeNrt3" +
            "W9oW+e9wPFTkx5MpIlItJKppVJHI7Ea1yY0ieskkKbM8VizS0lvy2CXezvaN3uxQTNYX\\/RCU7h90TcpdC\"},{\"type\":\"image/png\"," +
            "\"height\":\"575\",\"width\":\"575\",\"data\":\"Ppefulr4Ydre1RYhpmkWCtOFwnRHIt7b28NSMbASV1RmplzJT1117eBlzYOfGTlNa4CVKK7MT" +
            "LkyMXHZB9Pg+dbsHuhnDgUspKwyvunLohd1e9wPFTkx5MpIlItJKppVJHI7Ea1yY0ieskkKbM8VizS0lvy2CXezvaN3uxQTNYX\\/RCU7h90TcpdC\"}]}";

    public final static String REQUEST_PAYLOAD = "{\"provision\":{\"card\":{\"cardNumber\":\"54321111111111111\",\"nameOnCard\":\"John Smith\",\"securityCode\":\"444\"," +
            "\"expiryDate\":{\"month\":\"09\",\"year\":\"20\"},\"billingAddress\":{\"type\":\"work\",\"streetAddress\":\"100 Universal City Plaza\",\"locality\":\"Hollywood\"," +
            "\"region\":\"CA\",\"postalCode\":\"91608\",\"country\":\"USA\",\"formatted\":\"100 Universal City Plaza\\nHollywood, CA 91608 US\",\"primary\":true}," +
            "\"source\":\"ACCOUNT_ON_FILE\",\"captureMethod\":\"KEYENTERED\"},\"account\":{\"accountType\":\"GUEST\",\"email\":{\"type\":\"work\",\"value\":\"bjensen@example.com\"," +
            "\"primary\":true},\"clientWalletAccountId\":\"1234560987\",\"clientAppId\":\"1234560987\"},\"deviceDetails\":{\"id\":\"537edec8-d33e-4ee8-93a7-b9f61876950c\"," +
            "\"deviceScore\":\"5\",\"accountScore\":\"5\",\"loaction\":{\"latitude\":\"38.63\",\"longitude\":\"-90.25\",\"ipAddress\":\"172.27.37.221\"}},\"locale\":\"en_US\"}}";

    public final static String TRANSACT_RESPONSE_PAYLOAD = "{\"responseId\" : \"123456\",\"encryptedPayload\" :{\"encryptedData\":{\"accountNumber\":\"123454545\"},\"publicKeyFingerprint\" : \"4c4ead5927f0df8117f178eea9308daa58e27c2b\",\"encryptedKey\" : \"A1B2C3D4E5F6112233445566\",\"oaepHashingAlgorithm\" : \"SHA512\" }}";

    public final static String RESPONSE_PAYLOAD = "{\"responseHost\":\"site.1.sample.service.mastercard.com\",\"responseId\":\"a8f56432-7916-48b3-9aa3-9da7e57de35c\"," +
            "\"decision\":\"APPROVED\",\"tokenUniqueReference\":\"DWSPMC000000000132d72d4fcb2f4136a0532d3093ff1a45\"," +
            "\"panUniqueReference\":\"FWSPMC000000000159f71f703d2141efaf04dd26803f922b\",\"authenticationMethods\":[{\"id\":\"12344\",\"type\":\"TEXT_TO_CARDHOLDER_NUMBER\"," +
            "\"value\":\"12X-XXX-XX32\"},{\"id\":\"12345\",\"type\":\"CARDHOLDER_TO_CALL_AUTOMATED_NUMBER\",\"value\":\"1-800-BANK-NUMBER\"}]," +
            "\"productConfig\":{\"brandLogoAssetId\":\"800200c9-629d-11e3-949a-0739d27e5a66\",\"cardBackgroundCombinedAssetId\":\"739d27e5-629d-11e3-949a-0800200c9a66\"," +
            "\"foregroundColor\":\"000000\",\"issuerName\":\"Issuing Bank\",\"shortDescription\":\"Bank Rewards MasterCard\"," +
            "\"longDescription\":\"Bank Rewards MasterCard with the super duper rewards program\",\"customerServiceUrl\":\"https://bank.com/customerservice\",\"issuerMobileApp\":{}," +
            "\"privacyPolicyUrl\":\"https://bank.com/privacy\",\"issuerProductConfigCode\":\"123456\"},\"tokenInfo\":{\"tokenPanSuffix\":\"1234\",\"accountPanSuffix\":\"1111\"," +
            "\"tokenExpiry\":\"0123\",\"accountPanExpiry\":\"0920\",\"dsrpCapable\":\"false\",\"tokenAssuranceLevel\":\"1\",\"productCategory\":\"CREDIT\"}," +
            "\"tokenDetail\":{\"tokenUniqueReference\":\"4c4ead5927f0df8117f178eea9308daa58e27abc\",\"encryptedData\":{\"paymentAccountReference\":\"500181d9f8e0629211e3949a08002\"}}}";

    public final static String TOKENIZATION_RESPOSNE = "{\n" +
            "  \"responseHost\": \"site1.payment-app-provider.com\",\n" +
            "  \"requestId\": \"123456\",\n" +
            "  \"tokenType\": \"CLOUD\",\n" +
            "  \"tokenRequestorId\": \"123456789\",\n" +
            "  \"taskId\": \"123456\",\n" +
            "  \"fundingAccountInfo\": {\n" +
            "    \"encryptedPayload\": {\n" +
            "      \"encryptedData\": \"522c5c20a5386b225a703702f6871d01bf1d85d80b1b805ff32aef9519cc287f64e09844e259fcb4303a692cbe7dd15dc9a04be019209c9a95bbc5a7ac7ed30c8dbeba87b0dceaef543cf11afd9720e91c629666eb877ccd18f0c9e39d97a30672bf6714a595fe1fb2813edff5afb024b28ebf52eaf5dc71761f3d0acb50c1ba74837425e482c2acf3e7e2e1c14a8dd844e3cb5993f1a3ae81bdc2ec29bd13e05500f71f6aa621c34d8fc11ad8ab08b5d5e97d8d29d57e78e61a8245c3211aab86647a527d5c6cd0baef91eb534ce700ab14ce776ffb08b36faa61f620de0a8b0c50ac3ee38a51a88949806df0319c9df850616e715ebd60855b43151cf1fe3107c032da5dffbfdfb9c504e70766eaf34481cec68dfaa1178ad7ec25bfe1df77f787ee9951f045f504964bb8decc4cdaa74ed9f3dd6019a8efbdf9fa1b7cb9d8c776c8684e2a9c2f3046e97008397b134f185fea39c63b32bbd43798fbeb592e14eb0ddb05aba22479eb31ec9b6776d604c79cd6bf282b22a0e50341766e1b2a3bb9d0b04fa72f60a8f65fce998c3e13e57c4b6312c48dc793a1ef0e6d1a436a43216c543da1e52551037129b4f810c22b3eec06a398424ab793ba7ee8cde3c8f8c7b1f1d02a428841b686502c4e2a859d3add01c0ea6668bc9e13448cb871a0474eb3e38b041bc41075443c00e57693fe65852b620782b4c7b7d77d05ffc2da70f95f8871d9b509d62abe5bc7da3bcb30d29ea9c7d9422f2b53a9371c656174c7fd31ec805ecec4f9caed13edf024bd4c01a41af4b18e7be4672e2ad11573f926556c5701593272acd00fb2aae8d58be4083e4d49a9e4c4450a379deedc5a711c18e751ce3e0a4ab9011398129703210d1eaba6f3cc9ffa18b870a26aa55cfb474f79d20ef4678075fa342fdc66786a\",\n" +
            "      \"publicKeyFingerprint\": \"8FC11150A7508F14BACA07285703392A399CC57C\",\n" +
            "      \"encryptedKey\": \"a4d71a5101a02dfe44e70cad5fdc48c1d0873072ca18f249d92bc8e8bc610bdbb383b842d2d68d3e8fc199ac179bc81cc7696c5dfad9ce662cc9219ae937c433ad769df399d675e23cf5244fa8f3b20b166af5e386a370c8c30550928c928dfdfe5423ce7b72bebe8779c6474035a55f48d65c03ed9f24bb04e0fde1e9c8ce296c4b602fd032516412f5bac05c827a3cb9b9b98840d6b74d1fd4cdf4be91880280fb5fd38a3155819ddeebdfb33e7776dcd6d1fa1cca052b3615555d716602f9e61d47c33d68d5ae4363881b37a6313d85c748f583cac14169535de793cbc4608bed1cb076dea14898a71d02e909e0845d515f0c7afef89e4ba8f75526af67a7\",\n" +
            "      \"oaepHashingAlgorithm\": \"SHA256\",\n" +
            "      \"iv\": \"48dbb3d6718cc69a317290cb8dc81f50\"\n" +
            "    }\n" +
            "  }\n" +
            "}";

    public final static String SEARCH_RESPONSE = "{\"responseHost\":\"site.1.sample.service.mastercard.com\",\"responseId\":\"c9d6f8fb-fc78-44d9-ae25-4fc400a5b701\"," +
            "\"tokens\":[{\"tokenUniqueReference\":\"DWSPMC000000000132d72d4fcb2f4136a0532d3093ff1a45\",\"status\":\"ACTIVE\",\"statusTimestamp\":\"2017-09-05T00:00:00.000Z\"}," +
            "{\"tokenUniqueReference\":\"DWSPMC00000000032d72d4ffcb2f4136a0532d32d72d4fcb\",\"status\":\"ACTIVE\",\"statusTimestamp\":\"2017-09-06T00:00:00.000Z\"}," +
            "{\"tokenUniqueReference\":\"DWSPMC000000000fcb2f4136b2f4136a0532d2f4136a0532\",\"status\":\"SUSPENDED\",\"suspendedBy\":[\"TOKEN_REQUESTOR\"]," +
            "\"statusTimestamp\":\"2017-09-07T00:00:00.000Z\"}]}";

    public final static String TRANSACT_REQUEST_PAYLOAD = "{" +
            "  \"transactionType\": \"ECOM\"," +
            "  \"tspId\": \"501\"," +
            "  \"transactionInitiaitionType\": \"CONSUMER\"," +
            "  \"acquirerMerchantId\": \"53722\"" +
            "}";

    public static ObjectMapper objectMapper = new ObjectMapper();

    public static <T> T  getTokenRequest(Class<T> valueType) throws Exception {
        return objectMapper.readValue(REQUEST_PAYLOAD.getBytes(), valueType);
    }

    public static <T> T  getTransactRequest(Class<T> valueType) throws Exception {
        return objectMapper.readValue(TRANSACT_REQUEST_PAYLOAD.getBytes(), valueType);
    }

    public static <T> T  getTokenResponse(Class<T> valueType) throws Exception {
        return objectMapper.readValue(RESPONSE_PAYLOAD.getBytes(), valueType);
    }

    public static <T> T  getTransactResponse(Class<T> valueType) throws Exception {
        return objectMapper.readValue(TRANSACT_RESPONSE_PAYLOAD.getBytes(), valueType);
    }

    public static <T> T  getSearchResponse(Class<T> valueType) throws Exception {
        return objectMapper.readValue(SEARCH_RESPONSE.getBytes(), valueType);
    }

    public static <T> T  getAssetResponse(Class<T> valueType) throws Exception {
        return objectMapper.readValue(ASSET_PAYLOAD.getBytes(), valueType);
    }
}
