package com.fdc.mtrg.network.token.transformer;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fdc.mtrg.api.SearchTokenResponse;
import com.fdc.mtrg.network.token.ms.search.SearchTokensResponseSchema;
import com.fdc.util.exception.FdcException;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.List;

import static com.fdc.mtrg.network.token.utils.TestUtils.*;
import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class SearchTokenTransformerTest {
    @Rule
    public ExpectedException expectedException = ExpectedException.none();

    @Mock
    private ObjectMapper objectMapper;

    @InjectMocks
    SearchTokenTransformer searchTokenTransformer;

    private SearchTokensResponseSchema searchResponseSchema;

    @Before
    public void before() throws  Exception{
    }

    @Test
    public void testDoTransformResponse() throws Exception {
        SearchTokensResponseSchema searchResponseSchema = getSearchResponse(SearchTokensResponseSchema.class);
        //when(objectMapper.writeValueAsString(any())).thenReturn(SEARCH_RESPONSE);
        SearchTokenResponse searchTokenResponse = searchTokenTransformer.doTransformResponse(PARTNER_ID, searchResponseSchema);

        assertNotNull(searchTokenResponse);
        assertTrue(searchResponseSchema.getTokens().stream().allMatch(token ->
                searchTokenResponse.getTokenInfo().stream().anyMatch(am ->
                {
                    boolean result = false;
                    if(am.getToken() != null) {
                        String referenceId = am.getToken().getTokenReferenceId();
                        if (referenceId != null) {
                            result = token.getStatus().equals(am.getDecision().getValue()) && token.getTokenUniqueReference().equals(referenceId);
                        }
                    }
                    return result;
                })));
    }

    @Test
    @Ignore
    public void testDoTransformResponse_JsonProcessingException() throws Exception {
        when(objectMapper.writeValueAsString(any())).thenThrow(JsonProcessingException.class);
        expectedException.expect(FdcException.class);
        searchTokenTransformer.doTransformResponse(PARTNER_ID, getSearchResponse(SearchTokensResponseSchema.class));
    }
}
