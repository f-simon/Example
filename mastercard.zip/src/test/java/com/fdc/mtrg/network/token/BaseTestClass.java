package com.fdc.mtrg.network.token;

import com.fdc.mtrg.network.token.endpoint.ApplicationController;
import com.fdc.mtrg.network.token.exception.ServiceExceptionAdvice;
import io.restassured.module.mockmvc.RestAssuredMockMvc;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.test.web.servlet.setup.StandaloneMockMvcBuilder;

@RunWith(SpringRunner.class)
@ActiveProfiles("test")
@SpringBootTest(classes = NetworkTokenApplication.class)
@Ignore
public class BaseTestClass {

    @Autowired
    ApplicationController applicationController;

    @Before
    public void setup() {
        StandaloneMockMvcBuilder standaloneMockMvcBuilder =
                MockMvcBuilders.standaloneSetup(applicationController)
                        .setControllerAdvice(new ServiceExceptionAdvice());
        RestAssuredMockMvc.standaloneSetup(standaloneMockMvcBuilder);
    }
}
