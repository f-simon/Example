package com.fdc.mtrg.network.token.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fdc.mtrg.network.token.config.ApplicationProperties;
import com.fdc.mtrg.network.token.ms.TokenizeResponse;
import com.fdc.mtrg.network.token.util.Constants;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpHeaders;

import static com.fdc.mtrg.network.token.utils.TestUtils.ROOT_URL;
import static com.fdc.mtrg.network.token.utils.TestUtils.URL_PATH;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class NetworkTokensServiceTest {
    @Rule
    public ExpectedException expectedException = ExpectedException.none();

    @Mock
    private ApplicationProperties applicationProperties;

    @InjectMocks
    private NetworkTokensService networkTokensService;

    private ObjectMapper objectMapper;

    @Before
    public void before() {
        objectMapper = new ObjectMapper();

    }

    @Test
    public void testGetUri() {
        when(applicationProperties.getServiceUrl()).thenReturn(ROOT_URL);
        String url = networkTokensService.getUri(URL_PATH);

        assertNotNull(url);
        assertEquals(url, ROOT_URL + URL_PATH);
    }

    @Test
    public void testGetHttpHeaders() {
        final HttpHeaders headers = networkTokensService.getHttpHeaders();

        assertNotNull(headers);
        assertNotNull(headers.get(Constants.ACCCEPT));
        assertNotNull(headers.get(Constants.CONTENT_TYPE));
        assertEquals(Constants.CONTENT_TYPE_JSON, headers.get(Constants.ACCCEPT).get(0));
        assertEquals(Constants.APPLICATION_JSON, headers.get(Constants.CONTENT_TYPE).get(0));
    }

    @Test
    public void testDecrypt_EncryptionException() throws Exception {
        String payload = "{\"requestId\":\"1234\", \"token\":\"5678\"}";
        expectedException.expect(IllegalArgumentException.class);
        expectedException.expectMessage("Can't decrypt without decryption key!");

        networkTokensService.decrypt(payload, TokenizeResponse.class);
    }
    //todo: add other tests on decrypt methods once PowerMock is ready
}
