package com.fdc.mtrg.network.token.validator;

import com.fdc.mtrg.network.token.service.GetTokenService;
import com.fdc.util.exception.FdcException;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doReturn;

@RunWith(MockitoJUnitRunner.class)
public class GetTokenFilterTest {


    @Autowired
    private GetTokenFilter getTokenFilter;

    @Before
    public void setUp(){
        getTokenFilter = new GetTokenFilter();
    }

    @Test
    public void testDoValidateRequest_ThenReturnTrue() throws FdcException {

        Boolean returnTrue = getTokenFilter.doValidateRequest("test", "AAABBB");
        Assert.assertTrue(returnTrue);
    }

    @Test(expected = FdcException.class)
    public void testDoValidateRequest_Without_TokenReferenceId_ThenThrow_FdcException() throws FdcException {
        getTokenFilter.doValidateRequest("test", null);

    }

}
