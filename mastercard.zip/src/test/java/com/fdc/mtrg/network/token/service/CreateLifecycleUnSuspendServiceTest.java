package com.fdc.mtrg.network.token.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fdc.mtrg.network.token.config.ApplicationProperties;
import com.fdc.mtrg.network.token.error.ApplicationError;
import com.fdc.mtrg.network.token.ms.TokenForLCM;
import com.fdc.mtrg.network.token.ms.UnSuspendRequestSchema;
import com.fdc.mtrg.network.token.ms.UnSuspendResponseSchema;
import com.fdc.mtrg.network.token.transformer.CreateLifecycleSuspendTransformer;
import com.fdc.util.exception.FdcException;
import com.fdc.util.exception.types.FdcSystemException;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestClientResponseException;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static com.fdc.mtrg.network.token.utils.TestUtils.ROOT_URL;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class CreateLifecycleUnSuspendServiceTest {

    @Rule
    public ExpectedException expectedException = ExpectedException.none();

    @InjectMocks
    private CreateLifecycleUnSuspendService lifecycleUnSuspendService = new CreateLifecycleUnSuspendService();

    @Mock
    private ObjectMapper objectMapper;

    @Mock
    private ApplicationProperties applicationProperties;

    @Mock
    private RestTemplate restTemplate;

    @Mock
    private UnSuspendRequestSchema unSuspendRequestSchema;

    @Mock
    private UnSuspendResponseSchema unSuspendResponseSchema;

    @Mock
    protected HttpStatusCodeException httpStatusCodeException;


    @Before
    public void setUp() {
        when(applicationProperties.getServiceUrl()).thenReturn(ROOT_URL);
        setData();
    }

    private static final Logger logger = LoggerFactory.getLogger(CreateLifecycleUnSuspendServiceTest.class);

    @Test
    public void testDoOutboundServiceCall_ThenReturnSuspendResponseSchema() throws FdcSystemException, FdcException {

        doReturn(new ResponseEntity<>(unSuspendResponseSchema, HttpStatus.OK)).when(restTemplate)
                .exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(Class.class));

        unSuspendResponseSchema = lifecycleUnSuspendService.doOutboundServiceCall("test", unSuspendRequestSchema);

        Assert.assertNotNull(unSuspendResponseSchema);
    }

    @Test
    public void testDoOutboundServiceCall_Then_Throw_RestClientException() throws FdcSystemException, FdcException {
        doThrow(RestClientException.class).when(restTemplate)
                .exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(Class.class));

        expectedException.expect(FdcSystemException.class);
        expectedException.expectMessage(ApplicationError.SERVICE_UNAVAILABLE.getErrorDescription());

        lifecycleUnSuspendService.doOutboundServiceCall("test", unSuspendRequestSchema);
    }

    private void setData() {
        unSuspendRequestSchema = new UnSuspendRequestSchema();
        unSuspendRequestSchema.setRequestId("17417fb2-704f-4ac7-a559-3de0d7c95ea8");
        unSuspendRequestSchema.setPaymentAppInstanceId("123456789");
        unSuspendRequestSchema.setCausedBy("CARDHOLDER");
        unSuspendRequestSchema.setReason("Lost/stolen device");
        unSuspendRequestSchema.setReasonCode("FRAUD");

        List<String> tokenReferenceIds = new ArrayList<>
                (Arrays.asList("DWSPMC000000000132d72d4fcb2f4136a0532d3093ff1a45"));

        unSuspendRequestSchema.setTokenUniqueReferences(tokenReferenceIds);

        //
        unSuspendResponseSchema  = new UnSuspendResponseSchema();

        unSuspendResponseSchema.setResponseId("17417fb2-704f-4ac7-a559-3de0d7c95ea8");

        TokenForLCM tokenForLCM = new TokenForLCM();
        List<TokenForLCM> tokens = new ArrayList<>();

        tokenForLCM.setTokenUniqueReference("DWSPMC000000000132d72d4fcb2f4136a0532d3093ff1a45");

        tokenForLCM.setStatus("SUSPENDED");

        List<String> suspendedBy = new ArrayList<>(Arrays.asList("ISSUER", "TOKEN_REQUESTOR"));

        tokenForLCM.setSuspendedBy(suspendedBy);
        tokens.add(tokenForLCM);

        TokenForLCM tokenForLCM1 = new TokenForLCM();
        tokenForLCM1.setTokenUniqueReference("DWSPMC000000000132d72d4fcb2f4136a0532d3093ff1a47");
        tokenForLCM1.setStatus("SUSPENDED");

        List<String> suspendedBy1 = new ArrayList<>(Arrays.asList("ISSUER", "CARDHOLDER"));

        tokenForLCM1.setSuspendedBy(suspendedBy1);
        tokens.add(tokenForLCM1);

        unSuspendResponseSchema.setTokens(tokens);
    }
}
