package com.fdc.mtrg.network.token.transformer;

import brave.Span;
import brave.Tracer;
import com.fdc.mtrg.api.GetAssetResponse;
import com.fdc.mtrg.api.MediaContents;
import com.fdc.mtrg.network.token.dto.GetAssetResponseDDX;
import com.fdc.mtrg.network.token.util.Constants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.integration.annotation.Transformer;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class GetResourceTransformer {

    @Autowired
    private Tracer tracer;

    @Transformer
    public GetAssetResponse doTransformRequest(@Header(Constants.MERCHANT_ID) final String pmerchantId,
                                               GetAssetResponseDDX assetResponse) {
        GetAssetResponse asset = new GetAssetResponse();

        assetResponse.getResourceResponse().getResource().forEach(mc -> {
            MediaContents mcs = new MediaContents();
            mcs.mimeType(mc.getMedia())
                    .data(mc.getEncodedResource())
                    .height(mc.getHeight())
                    .width(mc.getWidth());
            asset.setMediaContents(mcs);
        });

        Optional.ofNullable(tracer).map(Tracer::currentSpan).map(Span::context)
                .ifPresent(traceId -> asset.setTransactionId(traceId.toString()));
        return asset;
    }
}
