
package com.fdc.mtrg.network.token.dto;

import java.io.Serializable;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "issuerName",
    "website",
    "email",
    "contactNumber",
    "privacyPolicyURL",
    "termsConditionsURL"
})
public class IssuerContext implements Serializable
{

    @JsonProperty("issuerName")
    private String issuerName;
    @JsonProperty("website")
    private String website;
    @JsonProperty("email")
    private String email;
    @JsonProperty("contactNumber")
    private String contactNumber;
    @JsonProperty("privacyPolicyURL")
    private String privacyPolicyURL;
    @JsonProperty("termsConditionsURL")
    private String termsConditionsURL;
    private final static long serialVersionUID = -8703378534800332344L;

    @JsonProperty("issuerName")
    public String getIssuerName() {
        return issuerName;
    }

    @JsonProperty("issuerName")
    public void setIssuerName(String issuerName) {
        this.issuerName = issuerName;
    }

    @JsonProperty("website")
    public String getWebsite() {
        return website;
    }

    @JsonProperty("website")
    public void setWebsite(String website) {
        this.website = website;
    }

    @JsonProperty("email")
    public String getEmail() {
        return email;
    }

    @JsonProperty("email")
    public void setEmail(String email) {
        this.email = email;
    }

    @JsonProperty("contactNumber")
    public String getContactNumber() {
        return contactNumber;
    }

    @JsonProperty("contactNumber")
    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }

    @JsonProperty("privacyPolicyURL")
    public String getPrivacyPolicyURL() {
        return privacyPolicyURL;
    }

    @JsonProperty("privacyPolicyURL")
    public void setPrivacyPolicyURL(String privacyPolicyURL) {
        this.privacyPolicyURL = privacyPolicyURL;
    }

    @JsonProperty("termsConditionsURL")
    public String getTermsConditionsURL() {
        return termsConditionsURL;
    }

    @JsonProperty("termsConditionsURL")
    public void setTermsConditionsURL(String termsConditionsURL) {
        this.termsConditionsURL = termsConditionsURL;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("issuerName", issuerName).append("website", website).append("email", email).append("contactNumber", contactNumber).append("privacyPolicyURL", privacyPolicyURL).append("termsConditionsURL", termsConditionsURL).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(website).append(issuerName).append(contactNumber).append(privacyPolicyURL).append(termsConditionsURL).append(email).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof IssuerContext) == false) {
            return false;
        }
        IssuerContext rhs = ((IssuerContext) other);
        return new EqualsBuilder().append(website, rhs.website).append(issuerName, rhs.issuerName).append(contactNumber, rhs.contactNumber).append(privacyPolicyURL, rhs.privacyPolicyURL).append(termsConditionsURL, rhs.termsConditionsURL).append(email, rhs.email).isEquals();
    }

}
