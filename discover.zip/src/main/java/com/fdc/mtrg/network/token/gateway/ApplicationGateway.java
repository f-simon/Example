package com.fdc.mtrg.network.token.gateway;

import com.fdc.mtrg.api.*;
import com.fdc.mtrg.network.token.dto.GetAssetResponseDDX;
import com.fdc.mtrg.network.token.dto.healthcheck.HeathcheckResponseDDX;
import com.fdc.mtrg.network.token.util.Constants;
import org.springframework.http.HttpStatus;
import org.springframework.messaging.Message;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.messaging.handler.annotation.Payload;

import javax.servlet.http.HttpServletRequest;

public interface ApplicationGateway {

    ProvisionTokenResponse tokenize(@Header(Constants.MERCHANT_ID) final String merchantId,
                                    Message<ProvisionTokenRequest> pRequestMessage);

    @Payload("''")
    HeathcheckResponseDDX healthcheck(@Header(Constants.MERCHANT_ID) final String merchantId,
                                      @Header(Constants.REQUEST_ID) final String requestId,
                                      @Header(Constants.PROGRAM_ID) final String programId);

    CryptoGramResponse transact(@Header(Constants.MERCHANT_ID) final String merchantId,
                                @Header(Constants.TOKEN_REFERENCE_ID) final String tokenReferenceId,
                                Message<CryptoGramRequest> pRequestMessage);

    HttpStatus doLifeCycle(@Header(Constants.MERCHANT_ID) final String merchantId,
                           @Header(Constants.PROVISION_TOKEN_ID) final String tokenReferenceId,
                           Message<UpdateTokenRequest> lifeCycleMessage);

    @Payload("''")
    GetAssetResponseDDX getResource(@Header(Constants.PROGRAM_ID) String programId,
                                    @Header(Constants.RESOURCE_UUID) String resourceUUID,
                                    @Header(Constants.REQUEST_ID) String requestId,
                                    @Header(Constants.MERCHANT_ID) final String merchantId);
}
