
package com.fdc.mtrg.network.token.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.io.Serializable;
import java.util.Objects;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "credentialsContext"
})
public class EncryptedContextResponse implements Serializable
{

    @JsonProperty("credentialsContext")
    private String credentialsContext;

    public String getCredentialsContext() {
        return credentialsContext;
    }

    public void setCredentialsContext(String credentialsContext) {
        this.credentialsContext = credentialsContext;
    }

    @Override
    public String toString() {
        return "ResponseEncryptedContext{" +
                "credentialsContext='" + credentialsContext + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        EncryptedContextResponse that = (EncryptedContextResponse) o;
        return Objects.equals(credentialsContext, that.credentialsContext);
    }

    @Override
    public int hashCode() {
        return Objects.hash(credentialsContext);
    }
}
