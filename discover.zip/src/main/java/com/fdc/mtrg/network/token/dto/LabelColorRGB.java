
package com.fdc.mtrg.network.token.dto;

import java.io.Serializable;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "red",
    "green",
    "blue"
})
public class LabelColorRGB implements Serializable
{

    @JsonProperty("red")
    private String red;
    @JsonProperty("green")
    private String green;
    @JsonProperty("blue")
    private String blue;
    private final static long serialVersionUID = -6701891156025815673L;

    @JsonProperty("red")
    public String getRed() {
        return red;
    }

    @JsonProperty("red")
    public void setRed(String red) {
        this.red = red;
    }

    @JsonProperty("green")
    public String getGreen() {
        return green;
    }

    @JsonProperty("green")
    public void setGreen(String green) {
        this.green = green;
    }

    @JsonProperty("blue")
    public String getBlue() {
        return blue;
    }

    @JsonProperty("blue")
    public void setBlue(String blue) {
        this.blue = blue;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("red", red).append("green", green).append("blue", blue).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(red).append(green).append(blue).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof LabelColorRGB) == false) {
            return false;
        }
        LabelColorRGB rhs = ((LabelColorRGB) other);
        return new EqualsBuilder().append(red, rhs.red).append(green, rhs.green).append(blue, rhs.blue).isEquals();
    }

}
