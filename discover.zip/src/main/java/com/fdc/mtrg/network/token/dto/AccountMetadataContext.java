
package com.fdc.mtrg.network.token.dto;

import java.io.Serializable;
import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "cardType",
    "productDescription",
    "cardImageId",
    "panSuffix",
    "newPanExpiry",
    "tokenSuffix"
})
public class AccountMetadataContext implements Serializable
{
    private final static long serialVersionUID = -718005486976812630L;

    @JsonProperty("cardType")
    private String cardType;
    @JsonProperty("productDescription")
    private String productDescription;
    @JsonProperty("cardImageId")
    private String cardImageId;
    @JsonProperty("panSuffix")
    private String panSuffix;
    @JsonProperty("newPanExpiry")
    private String newPanExpiry;
    @JsonProperty("tokenSuffix")
    private String tokenSuffix;

    public String getCardType() {
        return cardType;
    }

    public void setCardType(String cardType) {
        this.cardType = cardType;
    }

    public String getProductDescription() {
        return productDescription;
    }

    public void setProductDescription(String productDescription) {
        this.productDescription = productDescription;
    }

    public String getCardImageId() {
        return cardImageId;
    }

    public void setCardImageId(String cardImageId) {
        this.cardImageId = cardImageId;
    }

    public String getPanSuffix() {
        return panSuffix;
    }

    public void setPanSuffix(String panSuffix) {
        this.panSuffix = panSuffix;
    }

    public String getNewPanExpiry() {
        return newPanExpiry;
    }

    public void setNewPanExpiry(String newPanExpiry) {
        this.newPanExpiry = newPanExpiry;
    }

    public String getTokenSuffix() {
        return tokenSuffix;
    }

    public void setTokenSuffix(String tokenSuffix) {
        this.tokenSuffix = tokenSuffix;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        AccountMetadataContext that = (AccountMetadataContext) o;
        return Objects.equals(cardType, that.cardType) &&
                Objects.equals(productDescription, that.productDescription) &&
                Objects.equals(cardImageId, that.cardImageId) &&
                Objects.equals(panSuffix, that.panSuffix) &&
                Objects.equals(newPanExpiry, that.newPanExpiry) &&
                Objects.equals(tokenSuffix, that.tokenSuffix);
    }

    @Override
    public int hashCode() {
        return Objects.hash(cardType, productDescription, cardImageId, panSuffix, newPanExpiry, tokenSuffix);
    }

    @Override
    public String toString() {
        return "AccountMetadataContext{" +
                "cardType='" + cardType + '\'' +
                ", productDescription='" + productDescription + '\'' +
                ", cardImageId='" + cardImageId + '\'' +
                ", panSuffix='" + panSuffix + '\'' +
                ", newPanExpiry='" + newPanExpiry + '\'' +
                ", tokenSuffix='" + tokenSuffix + '\'' +
                '}';
    }
}
