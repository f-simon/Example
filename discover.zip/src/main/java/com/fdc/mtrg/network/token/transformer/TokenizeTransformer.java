package com.fdc.mtrg.network.token.transformer;

import brave.Span;
import brave.Tracer;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fdc.mtrg.api.*;
import com.fdc.mtrg.network.token.dto.*;
import com.fdc.mtrg.network.token.error.ApplicationError;
import com.fdc.mtrg.network.token.util.Constants;
import com.fdc.util.exception.FdcException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.expression.spel.ast.OpPlus;
import org.springframework.integration.annotation.Transformer;
import org.springframework.messaging.Message;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.stereotype.Service;

import java.util.Optional;
import java.util.UUID;

@Service
public class TokenizeTransformer {
    private static final Logger logger = LoggerFactory.getLogger(TokenizeTransformer.class);

    @Autowired
    protected ObjectMapper objectMapper;

    @Autowired
    private Tracer tracer;

    @Transformer
    public ProvisionedTokenRequestDDX doTransformRequest(@Header(Constants.MERCHANT_ID) final String pmerchantId,
                                                         Message<ProvisionTokenRequest> pRequestMessage) throws FdcException, JsonProcessingException {

        logger.debug("Request received @ doTransform API for merchant Partner {} and request {} ",
                pmerchantId, objectMapper.writeValueAsString(pRequestMessage.getPayload()));

        ProvisionedTokenRequestDDX tokenRequestTsp = new ProvisionedTokenRequestDDX();

        RequestHeader requestHeader = new RequestHeader();
        UserContext userContext = new UserContext();
        UserProvisionContext userProvisionContext = new UserProvisionContext();
        EncryptedContextRequest encryptedContextRequest = new EncryptedContextRequest();
        SecureContext secureContext = new SecureContext();

        ProvisionTokenRequest payload = pRequestMessage.getPayload();

        AccountProvisionRequest accountProvisionRequest = new AccountProvisionRequest();

        //Required fields:

        Optional.ofNullable(tracer).map(Tracer::currentSpan).map(Span::context)
                .ifPresent(traceId -> {
                    String requestId = traceId.toString().replace("/", "");
                    requestHeader.setRequestId(requestId);
                });

        requestHeader.setSessionId(UUID.randomUUID().toString());
        requestHeader.setProgramId(Constants.PROGRAM_ID);

        userContext.setWalletId(pmerchantId);
        userContext.setUserId(UUID.randomUUID().toString());
        requestHeader.setUserContext(userContext);

        // encryption part

        //  secureContext.setEncryptedContent();    // will populate with encrypted data form EncryptedContext

        Optional<String> pan = Optional.ofNullable(payload.getProvision().getCard().getCardNumber());
        if (pan.isPresent()) encryptedContextRequest.setPan(pan.get());

        ExpiryDate expiryDate = new ExpiryDate();
        Optional<String> month = Optional.ofNullable(payload.getProvision().getCard().getExpiryDate().getMonth());
        Optional<String> year = Optional.ofNullable(payload.getProvision().getCard().getExpiryDate().getYear());

        if (month.isPresent() && year.isPresent()) {
            encryptedContextRequest.setExpDate(month.get() + year.get());
        }

        Optional<String> nameOnCard = Optional.ofNullable(payload.getProvision().getCard().getNameOnCard());
        if (nameOnCard.isPresent()) encryptedContextRequest.setCardHolderName(nameOnCard.get());

        Optional<String> billingAdr = Optional.ofNullable(payload.getProvision().getCard().getBillingAddress().getStreetAddress());
        if (billingAdr.isPresent()) encryptedContextRequest.setBillingAddr(billingAdr.get());

        Optional<String> postalCode = Optional.ofNullable(payload.getProvision().getCard().getBillingAddress().getPostalCode());
        if (postalCode.isPresent()) encryptedContextRequest.setBillingZip(postalCode.get());

        Optional<Enum> source = Optional.ofNullable(payload.getProvision().getCard().getSource());
        if (source.isPresent()) encryptedContextRequest.setSource(CardSource.ON_FILE.getValue().substring(8));
//end secure

        //   Optional<String> local = Optional.ofNullable(payload.getProvision().getLocale());
        //    if(local.isPresent()) accountProvisionRequest.


        Optional<String> emailAddress = Optional.ofNullable(payload.getProvision().getAccount().getEmail().getValue());
        if (emailAddress.isPresent()) userProvisionContext.setEmailAddress(emailAddress.get());

        DeviceDetails deviceDetails = new DeviceDetails();
        DeviceDetailsLoaction deviceDetailsLoaction = new DeviceDetailsLoaction();
        DeviceLookUpContext deviceLookUpContext = new DeviceLookUpContext();
        DeviceContext deviceContext = new DeviceContext();
        deviceContext.setDeviceType("1");

        Optional<String> ip = Optional.ofNullable(payload.getProvision().getDeviceDetails().getLoaction().getIpAddress());
        if(ip.isPresent())deviceContext.setDeviceIp(ip.get());

        Optional<String> latitude = Optional.ofNullable(payload.getProvision().getDeviceDetails().getLoaction().getLatitude());
        if(latitude.isPresent())deviceLookUpContext.setLatitude(latitude.get());

        Optional<String> longitude = Optional.ofNullable(payload.getProvision().getDeviceDetails().getLoaction().getLongitude());
        if(longitude.isPresent())deviceLookUpContext.setLongitude(longitude.get());

         deviceContext.setDeviceLookUpContext(deviceLookUpContext);

        Optional<String> deviceScore = Optional.ofNullable(payload.getProvision().getDeviceDetails().getDeviceScore());
        if(deviceScore.isPresent())deviceDetails.setDeviceScore(deviceScore.get());

        Optional<String> accountScore = Optional.ofNullable(payload.getProvision().getDeviceDetails().getAccountScore());
        if(accountScore.isPresent())deviceDetails.setDeviceScore(accountScore.get());


        RiskContext riskContext = new RiskContext();
        riskContext.setAccountRisk("4");
        riskContext.setDeviceRisk("4");

        requestHeader.setUserContext(userContext);

        secureContext.setEncryptedContent(encryptedContextRequest);

        accountProvisionRequest.setSecureContext(secureContext);
        accountProvisionRequest.setDeviceContext(deviceContext);
        accountProvisionRequest.setRiskContext(riskContext);
        accountProvisionRequest.setUserProvisionContext(userProvisionContext);

        tokenRequestTsp.setRequestHeader(requestHeader);
        tokenRequestTsp.setAccountProvisionRequest(accountProvisionRequest);

        logger.info("tokenRequest -- ()", tokenRequestTsp);
        return tokenRequestTsp;
    }

    @Transformer
    public ProvisionTokenResponse doTransformResponse(@Header(Constants.MERCHANT_ID) final String pmerchantId,
                                                      ProvisionedTokenResponseDDX pRequestMessage) throws FdcException {

        ProvisionTokenResponse response = new ProvisionTokenResponse();
        try {
            logger.debug("Request received @ doReplyTransform API for merchant Partner {} and request {} ",
                    pmerchantId, objectMapper.writeValueAsString(pRequestMessage));

            Provision provision = new Provision();
            populate(provision, pRequestMessage);

            response.setProvision(provision);
        } catch (JsonProcessingException ex) {
            logger.error(ex.getMessage(), ex);
            throw new FdcException(ApplicationError.INVALID_REQUEST.getErrorCode(),
                    ApplicationError.INVALID_REQUEST.getErrorDescription());

        }
        return response;
    }


    private void populate(Provision provision, ProvisionedTokenResponseDDX response) {
        TokenInfo tokenInfo = new TokenInfo();
        Card card = new Card();
        Token token = new Token();
        Account account = new Account();

        if (null != response.getAccountProvisionResponse()) {
            Optional.ofNullable(tracer).map(Tracer::currentSpan).map(Span::context).ifPresent(traceId -> provision.setTransactionId(traceId.toString()));

     //       if (null != response.getAccountProvisionResponse().getEncryptedContext()) {
                Optional<String> newPanExpiry = Optional.ofNullable(response.getAccountProvisionResponse().getAccountMetadataContext().getNewPanExpiry());

                if (newPanExpiry.isPresent()) {
                    ExpiryDate expiryDate = new ExpiryDate();
                    String month = newPanExpiry.get().substring(0, 2);
                    String year = newPanExpiry.get().substring(2, 4);
                    expiryDate.setMonth(month);
                    expiryDate.setYear(year);
                    card.setExpiryDate(expiryDate);
                }

            if(null !=  response.getAccountProvisionResponse().getProvisioningMetadata()){
                Optional<String> tokenId = Optional.ofNullable(response.getAccountProvisionResponse().getProvisioningMetadata().getTokenId());
                if(tokenId.isPresent())token.setTokenReferenceId(tokenId.get());

                Optional<String> panId = Optional.ofNullable(response.getAccountProvisionResponse().getProvisioningMetadata().getPanId());
                if(panId.isPresent()) {
                    token.setPaymentAccountReferenceId(panId.get());
                    token.setPaymentToken(panId.get());
                }

                Optional<String> tokenExpire = Optional.ofNullable(response.getAccountProvisionResponse().getAccountMetadataContext().getNewPanExpiry());

                if (tokenExpire.isPresent()) {
                    ExpiryDate expiryDate = new ExpiryDate();
                    String month = tokenExpire.get().substring(0, 2);
                    String year = tokenExpire.get().substring(2, 4);
                    expiryDate.setMonth(month);
                    expiryDate.setYear(year);
                    token.setExpiryDate(expiryDate);
                }

                Optional<String> tokenSuffix = Optional.ofNullable(response.getAccountProvisionResponse().getAccountMetadataContext().getTokenSuffix());
                if(tokenSuffix.isPresent()) token.setAlias(tokenSuffix.get());

            }

            if (null != response.getAccountProvisionResponse().getAccountMetadataContext()) {
                Optional<String> panSuffix = Optional.ofNullable(response.getAccountProvisionResponse().getAccountMetadataContext().getPanSuffix());
                if (panSuffix.isPresent()) card.setAlias(panSuffix.get());

                Optional<String> cardImageId = Optional.ofNullable(response.getAccountProvisionResponse().getAccountMetadataContext().getCardImageId());
                if (cardImageId.isPresent()) card.setCardBrandLogoAssetId(cardImageId.get());

                Optional<String> productDescription = Optional.ofNullable(response.getAccountProvisionResponse().getAccountMetadataContext().getProductDescription());
                if (productDescription.isPresent()) card.setCardBrandDescription(productDescription.get());

                Optional<String> provisionDecision = Optional.ofNullable(response.getAccountProvisionResponse().getProvisioningDecision());
                if (provisionDecision.isPresent()) {
                    if (provisionDecision.get().equalsIgnoreCase(TokenStatus.APPROVED.getValue())) {
                        tokenInfo.setDecision(TokenStatus.APPROVED);
                    } else if (provisionDecision.get().equalsIgnoreCase(TokenStatus.DECLINED.getValue())) {
                        tokenInfo.setDecision(TokenStatus.DECLINED);
                    }
                }


            }

            token.setTspId(TSPID.DISCOVER.getValue());
        }

        provision.setCard(card);
        tokenInfo.setToken(token);
        provision.setTokenInfo(tokenInfo);
        provision.setAccount(account);
    }
}
