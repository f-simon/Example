package com.fdc.mtrg.network.token.dto.healthcheck;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fdc.mtrg.network.token.dto.ResponseHeader;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class HeathcheckResponseDDX {

    @JsonProperty("responseHeader")
    private ResponseHeader responseHeader;

    @JsonProperty("healthCheckResponse")
    private HealthCheckResponse healthCheckResponse;

    public ResponseHeader getResponseHeader() {
        return responseHeader;
    }

    public void setResponseHeader(ResponseHeader responseHeader) {
        this.responseHeader = responseHeader;
    }

    public HealthCheckResponse getHealthCheckResponse() {
        return healthCheckResponse;
    }

    public void setHealthCheckResponse(HealthCheckResponse healthCheckResponse) {
        this.healthCheckResponse = healthCheckResponse;
    }
}
