package com.fdc.mtrg.network.token.config.interceptor;

import com.fdc.mtrg.network.token.config.ApplicationProperties;
import com.fdc.mtrg.network.token.dto.AccessToken;
import com.fdc.mtrg.network.token.dto.AccessTokenResponse;
import com.fdc.mtrg.network.token.service.AccessTokenService;
import com.fdc.mtrg.network.token.util.Constants;
import com.fdc.mtrg.network.token.util.Timer;
import com.fdc.util.exception.FdcException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.io.Serializable;

public class AccessTokenAuthInterceptor implements ClientHttpRequestInterceptor, Serializable {

    private static final Logger logger = LoggerFactory.getLogger(AccessTokenAuthInterceptor.class);

    private ApplicationProperties applicationProperties;

    public AccessTokenAuthInterceptor(final ApplicationProperties applicationProperties){
        this.applicationProperties = applicationProperties;
    }

    @Override
    public ClientHttpResponse intercept(HttpRequest httpRequest, byte[] body, ClientHttpRequestExecution clientHttpRequestExecution) throws IOException {

        AccessToken accessToken;
        Timer timer;
        Boolean isValid = false;
        accessToken = new AccessToken();
        timer = new Timer();

        AccessTokenService accessTokenService = new AccessTokenService(applicationProperties);

        if (timer.getTotalTime() < accessToken.getExpireMillis()) {
            isValid = true;
        }

        try {
            if (accessTokenService != null) {
                if (!isValid) timer.start();

                if (!isValid) {
                    timer.end();
                    setBearToken(accessToken, accessTokenService.accessToken(), isValid);
                    setHeader(accessToken, httpRequest);
                    isValid = true;
                } else {
                    setHeader(accessToken, httpRequest);
                }
                return clientHttpRequestExecution.execute(httpRequest, body);
            }
        } catch (FdcException ex) {
            logger.error(ex.getMessage(), ex);
            throw new IOException(ex);
        }
        return null;
    }

    public void setBearToken(AccessToken accessToken, AccessTokenResponse accessTokenResponse, Boolean isValid) {

        StringBuilder sb = new StringBuilder();
        accessToken.setTokenType(accessTokenResponse.getTokenType());
        accessToken.setAccessToken(accessTokenResponse.getAccessToken());
        accessToken.setExpireMillis(accessTokenResponse.getExpiresIn() * 1000l);

        sb.append(accessTokenResponse.getTokenType()).append(" ").append(accessTokenResponse.getAccessToken());
        logger.info("Access Token {}  isValid {} ", sb.toString(), isValid);

    }

    public void setHeader(AccessToken accessToken, HttpRequest httpRequest) {
        httpRequest.getHeaders().add(Constants.PROVTOKEN_HEAD_AUTH, accessToken.getBearerToken());
    }
}




