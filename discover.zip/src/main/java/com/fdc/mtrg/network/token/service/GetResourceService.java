package com.fdc.mtrg.network.token.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fdc.mtrg.network.token.config.ApplicationProperties;
import com.fdc.mtrg.network.token.dto.GetAssetResponseDDX;
import com.fdc.mtrg.network.token.error.ApplicationError;
import com.fdc.mtrg.network.token.util.Constants;
import com.fdc.util.exception.FdcException;
import com.fdc.util.exception.FdcRuntimeException;
import com.fdc.util.logging.SimpleAroundLog;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.integration.annotation.ServiceActivator;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

@Service
public class GetResourceService {

    private static final Logger logger = LoggerFactory.getLogger(GetResourceService.class);

    @Autowired
    private ApplicationProperties appProps;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    @Qualifier("discoverRestTemplate")
    protected RestTemplate restTemplate;

    static int attempts;

    @SimpleAroundLog
    @ServiceActivator
    @HystrixCommand(commandKey = "ddx-getResource-command", threadPoolKey = "ddx-getResource-thread-pool", ignoreExceptions = FdcRuntimeException.class)
    public GetAssetResponseDDX getResource(@Header(Constants.PROGRAM_ID) String programId,
                    @Header(Constants.RESOURCE_UUID) String resourceUUID,
                    @Header(Constants.REQUEST_ID) String requestId,
                    @Header(Constants.MERCHANT_ID) final String merchantId) throws FdcException {

        GetAssetResponseDDX result = null;
        try {
            HttpEntity<String> getAssetRequest = new HttpEntity<String>(getHttpHeaders());
            result = restTemplate.exchange(getUri(Constants.DDX_RESOURCE_PATH, programId, resourceUUID, requestId),
                    HttpMethod.GET,
                    getAssetRequest,
                    GetAssetResponseDDX.class).getBody();

        } catch (RestClientException rce) {
            if (rce instanceof HttpClientErrorException) {
                HttpClientErrorException hcee = (HttpClientErrorException) rce;
                if (hcee.getStatusCode() == HttpStatus.UNAUTHORIZED) {
                    if (attempts < 1) {
                        attempts++;
                        getResource(programId, resourceUUID, requestId, merchantId);
                    }
                } else {
                    logger.error(hcee.getMessage(), hcee);
                    throw new FdcException(ApplicationError.AUTHORIZATION_FAILED.getErrorCode(), ApplicationError.AUTHORIZATION_FAILED.getErrorDescription());
                }
            }

        } catch (Exception hcee) {
            logger.error(hcee.getMessage(), hcee);
            throw new FdcException(ApplicationError.AUTHORIZATION_FAILED.getErrorCode(), ApplicationError.AUTHORIZATION_FAILED.getErrorDescription());
        }

        if (result == null) {
            logger.error("Getting null response from Discover for Tokenization API");
            throw new FdcException(ApplicationError.SERVICE_UNAVAILABLE.getErrorCode(), ApplicationError.SERVICE_UNAVAILABLE.getErrorDescription());
        }
        return result;
    }

    public String getUri(String path, String programId, String resourceUUID,String requestId) {
        final StringBuilder sb = new StringBuilder(appProps.getServiceUrl());
        sb.append(path);
        String endpoint = String.format("/%s/%s/%s", programId, resourceUUID, requestId);
        sb.append(endpoint);
        logger.info("Outbound Url {} ", sb.toString());
        return sb.toString();
    }

    public HttpHeaders getHttpHeaders() {
        final HttpHeaders headers = new HttpHeaders();
        headers.set(Constants.ACCCEPT, Constants.CONTENT_TYPE_JSON);
        headers.set(Constants.PROVTOKEN_HEAD_CACHE_CONTROL, Constants.PROVTOKEN_HEAD_CACHE_CONTROL_VALUE);
        headers.set(Constants.PROVTOKEN_HEAD_X_DFS_C_APP_CERT, Constants.PROVTOKEN_HEAD_X_DFS_C_APP_CERT_VALUE);
        headers.set(Constants.PROVTOKEN_HEAD_X_DFS_API_PLAN, Constants.PROVTOKEN_HEAD_X_DFS_API_PLAN_VALUE);

        return headers;
    }
}
