
package com.fdc.mtrg.network.token.dto;

import java.io.Serializable;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "language",
    "latitude",
    "longitude",
    "nameMismatch"
})
public class DeviceLookUpContext implements Serializable
{

    @JsonProperty("language")
    private String language;
    @JsonProperty("latitude")
    private String latitude;
    @JsonProperty("longitude")
    private String longitude;
    @JsonProperty("nameMismatch")
    private String nameMismatch;
    private final static long serialVersionUID = 8873222544850844189L;

    @JsonProperty("language")
    public String getLanguage() {
        return language;
    }

    @JsonProperty("language")
    public void setLanguage(String language) {
        this.language = language;
    }

    @JsonProperty("latitude")
    public String getLatitude() {
        return latitude;
    }

    @JsonProperty("latitude")
    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    @JsonProperty("longitude")
    public String getLongitude() {
        return longitude;
    }

    @JsonProperty("longitude")
    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    @JsonProperty("nameMismatch")
    public String getNameMismatch() {
        return nameMismatch;
    }

    @JsonProperty("nameMismatch")
    public void setNameMismatch(String nameMismatch) {
        this.nameMismatch = nameMismatch;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("language", language).append("latitude", latitude).append("longitude", longitude).append("nameMismatch", nameMismatch).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(language).append(nameMismatch).append(latitude).append(longitude).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof DeviceLookUpContext) == false) {
            return false;
        }
        DeviceLookUpContext rhs = ((DeviceLookUpContext) other);
        return new EqualsBuilder().append(language, rhs.language).append(nameMismatch, rhs.nameMismatch).append(latitude, rhs.latitude).append(longitude, rhs.longitude).isEquals();
    }

}
