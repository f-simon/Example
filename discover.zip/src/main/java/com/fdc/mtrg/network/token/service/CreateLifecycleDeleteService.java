package com.fdc.mtrg.network.token.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fdc.mtrg.network.token.config.ApplicationProperties;
import com.fdc.mtrg.network.token.dto.UpdateTokensRequestsDDX;
import com.fdc.mtrg.network.token.dto.UpdateTokensResponseDDX;
import com.fdc.mtrg.network.token.error.ApplicationError;
import com.fdc.mtrg.network.token.error.Error;
import com.fdc.mtrg.network.token.error.HeadLevelError;
import com.fdc.mtrg.network.token.util.Constants;
import com.fdc.util.exception.FdcException;
import com.fdc.util.exception.FdcRuntimeException;
import com.fdc.util.exception.model.NVP;
import com.fdc.util.exception.types.FdcSystemException;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.*;
import org.springframework.integration.annotation.ServiceActivator;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.stereotype.Service;
import org.springframework.validation.FieldError;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;


@Service
public class CreateLifecycleDeleteService {
    private static final Logger logger = LoggerFactory.getLogger(CreateLifecycleDeleteService.class);

    @Autowired
    protected ObjectMapper objectMapper;

    @Autowired
    private ApplicationProperties applicationProperties;

    @Autowired
    @Qualifier("discoverRestTemplate")
    private RestTemplate restTemplate;

    @Autowired
    private HttpServletRequest httpRequest;

    static int attempts;  // three attempts should be good : for now it is 1

    @ServiceActivator
 //   @HystrixCommand(commandKey = "mc-deleteService-command", threadPoolKey = "mc-deleteService-thread-pool", ignoreExceptions = FdcRuntimeException.class)
    public UpdateTokensResponseDDX doOutboundServiceCall(@Header(Constants.MERCHANT_ID) final String merchantId,
                                            @Header(Constants.PROVISION_TOKEN_ID) final String vProvisionedTokenId,
                                            UpdateTokensRequestsDDX lifeCycleMessage) throws FdcSystemException, FdcException, JsonProcessingException {

        logger.debug("Request received @ doOutboundServiceCall API for merchant Action {} and request {} ", merchantId, lifeCycleMessage);

        HttpEntity<UpdateTokensRequestsDDX> supendRequestEntity = new HttpEntity<UpdateTokensRequestsDDX>(lifeCycleMessage, getHttpHeaders());

        UpdateTokensResponseDDX responsePayload = null;

        String path = Constants.DDX_LIFECYCLE_PATH;
        Optional<String> notification = Optional.ofNullable(httpRequest.getQueryString());
        if(notification.isPresent()) path =  Constants.DDX_LIFECYCLE_PATH_MPP;

        try {
            responsePayload = this.restTemplate.exchange(getUri(path),
                    HttpMethod.POST,
                    supendRequestEntity, UpdateTokensResponseDDX.class).getBody();

        } catch (HttpClientErrorException hcee) {

            if (hcee.getStatusCode() == HttpStatus.UNAUTHORIZED) {
                if (attempts < 1) {
                    attempts++;
                    doOutboundServiceCall(merchantId, vProvisionedTokenId, lifeCycleMessage);

                } else {
                    logger.error(hcee.getMessage(), hcee);
                    throw new FdcException(ApplicationError.AUTHORIZATION_FAILED.getErrorCode(), ApplicationError.AUTHORIZATION_FAILED.getErrorDescription());
                }
            } else if (hcee.getStatusCode() == HttpStatus.BAD_REQUEST) {
                handleException(hcee.getResponseBodyAsString());
            } else if (hcee.getStatusCode() == HttpStatus.FORBIDDEN){
                logger.error(hcee.getMessage(), hcee);
                throw new FdcException(ApplicationError.AUTHORIZATION_FAILED.getErrorCode(), ApplicationError.AUTHORIZATION_FAILED.getErrorDescription());
            } else {
                logger.error(hcee.getMessage(), hcee);
                throw new FdcSystemException(ApplicationError.SERVICE_UNAVAILABLE.getErrorCode(), ApplicationError.SERVICE_UNAVAILABLE.getErrorDescription());
            }
        }catch (final RestClientException rce){
            logger.error(rce.getMessage(), rce);
            throw new FdcSystemException(ApplicationError.SERVICE_UNAVAILABLE.getErrorCode(), ApplicationError.SERVICE_UNAVAILABLE.getErrorDescription());
        }
        if (responsePayload == null) {
            logger.error("Getting null response from discover Adapter for suspend API");
            throw new FdcSystemException(ApplicationError.SERVICE_UNAVAILABLE.getErrorCode(), ApplicationError.SERVICE_UNAVAILABLE.getErrorDescription());
        }
        return responsePayload;
    }

    private HttpHeaders getHttpHeaders() {
        final HttpHeaders headers = new HttpHeaders();
        headers.set(Constants.ACCCEPT, Constants.CONTENT_TYPE_JSON);
        headers.set(Constants.CONTENT_TYPE, Constants.APPLICATION_JSON);
        headers.set(Constants.LC_CACHE_CONTROL, Constants.LC_CACHE_CONTROL_VALUE);
        headers.set(Constants.PROVTOKEN_HEAD_X_DFS_C_APP_CERT, Constants.PROVTOKEN_HEAD_X_DFS_C_APP_CERT_VALUE);
        headers.set(Constants.PROVTOKEN_HEAD_X_DFS_API_PLAN, Constants.PROVTOKEN_HEAD_X_DFS_API_PLAN_VALUE);

        return headers;
    }

    // https://apis.discover.com/nws/nwp/cof/v2/wallet/account/lifecycle
    public String getUri(String path) {
        final StringBuilder sb = new StringBuilder(applicationProperties.getServiceUrl());
        sb.append(path);
        logger.info("Outbound Url {} ", sb.toString());
        return sb.toString();
    }

    public void handleException(String responseBodyAsString) throws FdcException{
        try {
            HeadLevelError headLevelError = new HeadLevelError();
            objectMapper = new ObjectMapper();

            headLevelError = objectMapper.readValue(responseBodyAsString, HeadLevelError.class);

            // com.fdc.mtrg.network.token.error.Error  -- to avoid error with dto.Error
            Optional<List<Error>> headError = Optional.ofNullable(headLevelError.getResponseHeader().getErrors());
            if(headError.isPresent()){
                List<FieldError> fieldErrors = new ArrayList<>();
                for(Error error: headError.get()){
                    fieldErrors.add(new FieldError("LifeCycle", error.getErrorCode(), error.getErrorMessage()));
                }

                List<NVP> nvps = new ArrayList<>();

                // programId, responseId, and sessionId are not in array -- they are separate fields
                Optional<String> programId =  Optional.ofNullable(headLevelError.getResponseHeader().getProgramId());
                if(programId.isPresent()){
                    NVP nvp = new NVP();
                    nvp.setName("programId");
                    nvp.setValue(programId.get());
                    nvps.add(nvp);
                }

                Optional<String> responseId =  Optional.ofNullable(headLevelError.getResponseHeader().getResponseId());
                if(responseId.isPresent()){
                    NVP nvp = new NVP();
                    nvp.setName("responseId");
                    nvp.setValue(responseId.get());
                    nvps.add(nvp);
                }

                Optional<String> sessionId =  Optional.ofNullable(headLevelError.getResponseHeader().getSessionId());
                if(sessionId.isPresent()){
                    NVP nvp = new NVP();
                    nvp.setName("sessionId");
                    nvp.setValue(sessionId.get());
                    nvps.add(nvp);
                }

                throw new FdcException(ApplicationError.INVALID_REQUEST.getErrorCode(), ApplicationError.INVALID_REQUEST.getErrorDescription(), fieldErrors,
                        ApplicationError.INVALID_REQUEST.getErrorDescription(), nvps);
            }

        } catch (JsonProcessingException e) {
            logger.error(e.getMessage(), e);
            throw new FdcException(ApplicationError.INVALID_REQUEST.getStatusCode(), ApplicationError.INVALID_REQUEST.getErrorDescription());
        }
    }

}
