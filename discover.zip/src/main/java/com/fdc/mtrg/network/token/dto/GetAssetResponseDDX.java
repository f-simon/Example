
package com.fdc.mtrg.network.token.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "responseHeader",
    "resourceResponse"
})
public class GetAssetResponseDDX {

    @JsonProperty("responseHeader")
    private GetAssetResponseHeader responseHeader;
    @JsonProperty("resourceResponse")
    private ResourceResponse resourceResponse;

    public GetAssetResponseHeader getResponseHeader() {
        return responseHeader;
    }

    public void setResponseHeader(GetAssetResponseHeader responseHeader) {
        this.responseHeader = responseHeader;
    }

    public ResourceResponse getResourceResponse() {
        return resourceResponse;
    }

    public void setResourceResponse(ResourceResponse resourceResponse) {
        this.resourceResponse = resourceResponse;
    }

}
