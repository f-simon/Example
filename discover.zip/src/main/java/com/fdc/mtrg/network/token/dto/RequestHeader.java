
package com.fdc.mtrg.network.token.dto;

import java.io.Serializable;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "requestId",
    "sessionId",
    "programId",
    "userContext"
})
public class RequestHeader implements Serializable
{

    @JsonProperty("requestId")
    private String requestId;
    @JsonProperty("sessionId")
    private String sessionId;
    @JsonProperty("programId")
    private String programId;
    @JsonProperty("userContext")
    private UserContext userContext;
    private final static long serialVersionUID = -1095662305132166027L;

    @JsonProperty("requestId")
    public String getRequestId() {
        return requestId;
    }

    @JsonProperty("requestId")
    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    @JsonProperty("sessionId")
    public String getSessionId() {
        return sessionId;
    }

    @JsonProperty("sessionId")
    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }

    @JsonProperty("programId")
    public String getProgramId() {
        return programId;
    }

    @JsonProperty("programId")
    public void setProgramId(String programId) {
        this.programId = programId;
    }

    @JsonProperty("userContext")
    public UserContext getUserContext() {
        return userContext;
    }

    @JsonProperty("userContext")
    public void setUserContext(UserContext userContext) {
        this.userContext = userContext;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("requestId", requestId).append("sessionId", sessionId).append("programId", programId).append("userContext", userContext).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(sessionId).append(userContext).append(requestId).append(programId).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof RequestHeader) == false) {
            return false;
        }
        RequestHeader rhs = ((RequestHeader) other);
        return new EqualsBuilder().append(sessionId, rhs.sessionId).append(userContext, rhs.userContext).append(requestId, rhs.requestId).append(programId, rhs.programId).isEquals();
    }

}
