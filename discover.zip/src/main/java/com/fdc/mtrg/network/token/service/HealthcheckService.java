package com.fdc.mtrg.network.token.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fdc.mtrg.network.token.dto.healthcheck.HeathcheckResponseDDX;
import com.fdc.mtrg.network.token.error.ApplicationError;
import com.fdc.mtrg.network.token.util.Constants;
import com.fdc.util.exception.FdcException;
import com.fdc.util.exception.FdcRuntimeException;
import com.fdc.util.exception.types.FdcSystemException;
import com.fdc.util.logging.SimpleAroundLog;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.integration.annotation.ServiceActivator;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;

@Service
public class HealthcheckService extends NetworkTokensService {
    private static final Logger logger = LoggerFactory.getLogger(HealthcheckService.class);

    @SimpleAroundLog
    @ServiceActivator
    @HystrixCommand(commandKey = "healthcheck-command", threadPoolKey = "healthcheck-thread-pool", ignoreExceptions = FdcRuntimeException.class)
    public HeathcheckResponseDDX healthcheck(@Header(Constants.MERCHANT_ID) final String merchantId,
                                             @Header(Constants.REQUEST_ID) final String requestId,
                                             @Header(Constants.PROGRAM_ID) final String programId) throws FdcSystemException, FdcException {

        HeathcheckResponseDDX connectionResponse = null;
        try {
            HttpEntity<String> healthcheckRequest = new HttpEntity<>(getHttpHeaders());
            String url = appProps.getServiceUrl() + String.format(Constants.HEALTHCHECK_URI, programId, requestId);
            connectionResponse = this.restTemplate.exchange(url, HttpMethod.GET, healthcheckRequest, HeathcheckResponseDDX.class).getBody();
        } catch (HttpClientErrorException ie) {
            logger.error(ie.getMessage(), ie);
            try {
                connectionResponse = objectMapper.readValue(ie.getResponseBodyAsString(), HeathcheckResponseDDX.class);
            } catch (JsonProcessingException jpe) {
                throw new FdcException(ApplicationError.TOKENIZATION_FAILED.getErrorCode(), ApplicationError.TOKENIZATION_FAILED.getErrorDescription());
            }
            handleException(connectionResponse.getResponseHeader());
     }
        return connectionResponse;
    }
}
