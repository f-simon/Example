package com.fdc.mtrg.network.token.config.interceptor;

import com.fdc.mtrg.network.token.config.ApplicationProperties;
import com.fdc.mtrg.network.token.dto.ProvisionedTokenRequestDDX;
import com.fdc.mtrg.network.token.dto.ProvisionedTokenResponseDDX;
import org.jose4j.jwa.AlgorithmConstraints;
import org.jose4j.jwa.AlgorithmConstraints.ConstraintType;
import org.jose4j.jwe.ContentEncryptionAlgorithmIdentifiers;
import org.jose4j.jwe.JsonWebEncryption;
import org.jose4j.jwe.KeyManagementAlgorithmIdentifiers;
import org.jose4j.jwk.JsonWebKey;
import org.jose4j.lang.JoseException;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpRequest;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;

import javax.crypto.spec.SecretKeySpec;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.*;
import java.security.cert.Certificate;
import java.util.Base64;

public class JWTEncryptDecryptInterceptor  implements ClientHttpRequestInterceptor {

    private static final Logger logger = LoggerFactory.getLogger(JWTEncryptDecryptInterceptor.class);

    private ApplicationProperties appProps;

//    @Autowired
//    @Qualifier("encryptionCertificate")

    protected Certificate encryptionCertificate;

    public JWTEncryptDecryptInterceptor(ApplicationProperties appProps, Certificate encryptionCertificate) {
        this.appProps = appProps;
        this.encryptionCertificate = encryptionCertificate;
    }

    JsonWebKey jsonWebKey = null;

    @Override
    public ClientHttpResponse intercept(HttpRequest httpRequest, byte[] body, ClientHttpRequestExecution clientHttpRequestExecution) throws IOException {

        ClientHttpResponse clientHttpResponse;
        byte[] provisionedTokenRequest = null;

        ProvisionedTokenResponseDDX provisionedTokenResponseDDX = null;
        ProvisionedTokenRequestDDX provisionedTokenRequestDDX = null;
        byte[] provisionedTokenResponse = null;

        try {
            provisionedTokenRequest = processEncryptedContext(body, ProvisionedTokenRequestDDX.class);

            clientHttpResponse = clientHttpRequestExecution.execute(httpRequest, provisionedTokenRequest);

            long len = clientHttpResponse.getHeaders().getContentLength();
            int status =  clientHttpResponse.getStatusCode().value();

         //   byte[] decryPart = clientHttpResponse.getBody().toString().getBytes("UTF-8");

            if(status == 200 && len > 0){
                byte[] decryPart = clientHttpResponse.getBody().toString().getBytes("UTF-8");
                provisionedTokenResponse = processEncryptedContext(decryPart, ProvisionedTokenResponseDDX.class);
                return clientHttpRequestExecution.execute(httpRequest, provisionedTokenResponse);
            }

    //        return clientHttpRequestExecution.execute(httpRequest, provisionedTokenResponse);

        } catch (IOException ex) {
            logger.error(ex.getMessage(), ex);
            throw new IOException(ex);
        }

        return clientHttpResponse;
    }

    public <T> byte[] processEncryptedContext(byte[] payload, Class<T> type)  {
        try {

            JSONObject originalPayload = new JSONObject(new String(payload));

            boolean isProvisionedRequest = true;

            JSONObject jObject;
            String provisionedObject = type.getName();

            if (provisionedObject.contains("ProvisionedTokenRequestDDX")) {
                jObject = originalPayload.getJSONObject("accountProvisionRequest").getJSONObject("secureContext").getJSONObject("EncryptedContext");
            } else if (provisionedObject.contains("ProvisionedTokenResponsetDDX")) {
                jObject = originalPayload.getJSONObject("accountProvisionResponse").getJSONObject("secureContext").getJSONObject("EncryptedContext");
            } else {
                throw new IOException("No a valid Provisioned Object");
            }

            String encryptedContext = jObject.toString();

            byte context[] = encryptedContext.getBytes();
            String eContext = new String(context, "UTF-8");

            String encryptedPartOfPayload = null;

            if (isProvisionedRequest) {
                encryptedPartOfPayload = performEncryption(eContext);
                // TODO 2 - add encrypted string to ProvisionedTokeyRequestDDX (i.e. change JSONObject back to a byte [ ] as in the interceptor request )
                originalPayload.getJSONObject("accountProvisionRequest").getJSONObject("secureContext").put("EncryptedContext", encryptedPartOfPayload);

                // Can use the below line to test that it is decrypted
                // encryptedPartOfPayload = performDecryption(encryptedPartOfPayload);   // TODO -  Testing decryption for now
                isProvisionedRequest = false;
            } else {
                encryptedPartOfPayload = performDecryption(eContext);
                originalPayload.getJSONObject("accountProvisionResponse").getJSONObject("secureContext").put("EncryptedContext", encryptedPartOfPayload);

            }


            byte[] sendPayload = originalPayload.toString().getBytes("UTF-8");

            return sendPayload;
        } catch (JSONException | IOException ex) {
            logger.error(ex.getMessage(), ex);

        }
        return null;  // for now
    }




    String performEncryption(String partToEncrypted)  {

        SecretKeySpec aes = null;
        try {
              aes = createSecret("SHA-256");
        //    Key aes = new AesKey(ByteUtil.randomBytes(32));

              JsonWebKey jwk = JsonWebKey.Factory.newJwk(aes);
              jsonWebKey = jwk;   // store for decrypt   ------> assuming a Symmetric encryption

             // Create a new Json Web Encryption object
             JsonWebEncryption senderJwe = new JsonWebEncryption();

             // The plaintext of the JWE is the message that we want to encrypt.
             senderJwe.setPayload(partToEncrypted);

            // Encrypt payload & update headers

        /* Set the "alg" header, which indicates the key management mode for this JWE
	       and the content encryption key (CEK)
	    */
            senderJwe.setAlgorithmHeaderValue(KeyManagementAlgorithmIdentifiers.RSA_OAEP_256);

            // Set the "enc" header, which indicates the content encryption algorithm to be used.
            senderJwe.setEncryptionMethodHeaderParameter(ContentEncryptionAlgorithmIdentifiers.AES_128_CBC_HMAC_SHA_256);
            // Set the Json web key -- which is being used to encrypt the  content requires a 256 bit key.
            senderJwe.setKey(jwk.getKey());
         //   senderJwe.setKey(aes);

            senderJwe.setHeader("kid", getKIDSha256Base64Url("SHA-256"));
            senderJwe.setHeader("typ", "JWE");

            // TODO - hold for now - do not knonw if I get these for free from jose4j
            //   senderJwe.setContentEncryptionKey(getContentEncryptionKey("A128CBC-HS256").getBytes());
            //   senderJwe.setIv(getContentEncryptionIV());

            String compactSerialization = senderJwe.getCompactSerialization();
            return compactSerialization;

        } catch (Exception ex) {
            logger.error(ex.getMessage(), ex);
            logger.info("Encryption Error -- {}", ex);
        }
        return null;
    }


    //TODO
    private String performDecryption(String decrytPart) {

        try {

            JsonWebEncryption receiverJwe = new JsonWebEncryption();

            AlgorithmConstraints algConstraints = new AlgorithmConstraints(ConstraintType.WHITELIST, KeyManagementAlgorithmIdentifiers.A256KW);
            receiverJwe.setAlgorithmConstraints(algConstraints);
            AlgorithmConstraints encConstraints = new AlgorithmConstraints(ConstraintType.WHITELIST, ContentEncryptionAlgorithmIdentifiers.AES_128_CBC_HMAC_SHA_256);
            receiverJwe.setContentEncryptionAlgorithmConstraints(encConstraints);

            receiverJwe.setKey(jsonWebKey.getKey());      // assume we are using symmetric key
            receiverJwe.setCompactSerialization(decrytPart);
            return receiverJwe.getPlaintextString();
        } catch (JoseException ex) {
            logger.error(ex.getMessage(), ex);
            logger.info("Decryption Error -- {}", ex);
        }
        return null;
    }




    public MessageDigest createMessageDigest (String alg) throws NoSuchAlgorithmException {
        return MessageDigest.getInstance(alg);
    }

    public SecretKeySpec createSecret(String alg) throws NoSuchAlgorithmException, IOException, InvalidKeyException {

        MessageDigest md = createMessageDigest(alg);

        // secrete key
        byte []digest = md.digest(appProps.getSharedSecret().getBytes("UTF-8"));
        SecretKeySpec aes = new SecretKeySpec(digest, "AES");

        return aes;

    }

    public String getKIDSha256Base64Url(String alg) throws NoSuchAlgorithmException, UnsupportedEncodingException {

       return base64Url(alg);
    }

    public String base64Url(String alg) throws NoSuchAlgorithmException, UnsupportedEncodingException {
        MessageDigest md = createMessageDigest(alg);



        PublicKey publicKey = encryptionCertificate.getPublicKey();

        byte []digest = md.digest(publicKey.toString().getBytes("UTF-8"));

        // use jose4j -- instead of Java 8 versuib Base64Url
//        String base64Kid = Base64Url.encodeUtf8ByteRepresentation(digest.toString());

        // java 8
        String base64Kid =   Base64.getUrlEncoder().withoutPadding().encodeToString(digest);

        return base64Kid;
    }

    public String getContentEncryptionKey(String alg) throws NoSuchAlgorithmException, UnsupportedEncodingException {
        MessageDigest md = createMessageDigest(alg);

        byte []digest = md.digest(appProps.getApiKey().getBytes("UTF-8"));
   //     String cek = UrlBase64.encode(digest).toString();

    //    return cek;

         return "";  // for now
    }

    /* No need to Base64url encode because it will be decode by jose and and
     * and pass to setIv(byte [])
     */
    public byte[] getContentEncryptionIV() throws NoSuchAlgorithmException {
        byte[] iv = new byte[16];
        SecureRandom random = SecureRandom.getInstance("SHA1PRNG");
        random.nextBytes(iv);

       return iv;
    }

}
