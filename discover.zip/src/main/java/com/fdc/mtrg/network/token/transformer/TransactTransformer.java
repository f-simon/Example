package com.fdc.mtrg.network.token.transformer;

import brave.Tracer;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fdc.mtrg.api.CryptoGramRequest;
import com.fdc.mtrg.api.CryptoGramResponse;
import com.fdc.mtrg.network.token.config.ApplicationProperties;
import com.fdc.mtrg.network.token.dto.transact.TransactRequestDDX;
import com.fdc.mtrg.network.token.dto.transact.TransactResponseDDX;
import com.fdc.mtrg.network.token.util.Constants;
import com.fdc.util.exception.FdcException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.integration.annotation.Transformer;
import org.springframework.messaging.Message;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.stereotype.Service;

@Service
public class TransactTransformer {

    private static final Logger logger = LoggerFactory.getLogger(TransactTransformer.class);

    @Autowired
    private ApplicationProperties applicationProperties;

    @Autowired
    private Tracer tracer;

    @Transformer
    public TransactRequestDDX doTransformRequest(@Header(Constants.MERCHANT_ID) final String merchantId,
                                                 @Header(Constants.TOKEN_REFERENCE_ID) final String pTokenReferenceId,
                                                 Message<CryptoGramRequest> pRequestMessage) {
        logger.debug("Request received @ doTransform API for merchant Token reference Id {} and acquirerMerchantId {} ", pTokenReferenceId);

        TransactRequestDDX transactRequest = new TransactRequestDDX();

        return transactRequest;
    }

    @Transformer
    public CryptoGramResponse doTransformResponse(@Header(Constants.MERCHANT_ID) final String pTokenReferenceId,
                                                  TransactResponseDDX pResponseMessage) throws FdcException, JsonProcessingException {
        CryptoGramResponse returnMessage = new CryptoGramResponse();

        return returnMessage;
    }
}
