
package com.fdc.mtrg.network.token.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "media",
    "encodedResource"
})
public class Resource {

    @JsonProperty("media")
    private String media;
    @JsonProperty("encodedResource")
    private String encodedResource;
    @JsonProperty("width")
    private String width;
    @JsonProperty("height")
    private String height;

    public String getMedia() {
        return media;
    }

    public void setMedia(String media) {
        this.media = media;
    }

    public String getEncodedResource() {
        return encodedResource;
    }

    public void setEncodedResource(String encodedResource) {
        this.encodedResource = encodedResource;
    }

    public String getWidth() {
        return width;
    }

    public void setWidth(String width) {
        this.width = width;
    }

    public String getHeight() {
        return height;
    }

    public void setHeight(String height) {
        this.height = height;
    }
}
