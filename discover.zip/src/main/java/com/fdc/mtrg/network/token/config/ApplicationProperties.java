package com.fdc.mtrg.network.token.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.core.io.Resource;

@ConfigurationProperties("com.fdc.mtrg.security.discover")
public class ApplicationProperties {

    /**
     * Read timeout for the RestTemplate outbound call
     */
    private int readTimeout;

    /**
     * Connect timeout for the RestTemplate outbound call
     */
    private int connectionTimeout;

    private int connectionRequestTimeout;

    private int poolingMaxTotal;

    private int poolingDefaultMaxPerRoute;

    private String apiKey;

    private String sharedSecret;

    private String serviceUrl;

    private String[] encryptionPaths;

    private String[] decryptionPaths;

    private Resource privateKeyDecrypt;

    public Resource getPrivateKeyDecrypt() {
        return privateKeyDecrypt;
    }

    public void setPrivateKeyDecrypt(Resource privateKeyDecrypt) {
        this.privateKeyDecrypt = privateKeyDecrypt;
    }

    public Resource getPublickKeyEncrypt() {
        return publickKeyEncrypt;
    }

    public void setPublickKeyEncrypt(Resource publickKeyEncrypt) {
        this.publickKeyEncrypt = publickKeyEncrypt;
    }

    private Resource publickKeyEncrypt;

    public int getReadTimeout() {
        return readTimeout;
    }

    public void setReadTimeout(int readTimeout) {
        this.readTimeout = readTimeout;
    }

    public int getConnectionTimeout() {
        return connectionTimeout;
    }

    public void setConnectionTimeout(int connectionTimeout) {
        this.connectionTimeout = connectionTimeout;
    }

    public int getConnectionRequestTimeout() {
        return connectionRequestTimeout;
    }

    public void setConnectionRequestTimeout(int connectionRequestTimeout) {
        this.connectionRequestTimeout = connectionRequestTimeout;
    }

    public int getPoolingMaxTotal() {
        return poolingMaxTotal;
    }

    public void setPoolingMaxTotal(int poolingMaxTotal) {
        this.poolingMaxTotal = poolingMaxTotal;
    }

    public int getPoolingDefaultMaxPerRoute() {
        return poolingDefaultMaxPerRoute;
    }

    public void setPoolingDefaultMaxPerRoute(int poolingDefaultMaxPerRoute) {
        this.poolingDefaultMaxPerRoute = poolingDefaultMaxPerRoute;
    }

    public String getApiKey() {
        return apiKey;
    }

    public void setApiKey(String apiKey) {
        this.apiKey = apiKey;
    }

    public String getSharedSecret() {
        return sharedSecret;
    }

    public void setSharedSecret(String sharedSecret) {
        this.sharedSecret = sharedSecret;
    }

    public String getServiceUrl() {
        return serviceUrl;
    }

    public void setServiceUrl(String serviceUrl) {
        this.serviceUrl = serviceUrl;
    }

    public String[] getEncryptionPaths() {
        return encryptionPaths;
    }

    public void setEncryptionPaths(String[] encryptionPaths) {
        this.encryptionPaths = encryptionPaths;
    }

    public String[] getDecryptionPaths() {
        return decryptionPaths;
    }

    public void setDecryptionPaths(String[] decryptionPaths) {
        this.decryptionPaths = decryptionPaths;
    }
}
