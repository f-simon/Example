package com.fdc.mtrg.network.token.dto.transact;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fdc.mtrg.network.token.error.ResponseHeader;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TransactResponseDDX {
    @JsonProperty("responseHeader")
    private ResponseHeader responseHeader;

    @JsonProperty("onDemandCredentialsResponse")
    private OnDemandCredentialsResponse onDemandCredentialsResponse;

    public ResponseHeader getResponseHeader() {
        return responseHeader;
    }

    public void setResponseHeader(ResponseHeader responseHeader) {
        this.responseHeader = responseHeader;
    }

    public OnDemandCredentialsResponse getOnDemandCredentialsResponse() {
        return onDemandCredentialsResponse;
    }

    public void setOnDemandCredentialsResponse(OnDemandCredentialsResponse onDemandCredentialsResponse) {
        this.onDemandCredentialsResponse = onDemandCredentialsResponse;
    }
}
