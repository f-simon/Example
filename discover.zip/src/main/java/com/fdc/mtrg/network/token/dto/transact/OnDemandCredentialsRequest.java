package com.fdc.mtrg.network.token.dto.transact;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fdc.mtrg.network.token.dto.SecureContext;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class OnDemandCredentialsRequest {

    @JsonProperty("tokenId")
    private String tokenId;

    @JsonProperty("cryptoType")
    private String cryptoType;

    @JsonProperty("secureContext")
    private SecureContext secureContext;

    public String getTokenId() {
        return tokenId;
    }

    public String getCryptoType() {
        return cryptoType;
    }

    public void setCryptoType(String cryptoType) {
        this.cryptoType = cryptoType;
    }

    public SecureContext getSecureContext() {
        return secureContext;
    }

    public void setSecureContext(SecureContext secureContext) {
        this.secureContext = secureContext;
    }

    public void setTokenId(String tokenId) {
        this.tokenId = tokenId;
    }
}
