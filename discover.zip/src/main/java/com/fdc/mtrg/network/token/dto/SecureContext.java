
package com.fdc.mtrg.network.token.dto;

import java.io.Serializable;
import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "EncryptedContext"
})
public class SecureContext implements Serializable
{

    @JsonProperty("encryptedContent")
    private EncryptedContextRequest encryptedContent;
    private final static long serialVersionUID = 2461441733183945767L;


    public EncryptedContextRequest getEncryptedContent() {
        return encryptedContent;
    }

    public void setEncryptedContent(EncryptedContextRequest encryptedContent) {
        this.encryptedContent = encryptedContent;
    }

    @Override
    public String toString() {
        return "SecureContext{" +
                "encryptedContent=" + encryptedContent +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        SecureContext that = (SecureContext) o;
        return Objects.equals(encryptedContent, that.encryptedContent);
    }

    @Override
    public int hashCode() {
        return Objects.hash(encryptedContent);
    }
}
