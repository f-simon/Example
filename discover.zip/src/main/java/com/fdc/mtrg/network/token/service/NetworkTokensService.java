package com.fdc.mtrg.network.token.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fdc.mtrg.network.token.config.ApplicationProperties;
import com.fdc.mtrg.network.token.dto.ResponseHeader;
import com.nimbusds.jose.JWEDecrypter;
import com.nimbusds.jose.JWEObject;
import com.nimbusds.jose.crypto.RSADecrypter;
import com.fdc.mtrg.network.token.error.ApplicationError;
import com.fdc.mtrg.network.token.util.Constants;
import com.fdc.util.exception.FdcException;
import com.fdc.util.exception.model.NVP;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.security.PrivateKey;

import static com.fdc.mtrg.network.token.util.FileUtils.getJsonValue;
import static com.fdc.mtrg.network.token.util.FileUtils.setJsonValue;
import org.springframework.http.HttpHeaders;
import org.springframework.validation.FieldError;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.fdc.mtrg.network.token.dto.Error;

@Service
public class NetworkTokensService {
    private static final Logger logger = LoggerFactory.getLogger(NetworkTokensService.class);

    @Autowired
    protected ApplicationProperties appProps;

    @Autowired
    protected ObjectMapper objectMapper;

    @Autowired
    @Qualifier("JWTRestTemplate")
    protected RestTemplate restTemplate;

    @Autowired
    @Qualifier("privateKey")
    protected PrivateKey privateKey;

    protected String doDecryption(String responsePayload) throws IOException {
        try {
            for (String name : appProps.getDecryptionPaths()) {
                String value = getJsonValue(responsePayload, name);

                if(value == null) {
                    continue;
                }
                value = value.replace("\"", "");
                String decryptedValue = decrypt(value);

                logger.info("Decrypted value: {}", decryptedValue);

                responsePayload = setJsonValue(responsePayload, name, decryptedValue);
            }
            return sanitizeJson(responsePayload);
        } catch (Exception e) {
            throw new IOException("Failed to decrypt payload!", e);
        }
    }

    protected String sanitizeJson(String json) {
        return json.replaceAll("\n", "")
                .replaceAll("\r", "")
                .replaceAll("\t", "")
                .replaceAll("\"\\{","\\{")
                .replaceAll("\"\\}","\\}");
    }

    protected String decrypt(String encrypted) throws Exception {
        JWEDecrypter decrypter = new RSADecrypter(privateKey);
        JWEObject jweObject = JWEObject.parse(encrypted);
        jweObject.decrypt(decrypter);

        return jweObject.getPayload().toString();
    }

    protected HttpHeaders getHttpHeaders() {
        final HttpHeaders headers = new HttpHeaders();
        headers.set(Constants.ACCCEPT, Constants.CONTENT_TYPE_JSON);
        headers.set(Constants.CONTENT_TYPE, Constants.APPLICATION_JSON);
        headers.set(Constants.PROVTOKEN_HEAD_CACHE_CONTROL, Constants.PROVTOKEN_HEAD_CACHE_CONTROL_VALUE);
        headers.set(Constants.PROVTOKEN_HEAD_CONTENT_LANGUAGE, Constants.PROVTOKEN_HEAD_CONTENT_LANGUAGE_VALUE);
        headers.set(Constants.PROVTOKEN_HEAD_X_DFS_C_APP_CERT, Constants.PROVTOKEN_HEAD_X_DFS_C_APP_CERT_VALUE);
        headers.set(Constants.PROVTOKEN_HEAD_X_DFS_API_PLAN, Constants.PROVTOKEN_HEAD_X_DFS_API_PLAN_VALUE);

        return headers;
    }

    protected void handleException(ResponseHeader responseHeader) throws FdcException {
        Optional<List<Error>> optionalErrors = Optional.ofNullable(responseHeader.getErrors());

        if (optionalErrors.isPresent()) {
            List<Error> errors = optionalErrors.get();
            List<FieldError> fieldErrors = new ArrayList<>();
            List<NVP> nvps = new ArrayList<>();
            for (Error error : errors) {
                NVP nvp = new NVP();
                nvp.setName(error.getErrorCode());
                nvp.setValue(error.getErrorMessage());
                nvps.add(nvp);
            }
            throw new FdcException(ApplicationError.INVALID_REQUEST.getErrorCode(), ApplicationError.INVALID_REQUEST.getErrorDescription(), fieldErrors, ApplicationError.INVALID_REQUEST.getErrorDescription(), nvps);
        }
    }

}
