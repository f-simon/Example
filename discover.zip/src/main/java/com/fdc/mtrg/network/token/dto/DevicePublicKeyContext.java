
package com.fdc.mtrg.network.token.dto;

import java.io.Serializable;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "wallet specific information"
})
public class DevicePublicKeyContext implements Serializable
{

    @JsonProperty("wallet specific information")
    private String walletSpecificInformation;
    private final static long serialVersionUID = -2444885313747012306L;

    @JsonProperty("wallet specific information")
    public String getWalletSpecificInformation() {
        return walletSpecificInformation;
    }

    @JsonProperty("wallet specific information")
    public void setWalletSpecificInformation(String walletSpecificInformation) {
        this.walletSpecificInformation = walletSpecificInformation;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("walletSpecificInformation", walletSpecificInformation).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(walletSpecificInformation).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof DevicePublicKeyContext) == false) {
            return false;
        }
        DevicePublicKeyContext rhs = ((DevicePublicKeyContext) other);
        return new EqualsBuilder().append(walletSpecificInformation, rhs.walletSpecificInformation).isEquals();
    }

}
