
package com.fdc.mtrg.network.token.dto;

import java.io.Serializable;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "accountRisk",
    "deviceRisk"
})
public class RiskContext implements Serializable
{

    @JsonProperty("accountRisk")
    private String accountRisk;
    @JsonProperty("deviceRisk")
    private String deviceRisk;
    private final static long serialVersionUID = -7460903932109462271L;

    @JsonProperty("accountRisk")
    public String getAccountRisk() {
        return accountRisk;
    }

    @JsonProperty("accountRisk")
    public void setAccountRisk(String accountRisk) {
        this.accountRisk = accountRisk;
    }

    @JsonProperty("deviceRisk")
    public String getDeviceRisk() {
        return deviceRisk;
    }

    @JsonProperty("deviceRisk")
    public void setDeviceRisk(String deviceRisk) {
        this.deviceRisk = deviceRisk;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("accountRisk", accountRisk).append("deviceRisk", deviceRisk).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(accountRisk).append(deviceRisk).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof RiskContext) == false) {
            return false;
        }
        RiskContext rhs = ((RiskContext) other);
        return new EqualsBuilder().append(accountRisk, rhs.accountRisk).append(deviceRisk, rhs.deviceRisk).isEquals();
    }

}
