package com.fdc.mtrg.network.token.dto;


public class AccessToken {
    private static String accessToken;
    private static String tokenType;
    private static long expireMillis;


    public String getAccessToken() {
        return accessToken;
    }

    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }

    public String getTokenType() {
        return tokenType;
    }

    public void setTokenType(String tokenType) {
        this.tokenType = tokenType;
    }

    public long getExpireMillis() {
        return expireMillis;
    }

    public void setExpireMillis(long expireMillis) {
        this.expireMillis = expireMillis;
    }

    public String getBearerToken(){
        return new StringBuilder().append(tokenType).append(" ").append(accessToken).toString();
    }
}
