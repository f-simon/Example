package com.fdc.mtrg.network.token.dto.transact;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class OnDemandCredentialsResponse extends OnDemandCredentialsRequest{
}
