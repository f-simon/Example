package com.fdc.mtrg.network.token.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fdc.mtrg.network.token.dto.transact.TransactRequestDDX;
import com.fdc.mtrg.network.token.dto.transact.TransactResponseDDX;
import com.fdc.mtrg.network.token.error.ApplicationError;
import com.fdc.mtrg.network.token.util.Constants;
import com.fdc.util.exception.FdcException;
import com.fdc.util.exception.FdcRuntimeException;
import com.fdc.util.exception.types.FdcSystemException;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.integration.annotation.ServiceActivator;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;

@Service
public class TransactService extends NetworkTokensService {

    private static final Logger logger = LoggerFactory.getLogger(TransactService.class);

    @Autowired
    @Qualifier("JWTRestTemplate")
    private RestTemplate restTemplate;

    @Autowired
    private ObjectMapper objectMapper;

    @ServiceActivator
    @HystrixCommand(commandKey = "mc-cryptogram-command", threadPoolKey = "mc-cryptogram-thread-pool", ignoreExceptions = FdcRuntimeException.class)
    public Message<TransactResponseDDX> doOutboundServiceCall(@Header(Constants.MERCHANT_ID) final String pTokenReferenceId,
                                                              TransactRequestDDX pRequestMessage) throws FdcSystemException, FdcException, Exception {
        TransactResponseDDX transactResponse;

        return null;
    }
}