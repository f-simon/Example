package com.fdc.mtrg.network.token.service;

import com.fdc.mtrg.network.token.config.ApplicationProperties;
import com.fdc.mtrg.network.token.dto.AccessTokenResponse;
import com.fdc.mtrg.network.token.error.ApplicationError;
import com.fdc.mtrg.network.token.util.Constants;
import com.fdc.util.exception.FdcException;
import com.fdc.util.exception.FdcRuntimeException;
import com.fdc.util.exception.types.FdcSystemException;
import com.fdc.util.logging.SimpleAroundLog;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.integration.annotation.ServiceActivator;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

@Service
public class AccessTokenService {
    private static final Logger logger = LoggerFactory.getLogger(TokenizeService.class);

    private ApplicationProperties appProps;

    private RestTemplate restTemplate;

    public AccessTokenService(final ApplicationProperties appProps){
        this.appProps = appProps;
    }

    @SimpleAroundLog
    @HystrixCommand(commandKey = "mc-provision-command", threadPoolKey = "mc-provision-thread-pool", ignoreExceptions = FdcRuntimeException.class)
    public AccessTokenResponse accessToken() throws FdcSystemException, FdcException {

        logger.debug("Request received @ accessToken API {}");

        HttpEntity<String> accessTokenRequest = new HttpEntity<String>(getHttpHeaders());

        AccessTokenResponse accessToken;
        try {
            RestTemplate rt=  new RestTemplate();
            accessToken = rt.exchange(getUri(appProps.getServiceUrl()), HttpMethod.POST, accessTokenRequest, AccessTokenResponse.class).getBody();

        } catch (HttpClientErrorException hcee) {
            logger.error(hcee.getMessage(), hcee);
            throw new FdcException(ApplicationError.AUTHORIZATION_FAILED.getErrorCode(), ApplicationError.AUTHORIZATION_FAILED.getErrorDescription());
        }

        return accessToken;
    }


    public HttpHeaders getHttpHeaders() {
        final HttpHeaders headers = new HttpHeaders();
        headers.set(Constants.ACCCEPT, Constants.CONTENT_TYPE_JSON);
        headers.set(Constants.ACCESS_TOKEN_HEAD_CONTENT_TYPE, Constants.ACCESS_TOKEN_HEAD_CONTENT_TYPE_VALUE);
        headers.set(Constants.ACCESS_TOKEN_HEAD_AUTH, Constants.ACCESS_TOKEN_HEAD_AUTH_VALUE);
        headers.set(Constants.ACCESS_TOKEN_HEAD_CACHE_CONTROL, Constants.ACCESS_TOKEN_HEAD_CACHE_CONTROL_VALUE);
        return headers;
    }

    public String getUri(String path) {
        final StringBuilder sb = new StringBuilder();
        sb.append(path);
        sb.append(Constants.ACCESS_TOKEN_URI);
        logger.info("Outbound Url {} ", sb.toString());
        return sb.toString();

    }

}
