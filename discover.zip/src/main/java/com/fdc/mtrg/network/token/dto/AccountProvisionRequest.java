
package com.fdc.mtrg.network.token.dto;

import java.io.Serializable;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "secureContext",
    "deviceContext",
    "userProvisionContext",
    "riskContext"
})
public class AccountProvisionRequest implements Serializable
{

    @JsonProperty("secureContext")
    private SecureContext secureContext;
    @JsonProperty("deviceContext")
    private DeviceContext deviceContext;
    @JsonProperty("userProvisionContext")
    private UserProvisionContext userProvisionContext;
    @JsonProperty("riskContext")
    private RiskContext riskContext;
    private final static long serialVersionUID = 3782043367323670035L;

    @JsonProperty("secureContext")
    public SecureContext getSecureContext() {
        return secureContext;
    }

    @JsonProperty("secureContext")
    public void setSecureContext(SecureContext secureContext) {
        this.secureContext = secureContext;
    }

    @JsonProperty("deviceContext")
    public DeviceContext getDeviceContext() {
        return deviceContext;
    }

    @JsonProperty("deviceContext")
    public void setDeviceContext(DeviceContext deviceContext) {
        this.deviceContext = deviceContext;
    }

    @JsonProperty("userProvisionContext")
    public UserProvisionContext getUserProvisionContext() {
        return userProvisionContext;
    }

    @JsonProperty("userProvisionContext")
    public void setUserProvisionContext(UserProvisionContext userProvisionContext) {
        this.userProvisionContext = userProvisionContext;
    }

    @JsonProperty("riskContext")
    public RiskContext getRiskContext() {
        return riskContext;
    }

    @JsonProperty("riskContext")
    public void setRiskContext(RiskContext riskContext) {
        this.riskContext = riskContext;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("secureContext", secureContext).append("deviceContext", deviceContext).append("userProvisionContext", userProvisionContext).append("riskContext", riskContext).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(riskContext).append(secureContext).append(deviceContext).append(userProvisionContext).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof AccountProvisionRequest) == false) {
            return false;
        }
        AccountProvisionRequest rhs = ((AccountProvisionRequest) other);
        return new EqualsBuilder().append(riskContext, rhs.riskContext).append(secureContext, rhs.secureContext).append(deviceContext, rhs.deviceContext).append(userProvisionContext, rhs.userProvisionContext).isEquals();
    }

}
