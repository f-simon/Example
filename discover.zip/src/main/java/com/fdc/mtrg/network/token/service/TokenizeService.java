package com.fdc.mtrg.network.token.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fdc.mtrg.network.token.config.ApplicationProperties;
import com.fdc.mtrg.network.token.dto.ProvisionedTokenRequestDDX;
import com.fdc.mtrg.network.token.dto.ProvisionedTokenResponseDDX;
import com.fdc.mtrg.network.token.error.ApplicationError;
import com.fdc.mtrg.network.token.error.Error;
import com.fdc.mtrg.network.token.error.HeadLevelError;
import com.fdc.mtrg.network.token.util.Constants;
import com.fdc.util.exception.FdcException;
import com.fdc.util.exception.FdcRuntimeException;
import com.fdc.util.exception.model.NVP;
import com.fdc.util.exception.types.FdcSystemException;
import com.fdc.util.logging.SimpleAroundLog;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.integration.annotation.ServiceActivator;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.stereotype.Service;
import org.springframework.validation.FieldError;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.security.cert.Certificate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;


@Service
public class TokenizeService {

    private static final Logger logger = LoggerFactory.getLogger(TokenizeService.class);

    @Autowired
    private ApplicationProperties appProps;

    @Autowired
    @Qualifier("encryptionCertificate")
    private Certificate certificate;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    @Qualifier("JWTRestTemplate")
    protected RestTemplate restTemplate;

    static int attempts;

    @SimpleAroundLog
    @ServiceActivator
  //  @HystrixCommand(commandKey = "mc-provision-command", threadPoolKey = "mc-provision-thread-pool", ignoreExceptions = FdcRuntimeException.class)
    public ProvisionedTokenResponseDDX tokenize(@Header(Constants.MERCHANT_ID) final String pmerchantId,
                                                ProvisionedTokenRequestDDX pRequestMessage) throws FdcSystemException, FdcException, JsonProcessingException {

        logger.debug("Request received @ tokenize API for merchant Partner {} and request {} ", pmerchantId, pRequestMessage);

        ProvisionedTokenResponseDDX responsePayload = null;
        try {
            HttpEntity<String> tokenizationRequest = new HttpEntity<>(objectMapper.writeValueAsString(pRequestMessage), getHttpHeaders());

            responsePayload = this.restTemplate.exchange(getUri(), HttpMethod.POST, tokenizationRequest, ProvisionedTokenResponseDDX.class).getBody();
            //tokenizeResponse = getProvisionedTokenResponse(); //for unit tests

        } catch (HttpClientErrorException hcee) {

            if (hcee.getStatusCode() == HttpStatus.UNAUTHORIZED) {
                if (attempts < 1) {
                    attempts++;
                    tokenize(pmerchantId, pRequestMessage);

                } else {
                    logger.error(hcee.getMessage(), hcee);
                    throw new FdcException(ApplicationError.AUTHORIZATION_FAILED.getErrorCode(), ApplicationError.AUTHORIZATION_FAILED.getErrorDescription());
                }
            } else if (hcee.getStatusCode() == HttpStatus.BAD_REQUEST) {
                handleException(hcee.getResponseBodyAsString());
            } else if (hcee.getStatusCode() == HttpStatus.FORBIDDEN){
                logger.error(hcee.getMessage(), hcee);
                throw new FdcException(ApplicationError.AUTHORIZATION_FAILED.getErrorCode(), ApplicationError.AUTHORIZATION_FAILED.getErrorDescription());
            } else {
                logger.error(hcee.getMessage(), hcee);
                throw new FdcSystemException(ApplicationError.SERVICE_UNAVAILABLE.getErrorCode(), ApplicationError.SERVICE_UNAVAILABLE.getErrorDescription());
            }
        }catch (final RestClientException rce){
            logger.error(rce.getMessage(), rce);
            throw new FdcSystemException(ApplicationError.SERVICE_UNAVAILABLE.getErrorCode(), ApplicationError.SERVICE_UNAVAILABLE.getErrorDescription());
        }
        if (responsePayload == null) {
            logger.error("Getting null response from discover Adapter for suspend API");
            throw new FdcSystemException(ApplicationError.SERVICE_UNAVAILABLE.getErrorCode(), ApplicationError.SERVICE_UNAVAILABLE.getErrorDescription());
        }
        return responsePayload;
    }

    public String getUri() {
        final StringBuilder sb = new StringBuilder();
        sb.append(appProps.getServiceUrl());
        sb.append(Constants.PROVISON_URI);
        logger.info("Outbound Url {} ", sb.toString());
        return sb.toString();
    }


    public HttpHeaders getHttpHeaders() {
        final HttpHeaders headers = new HttpHeaders();
        headers.set(Constants.ACCCEPT, Constants.CONTENT_TYPE_JSON);
        headers.set(Constants.CONTENT_TYPE, Constants.APPLICATION_JSON);

        //   headers.set(Constants.PROVTOKEN_HEAD_AUTH, Constants.PROVTOKEN_HEAD_AUTH_VALUE);
        headers.set(Constants.PROVTOKEN_HEAD_CACHE_CONTROL, Constants.PROVTOKEN_HEAD_CACHE_CONTROL_VALUE);
        headers.set(Constants.PROVTOKEN_HEAD_CONTENT_LANGUAGE, Constants.PROVTOKEN_HEAD_CONTENT_LANGUAGE_VALUE);
        headers.set(Constants.PROVTOKEN_HEAD_X_DFS_C_APP_CERT, Constants.PROVTOKEN_HEAD_X_DFS_C_APP_CERT_VALUE);
        headers.set(Constants.PROVTOKEN_HEAD_X_DFS_API_PLAN, Constants.PROVTOKEN_HEAD_X_DFS_API_PLAN_VALUE);

        return headers;
    }

    public void handleException(String responseBodyAsString) throws FdcException{
        try {
            HeadLevelError headLevelError = new HeadLevelError();
            objectMapper = new ObjectMapper();

            headLevelError = objectMapper.readValue(responseBodyAsString, HeadLevelError.class);

            // com.fdc.mtrg.network.token.error.Error  -- to avoid error with dto.Error
            Optional<List<com.fdc.mtrg.network.token.error.Error>> headError = Optional.ofNullable(headLevelError.getResponseHeader().getErrors());
            if(headError.isPresent()){
                List<FieldError> fieldErrors = new ArrayList<>();
                for(Error error: headError.get()){
                    fieldErrors.add(new FieldError("LifeCycle", error.getErrorCode(), error.getErrorMessage()));
                }

                List<NVP> nvps = new ArrayList<>();

                // programId, responseId, and sessionId are not in array -- they are separate fields
                Optional<String> programId =  Optional.ofNullable(headLevelError.getResponseHeader().getProgramId());
                if(programId.isPresent()){
                    NVP nvp = new NVP();
                    nvp.setName("programId");
                    nvp.setValue(programId.get());
                    nvps.add(nvp);
                }

                Optional<String> responseId =  Optional.ofNullable(headLevelError.getResponseHeader().getResponseId());
                if(responseId.isPresent()){
                    NVP nvp = new NVP();
                    nvp.setName("responseId");
                    nvp.setValue(responseId.get());
                    nvps.add(nvp);
                }

                Optional<String> sessionId =  Optional.ofNullable(headLevelError.getResponseHeader().getSessionId());
                if(sessionId.isPresent()){
                    NVP nvp = new NVP();
                    nvp.setName("sessionId");
                    nvp.setValue(sessionId.get());
                    nvps.add(nvp);
                }

                throw new FdcException(ApplicationError.INVALID_REQUEST.getErrorCode(), ApplicationError.INVALID_REQUEST.getErrorDescription(), fieldErrors,
                        ApplicationError.INVALID_REQUEST.getErrorDescription(), nvps);
            }

        } catch (JsonProcessingException e) {
            logger.error(e.getMessage(), e);
            throw new FdcException(ApplicationError.INVALID_REQUEST.getStatusCode(), ApplicationError.INVALID_REQUEST.getErrorDescription());
        }
    }
}
