
package com.fdc.mtrg.network.token.dto;

import java.io.Serializable;
import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "lifeycleOperationsRequest",
    "operationType",
    "reason",
    "timeRaised"
})
public class AccountLifecycleRequest implements Serializable
{

    @JsonProperty("lifeycleOperationsRequest")
    private List<LifeycleOperationsRequest> lifeycleOperationsRequest = null;
    @JsonProperty("operationType")
    private String operationType;
    @JsonProperty("reason")
    private String reason;
    @JsonProperty("timeRaised")
    private String timeRaised;
    private final static long serialVersionUID = -3023731743318655L;

    @JsonProperty("lifeycleOperationsRequest")
    public List<LifeycleOperationsRequest> getLifeycleOperationsRequest() {
        return lifeycleOperationsRequest;
    }

    @JsonProperty("lifeycleOperationsRequest")
    public void setLifeycleOperationsRequest(List<LifeycleOperationsRequest> lifeycleOperationsRequest) {
        this.lifeycleOperationsRequest = lifeycleOperationsRequest;
    }

    @JsonProperty("operationType")
    public String getOperationType() {
        return operationType;
    }

    @JsonProperty("operationType")
    public void setOperationType(String operationType) {
        this.operationType = operationType;
    }

    @JsonProperty("reason")
    public String getReason() {
        return reason;
    }

    @JsonProperty("reason")
    public void setReason(String reason) {
        this.reason = reason;
    }

    @JsonProperty("timeRaised")
    public String getTimeRaised() {
        return timeRaised;
    }

    @JsonProperty("timeRaised")
    public void setTimeRaised(String timeRaised) {
        this.timeRaised = timeRaised;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("lifeycleOperationsRequest", lifeycleOperationsRequest).append("operationType", operationType).append("reason", reason).append("timeRaised", timeRaised).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(lifeycleOperationsRequest).append(reason).append(timeRaised).append(operationType).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof AccountLifecycleRequest) == false) {
            return false;
        }
        AccountLifecycleRequest rhs = ((AccountLifecycleRequest) other);
        return new EqualsBuilder().append(lifeycleOperationsRequest, rhs.lifeycleOperationsRequest).append(reason, rhs.reason).append(timeRaised, rhs.timeRaised).append(operationType, rhs.operationType).isEquals();
    }

}
