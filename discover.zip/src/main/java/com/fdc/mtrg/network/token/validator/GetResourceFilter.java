package com.fdc.mtrg.network.token.validator;

import com.fdc.mtrg.network.token.error.ApplicationError;
import com.fdc.mtrg.network.token.util.Constants;
import com.fdc.util.exception.FdcException;
import com.fdc.util.exception.model.NVP;
import org.springframework.integration.annotation.Filter;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.stereotype.Service;
import org.springframework.validation.FieldError;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
public class GetResourceFilter {

    @Filter
    public boolean validateAssetRequest(@Header(Constants.PROGRAM_ID) String programId,
                    @Header(Constants.RESOURCE_UUID) String resourceUUID,
                    @Header(Constants.REQUEST_ID) String requestId,
                    @Header(Constants.MERCHANT_ID) final String merchantId) throws FdcException {

        final String programIdRegex = "^([A-Za-z0-9-]{1,16})$";
        final String resourceUUIDRegex = "^([A-Za-z0-9-_]{1,64})$";
        final String requestIdRegex = "^([A-Za-z0-9-]{1,64})$";

        final Pattern programIdPattern = Pattern.compile(programIdRegex);
        final Pattern resourceUUIDPattern = Pattern.compile(resourceUUIDRegex);
        final Pattern requestIdPattern = Pattern.compile(requestIdRegex);

        final Matcher programIdPMatcher = programIdPattern.matcher(programId);
        final Matcher resourceUUIDMatcher = resourceUUIDPattern.matcher(resourceUUID);
        final Matcher requestIdMatcher = requestIdPattern.matcher(requestId);

        List<FieldError> fieldErrors = new ArrayList<>();
        List<NVP> nvps = new ArrayList<>();

        if (!programIdPMatcher.matches()) {
            fieldErrors.add(new FieldError("Invalid ProgramId",
                    Constants.PROGRAM_ID, Constants.INVALID_PROGRAM_ID));
            NVP nvp = new NVP();
            nvp.setName(Constants.PROGRAM_ID);
            nvp.setValue(programId);
            nvps.add(nvp);
        }

        if (!resourceUUIDMatcher.matches()) {
            fieldErrors.add(new FieldError("Invalid Resource UUID",
                    Constants.RESOURCE_UUID, Constants.INVALID_RESOURCE_UUID_ID));
            NVP nvp = new NVP();
            nvp.setName(Constants.RESOURCE_UUID);
            nvp.setValue(resourceUUID);
            nvps.add(nvp);
        }

        if (!requestIdMatcher.matches()) {
            fieldErrors.add(new FieldError("Invalid RequestId",
                    Constants.REQUEST_ID, Constants.INVALID_REQUEST_ID));
            NVP nvp = new NVP();
            nvp.setName(Constants.REQUEST_ID);
            nvp.setValue(requestId);
            nvps.add(nvp);
        }

        if (fieldErrors.size() > 0 && nvps.size() > 0) {
            throw new FdcException(ApplicationError.INVALID_REQUEST.getErrorCode(),
                    ApplicationError.INVALID_REQUEST.getErrorDescription(),
                    fieldErrors,
                    ApplicationError.INVALID_REQUEST.getErrorDescription(),
                    nvps);
        }

        return true;
    }
}
