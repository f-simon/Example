
package com.fdc.mtrg.network.token.dto;

import java.io.Serializable;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "pan",
    "expDate",
    "seqNbr",
    "cardHolderName",
    "billingAddr",
    "billingZip",
    "source"
})
public class EncryptedContextRequest implements Serializable
{

    @JsonProperty("pan")
    private String pan;
    @JsonProperty("expDate")
    private String expDate;
    @JsonProperty("seqNbr")
    private String seqNbr;
    @JsonProperty("cardHolderName")
    private String cardHolderName;
    @JsonProperty("billingAddr")
    private String billingAddr;
    @JsonProperty("billingZip")
    private String billingZip;
    @JsonProperty("source")
    private String source;
    @JsonProperty("unpredictableNumber")
    private String unpredictableNumber;
    @JsonProperty("remoteCryptogram")
    private String remoteCryptogram;
    private final static long serialVersionUID = -6980658063867947530L;

    @JsonProperty("pan")
    public String getPan() {
        return pan;
    }

    @JsonProperty("pan")
    public void setPan(String pan) {
        this.pan = pan;
    }

    @JsonProperty("expDate")
    public String getExpDate() {
        return expDate;
    }

    @JsonProperty("expDate")
    public void setExpDate(String expDate) {
        this.expDate = expDate;
    }

    @JsonProperty("seqNbr")
    public String getSeqNbr() {
        return seqNbr;
    }

    @JsonProperty("seqNbr")
    public void setSeqNbr(String seqNbr) {
        this.seqNbr = seqNbr;
    }

    @JsonProperty("cardHolderName")
    public String getCardHolderName() {
        return cardHolderName;
    }

    @JsonProperty("cardHolderName")
    public void setCardHolderName(String cardHolderName) {
        this.cardHolderName = cardHolderName;
    }

    @JsonProperty("billingAddr")
    public String getBillingAddr() {
        return billingAddr;
    }

    @JsonProperty("billingAddr")
    public void setBillingAddr(String billingAddr) {
        this.billingAddr = billingAddr;
    }

    @JsonProperty("billingZip")
    public String getBillingZip() {
        return billingZip;
    }

    @JsonProperty("billingZip")
    public void setBillingZip(String billingZip) {
        this.billingZip = billingZip;
    }

    @JsonProperty("source")
    public String getSource() {
        return source;
    }

    @JsonProperty("source")
    public void setSource(String source) {
        this.source = source;
    }

    public String getUnpredictableNumber() {
        return unpredictableNumber;
    }

    public void setUnpredictableNumber(String unpredictableNumber) {
        this.unpredictableNumber = unpredictableNumber;
    }

    public String getRemoteCryptogram() {
        return remoteCryptogram;
    }

    public void setRemoteCryptogram(String remoteCryptogram) {
        this.remoteCryptogram = remoteCryptogram;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("pan", pan).append("expDate", expDate).append("seqNbr", seqNbr).append("cardHolderName", cardHolderName).append("billingAddr", billingAddr).append("billingZip", billingZip).append("source", source).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(cardHolderName).append(billingAddr).append(source).append(pan).append(expDate).append(seqNbr).append(billingZip).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof EncryptedContextRequest) == false) {
            return false;
        }
        EncryptedContextRequest rhs = ((EncryptedContextRequest) other);
        return new EqualsBuilder().append(cardHolderName, rhs.cardHolderName).append(billingAddr, rhs.billingAddr).append(source, rhs.source).append(pan, rhs.pan).append(expDate, rhs.expDate).append(seqNbr, rhs.seqNbr).append(billingZip, rhs.billingZip).isEquals();
    }

}
