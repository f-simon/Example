
package com.fdc.mtrg.network.token.dto;

import java.io.Serializable;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "deviceType",
    "deviceIp",
    "deviceLookUpContext"
})
public class DeviceContext implements Serializable
{

    @JsonProperty("deviceType")
    private String deviceType;
    @JsonProperty("deviceIp")
    private String deviceIp;
    @JsonProperty("deviceLookUpContext")
    private DeviceLookUpContext deviceLookUpContext;
    private final static long serialVersionUID = -1956437487417590657L;

    @JsonProperty("deviceType")
    public String getDeviceType() {
        return deviceType;
    }

    @JsonProperty("deviceType")
    public void setDeviceType(String deviceType) {
        this.deviceType = deviceType;
    }

    @JsonProperty("deviceIp")
    public String getDeviceIp() {
        return deviceIp;
    }

    @JsonProperty("deviceIp")
    public void setDeviceIp(String deviceIp) {
        this.deviceIp = deviceIp;
    }

    @JsonProperty("deviceLookUpContext")
    public DeviceLookUpContext getDeviceLookUpContext() {
        return deviceLookUpContext;
    }

    @JsonProperty("deviceLookUpContext")
    public void setDeviceLookUpContext(DeviceLookUpContext deviceLookUpContext) {
        this.deviceLookUpContext = deviceLookUpContext;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("deviceType", deviceType).append("deviceIp", deviceIp).append("deviceLookUpContext", deviceLookUpContext).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(deviceType).append(deviceIp).append(deviceLookUpContext).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof DeviceContext) == false) {
            return false;
        }
        DeviceContext rhs = ((DeviceContext) other);
        return new EqualsBuilder().append(deviceType, rhs.deviceType).append(deviceIp, rhs.deviceIp).append(deviceLookUpContext, rhs.deviceLookUpContext).isEquals();
    }

}
