
package com.fdc.mtrg.network.token.dto;

import java.io.Serializable;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "requestHeader",
    "accountProvisionRequest"
})
public class ProvisionedTokenRequestDDX implements Serializable
{

    @JsonProperty("requestHeader")
    private RequestHeader requestHeader;
    @JsonProperty("accountProvisionRequest")
    private AccountProvisionRequest accountProvisionRequest;
    private final static long serialVersionUID = -7882455023767595554L;

    @JsonProperty("requestHeader")
    public RequestHeader getRequestHeader() {
        return requestHeader;
    }

    @JsonProperty("requestHeader")
    public void setRequestHeader(RequestHeader requestHeader) {
        this.requestHeader = requestHeader;
    }

    @JsonProperty("accountProvisionRequest")
    public AccountProvisionRequest getAccountProvisionRequest() {
        return accountProvisionRequest;
    }

    @JsonProperty("accountProvisionRequest")
    public void setAccountProvisionRequest(AccountProvisionRequest accountProvisionRequest) {
        this.accountProvisionRequest = accountProvisionRequest;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("requestHeader", requestHeader).append("accountProvisionRequest", accountProvisionRequest).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(accountProvisionRequest).append(requestHeader).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof ProvisionedTokenRequestDDX) == false) {
            return false;
        }
        ProvisionedTokenRequestDDX rhs = ((ProvisionedTokenRequestDDX) other);
        return new EqualsBuilder().append(accountProvisionRequest, rhs.accountProvisionRequest).append(requestHeader, rhs.requestHeader).isEquals();
    }

}
