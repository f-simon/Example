package com.fdc.mtrg.network.token.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.util.Objects;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "paymentAccountReference"
})
public class AccountContext {

    @JsonProperty("paymentAccountReference")
    private String paymentAccountReference;

    public String getPaymentAccountReference() {
        return paymentAccountReference;
    }

    public void setPaymentAccountReference(String paymentAccountReference) {
        this.paymentAccountReference = paymentAccountReference;
    }

    @Override
    public String toString() {
        return "AccountContext{" +
                "paymentAccountReference='" + paymentAccountReference + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        AccountContext that = (AccountContext) o;
        return Objects.equals(paymentAccountReference, that.paymentAccountReference);
    }

    @Override
    public int hashCode() {
        return Objects.hash(paymentAccountReference);
    }
}
