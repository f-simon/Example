
package com.fdc.mtrg.network.token.dto;

import java.io.Serializable;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "tokenId",
    "operationStatus",
    "errorCode",
    "errorMessage"
})
public class LifecycleOperationsResponse implements Serializable
{

    @JsonProperty("tokenId")
    private String tokenId;
    @JsonProperty("operationStatus")
    private String operationStatus;
    @JsonProperty("errorCode")
    private String errorCode;
    @JsonProperty("errorMessage")
    private String errorMessage;
    private final static long serialVersionUID = 4676487795092029190L;

    @JsonProperty("tokenId")
    public String getTokenId() {
        return tokenId;
    }

    @JsonProperty("tokenId")
    public void setTokenId(String tokenId) {
        this.tokenId = tokenId;
    }

    @JsonProperty("operationStatus")
    public String getOperationStatus() {
        return operationStatus;
    }

    @JsonProperty("operationStatus")
    public void setOperationStatus(String operationStatus) {
        this.operationStatus = operationStatus;
    }

    @JsonProperty("errorCode")
    public String getErrorCode() {
        return errorCode;
    }

    @JsonProperty("errorCode")
    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    @JsonProperty("errorMessage")
    public String getErrorMessage() {
        return errorMessage;
    }

    @JsonProperty("errorMessage")
    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("tokenId", tokenId).append("operationStatus", operationStatus).append("errorCode", errorCode).append("errorMessage", errorMessage).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(errorMessage).append(errorCode).append(operationStatus).append(tokenId).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof LifecycleOperationsResponse) == false) {
            return false;
        }
        LifecycleOperationsResponse rhs = ((LifecycleOperationsResponse) other);
        return new EqualsBuilder().append(errorMessage, rhs.errorMessage).append(errorCode, rhs.errorCode).append(operationStatus, rhs.operationStatus).append(tokenId, rhs.tokenId).isEquals();
    }

}
