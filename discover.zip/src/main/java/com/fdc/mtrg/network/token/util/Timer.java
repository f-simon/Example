package com.fdc.mtrg.network.token.util;

public class Timer {
    private static long startTime = 0;
    private static long endTime   = 0;

    public void start(){
        this.startTime = System.currentTimeMillis();
    }

    public void end() {
        this.endTime   = System.currentTimeMillis();
    }

    public long getStartTime() {
        return this.startTime;
    }

    public long getEndTime() {
        return this.endTime;
    }

    public long getTotalTime() {
        return this.endTime - this.startTime ;
    }
}
