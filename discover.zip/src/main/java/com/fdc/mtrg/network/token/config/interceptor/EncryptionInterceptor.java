package com.fdc.mtrg.network.token.config.interceptor;

import com.fdc.mtrg.network.token.config.ApplicationProperties;
import com.nimbusds.jose.*;
import com.nimbusds.jose.crypto.RSAEncrypter;
import com.nimbusds.jose.util.Base64URL;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpRequest;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;

import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.cert.Certificate;
import java.security.interfaces.RSAPublicKey;

import static com.fdc.mtrg.network.token.util.FileUtils.getJsonValue;
import static com.fdc.mtrg.network.token.util.FileUtils.setJsonValue;

public class EncryptionInterceptor implements ClientHttpRequestInterceptor {
    private static final Logger logger = LoggerFactory.getLogger(EncryptionInterceptor.class);

    private ApplicationProperties appProps;

    private Certificate publicKeyCertificate;


    public EncryptionInterceptor(ApplicationProperties appProps, Certificate certificate) {
        this.appProps = appProps;
        this.publicKeyCertificate = certificate;
    }

    @Override
    public ClientHttpResponse intercept(HttpRequest request, byte[] body, ClientHttpRequestExecution execution) throws IOException {
        String payload = new String(body);

        if (StringUtils.isNotBlank(payload)) {
            boolean isEncryptionProcessed = false;

            try {
                for (String name : appProps.getEncryptionPaths()) {
                    String valueToBeEncrypted = getJsonValue(payload, name);

                    if (valueToBeEncrypted == null) {
                        continue;
                    }
                    String encryptedValue = encrypt(valueToBeEncrypted);
                    payload = setJsonValue(payload, name, encryptedValue);
                    isEncryptionProcessed = true;
                }
                if (isEncryptionProcessed) {
                    body = payload.getBytes();
                    request.getHeaders().add("Content-Length", String.valueOf(body.length));
                }
            } catch (Exception e) {
                logger.error(e.getMessage(), e);
                throw new IOException("Failed to ecrypt payload!", e);
            }
        }
        return execution.execute(request, body);
    }

    private String encrypt(String json) throws Exception {
        JWEEncrypter encrypter = new RSAEncrypter(getRSAPublicKey());
        JWEObject jweObject = new JWEObject(getRSAHeader(), new Payload(json));
        jweObject.encrypt(encrypter);

        return jweObject.serialize();
    }

    private  RSAPublicKey getRSAPublicKey() {
        return (RSAPublicKey)publicKeyCertificate.getPublicKey();
    }

    private JWEHeader getRSAHeader()  throws NoSuchAlgorithmException {
        //build JWEHeader based on the Discover requirements
        JWEHeader.Builder headerBuilder = new JWEHeader.Builder(JWEAlgorithm.RSA1_5, EncryptionMethod.A128CBC_HS256);
        headerBuilder.keyID(getKid().toString());
        return headerBuilder.build();
    }

    private Base64URL getKid() throws NoSuchAlgorithmException {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] encodedhash = digest.digest(getRSAPublicKey().getEncoded());
        return Base64URL.encode(encodedhash);
    }
}
