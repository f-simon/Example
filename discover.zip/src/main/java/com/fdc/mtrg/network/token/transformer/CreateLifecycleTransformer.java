package com.fdc.mtrg.network.token.transformer;

import brave.Span;
import brave.Tracer;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fdc.mtrg.api.Operation;
import com.fdc.mtrg.api.UpdateTokenRequest;
import com.fdc.mtrg.network.token.dto.*;
import com.fdc.mtrg.network.token.error.ApplicationError;
import com.fdc.mtrg.network.token.util.Constants;
import com.fdc.util.exception.FdcException;
import com.fdc.util.exception.types.FdcSystemException;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.integration.annotation.Transformer;
import org.springframework.messaging.Message;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.stereotype.Service;
import org.springframework.validation.FieldError;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class CreateLifecycleTransformer {
    private static final Logger logger = LoggerFactory.getLogger(CreateLifecycleTransformer.class);

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private Tracer tracer;


    @Transformer
    public UpdateTokensRequestsDDX doTransformRequest(@Header(Constants.MERCHANT_ID) final String merchantId,
                                                      @Header(Constants.PROVISION_TOKEN_ID) final String tokenReferenceId,
                                                      Message<UpdateTokenRequest> lifeCycleMessage) throws JsonProcessingException {

        logger.debug("Request received @ doTransform API for merchant Action {} : tokenReferenceId {} and request {} ", merchantId, tokenReferenceId,
                objectMapper.writeValueAsString(lifeCycleMessage.getPayload()));

        UpdateTokenRequest payload = lifeCycleMessage.getPayload();

        UpdateTokensRequestsDDX updateTokensRequestsDDX = new UpdateTokensRequestsDDX();
        RequestHeader requestHeader = new RequestHeader();
        AccountLifecycleRequest accountLifecycleRequest = new AccountLifecycleRequest();

        LifeycleOperationsRequest lor = new LifeycleOperationsRequest();


        var lifeycleOperationsRequest = new ArrayList<LifeycleOperationsRequest>();

        // TODO - TraceId is not working
//        Optional.ofNullable(tracer).map(Tracer::currentSpan).map(Span::context)
//                .ifPresent(traceId -> requestHeader.setRequestId(traceId.toString()));
//

        requestHeader.setRequestId(UUID.randomUUID().toString());

        // for testing responseId
     //   requestHeader.setRequestId("5f306b361a134ef48dd1e809a3389xxx");

    //    requestHeader.setRequestId("5f306b361a134ef48dd1e809a338952d");

        requestHeader.setProgramId(Constants.DDXPROGRAM_ID);

        // for Testing
     //   requestHeader.setProgramId("ErrorId");

        Optional<String> tuf = Optional.ofNullable(tokenReferenceId);

        if (tuf.isPresent()) lor.setTokenId(tuf.get());

        // for Testing TokenId
     //   lor.setTokenId("XXXXX");

        lifeycleOperationsRequest.add(lor);


        Optional<Enum> operation = Optional.ofNullable(payload.getOperation());
        if (operation.isPresent()) {
            if (operation.get().equals(Operation.SUSPEND)) {
                accountLifecycleRequest.setOperationType(Operation.SUSPEND.getValue());
            } else if (operation.get().equals(Operation.RESUME)) {
                accountLifecycleRequest.setOperationType(Operation.RESUME.getValue());
            } else if (operation.get().equals(Operation.DELETE)) {
                accountLifecycleRequest.setOperationType("Unlink");
            }
        }

        Optional<String> reason = Optional.ofNullable(payload.getUpdateReason().getReason());
        accountLifecycleRequest.setReason(reason.get());

        accountLifecycleRequest.setLifeycleOperationsRequest(lifeycleOperationsRequest);
        accountLifecycleRequest.setTimeRaised(getDateTimeUTC());

        updateTokensRequestsDDX.setRequestHeader(requestHeader);
        updateTokensRequestsDDX.setAccountLifecycleRequest(accountLifecycleRequest);

        return updateTokensRequestsDDX;
    }

    @Transformer
    public HttpStatus doTransformResposne(@Header(Constants.MERCHANT_ID) final String merchantId,
                                                             UpdateTokensResponseDDX updateTokensResponseDDX) throws FdcException {
        logger.debug("Request received @ doReplyTransform API for merchant Partner {}  ", merchantId);

        /* This code here is correct.  The global exception handler was probably change */

        List<FieldError> fieldErrors = new ArrayList<>();

        if (null != updateTokensResponseDDX.getAccountLifecycleResponse()) {
            for (LifecycleOperationsResponse lor : updateTokensResponseDDX.getAccountLifecycleResponse().getLifecycleOperationsResponse()) {
                if (lor.getOperationStatus().equals("00") && updateTokensResponseDDX.getResponseHeader().getResponseId() != null
                        && updateTokensResponseDDX.getResponseHeader().getProgramId().equals(Constants.DDXPROGRAM_ID)) {
                    return HttpStatus.NO_CONTENT;

                } else {
                    fieldErrors.add(new FieldError("UpdateTokensResponseDDX", "tokenId" , "Invalid payment token identifier"));
                    throw new FdcException(ApplicationError.INVALID_REQUEST.getErrorCode(), ApplicationError.INVALID_REQUEST.getErrorDescription(), fieldErrors);
                }
            }  // for ends
        }

        logger.error("UpdateTokensResponseDDX is null from MDES.");
        throw new FdcSystemException(ApplicationError.SERVER_ERROR.getErrorCode(), ApplicationError.SERVER_ERROR.getErrorDescription());
    }

    public String getDateTimeUTC() {

        DateTime dt = new DateTime();
        DateTimeFormatter fmt = DateTimeFormat.forPattern("YYYY-MM-dd'T'hh:mm:ss.sss'Z'");
        return dt.toString(fmt);
    }
}
