package com.fdc.mtrg.network.token.util;

public interface Constants {
    String CLIENT_REQUEST_ID = "Client-Request-Id";
    String X_REQUEST_ID = "x-request-id";
    String MERCHANT_ID = "merchantId";
    String TOKEN_REFERENCE_ID = "tokenReferenceId";
    String PROVISION_TOKEN_ID = "vProvisionedTokenID";
    String CLOUD = "CLOUD";
    String PRESENTATION_TYPE = "ECOM";
    String CONSUMER_ENTRY_MODE = "UNKNOWN";
    String TOKENIZATION_URI = "provisionedTokens";
    String HEALTHCHECK_URI = "/nws/nwp/cof/v2/wallet/utility/healthcheck/%s/%s";
    String TRANSACT_URI = "/nws/nwp/cof/v2/wallet/account/credentials/ondemand";
    String PROVISON_URI = "/nws/nwp/cof/v2/account/provision";
    String ACCCEPT = "Accept";
    String APPLICATION_JSON = "application/json";
    String CONTENT_TYPE = "Content-Type";
    String CONTENT_TYPE_JSON = "application/json";
    String URI_PATH = "uriPath";
    String RESOURCE_UUID = "resourceUUID";
    String REQUEST_ID = "requestId";

    //Discover
    //TODO -  For header need consumer application certificate
    String PROVTOKEN_HEAD_X_DFS_C_APP_CERT = "X-DFS-C-APP-CERT";
    String PROVTOKEN_HEAD_X_DFS_C_APP_CERT_VALUE ="dfsexxyirXfFyjhE4YfNuWYeUbGqID76WM_GWge3SdHPWuvb4";

    String PROVTOKEN_HEAD_X_DFS_API_PLAN = "X-DFS-API-PLAN";
    String PROVTOKEN_HEAD_X_DFS_API_PLAN_VALUE ="NWS-COF-v2-CERTIFICATION";

    String PROVTOKEN_HEAD_AUTH = "Authorization";
    String PROVTOKEN_HEAD_AUTH_VALUE = "Bearer 75eb3d10-be86-4f09-84e2-58c3f28a90c6";

    String PROVTOKEN_HEAD_CACHE_CONTROL="Cache-Control";
    String PROVTOKEN_HEAD_CACHE_CONTROL_VALUE="no-cache";

    String PROVTOKEN_HEAD_CONTENT_LANGUAGE = "Content-Language";
    String PROVTOKEN_HEAD_CONTENT_LANGUAGE_VALUE="en-US";

    String ACCESS_TOKEN_URI_GRANT_TYPE = "grant_type";
    String ACCESS_TOKEN_URI_GRANT_TYPE_VALUE ="client_credentials";
    String ACCESS_TOKEN_URI_SCOPE="scope";
    String ACCESS_TOKEN_URI_SCOPE_VALUE = "COF";

    String ACCESS_TOKEN_HEAD_AUTH = "Authorization";
    String ACCESS_TOKEN_HEAD_AUTH_VALUE = "Basic bDd4eGE1MGUzNGI4OGQxZTQ3NzlhNjBhOGU2ZmVhYmMwOTZjOjM2YzM3ODc0NDEzNDQzZjZhYTc3MDA4YzA4OTViM2Zj";
    String ACCESS_TOKEN_HEAD_CONTENT_TYPE = "Content-Type";
    String ACCESS_TOKEN_HEAD_CONTENT_TYPE_VALUE="application/x-www-form-urlencoded";
    String ACCESS_TOKEN_HEAD_CACHE_CONTROL="Cache-Control";
    String ACCESS_TOKEN_HEAD_CACHE_CONTROL_VALUE = "no-cache";

    String ACCESS_TOKEN_URI ="auth/oauth/v2/token?grant_type=client_credentials&scope=COF_AdminTrigger";

    String PROGRAM_ID ="2490";
    String DDX_LIFECYCLE_PATH ="nws/nwp/cof/v2/wallet/account/lifecycle";
    String DDX_LIFECYCLE_PATH_MPP = "nws/mpp/cof/v2/wallet/account/lifecycle";
    String NOTIFICATION ="notification";

    String DDX_RESOURCE_PATH ="/nws/nwp/cof/v2/resource";

    String DDXPROGRAM_ID ="2490";
    String LC_CACHE_CONTROL = "Cache-Control";
    String LC_CACHE_CONTROL_VALUE = "no-store";
    String TOKENIZE_APPROVED = "APPROVED";
    String UCAF = "UCAF";

    String TOKEN_REQUEST_PAYLOAD = "tokenRequestPayload";
    String TRANSACT_REQUEST_PAYLOAD = "transactRequestPayload";
    String ACQUIRER_MERCHANT_ID = "acquirerMerchantID";
    String TRANSACT_TYPE = "transactionType";
    String LOCALE = "locale";
    String ROUTER = "ROUTER";

    String TOKEN_REQUEST_ID = "tokenRequestorId";
    String CARD = "card";
    String FUNDING_SOURCE_TYPE = "fundingSourceType";
    String CARD_NUMBER = "cardNumber";
    String EXPIRY_DATE = "expiryDate";
    String YEAR = "year";
    String MONTH = "month";
    String SECURITY_CODE = "securityCode";
    String ACCOUNT = "account";
    String EMAIL = "email";
    String ACCOUNT_TYPE = "accountType";
    String CLIENT_WALLET_ACCOUNT_ID = "clientWalletAccountID";
    String CLIENT_DEVICE_ID = "clientDeviceID";
    String DEVICE_IP4_ADDRESS = "ip4Address";
    String DEVICE_LOCATION = "location";

    String STREET_ADDRESS = "streetAddress";
    String COUNTRY = "country";
    String LOCALITY = "locality";
    String POSTCODE = "postalCode";
    String NAME_ON_CARD = "nameOnCard";
    String SOURCE = "source";

    //field descriptions
    String ERROR_FORMAT = "This is a required field and cannot be empty";
    String NULL_PAYLOAD = "Payload cannot be null.";
    String NOT_NUMERIC = "TokenRequestorId must be numeric.";
    String LENGTH_MESSAGE = "%s must be %s in length.";
    String LESS_OR_EQUAL_MESSAGE = "%s must be less than or equal to %s in length.";
    String CARD_NUMBER_RANGE = "CardNumber must be 12 to 19 digit.";
    String YEAR_LENGTH = "Year must be two digits in length.";
    String YEAR_NOT_NUMERIC = "Year must be numeric.";
    String MONTH_LENGTH = "Month must be two digits in length.";
    String MONTH_NOT_NUMERIC = "Month must be numeric.";
    String MONTH_ABOVE_12_BELOW_1 = "Month cannot be greater than 12 and less than 1.";
    String SECURITY_CODE_LENGTH = "The securityCode must be a numeric with length of 3 or 4 digits";
    String TASK_ID = "taskId";
    String TRANSACTION_ID = "transactionId";
    String SEARCH = "search";
    String INVALID_PROGRAM_ID = "The assetId is invalid";
    String INVALID_RESOURCE_UUID_ID = "The resourceUUID is invalid";
    String INVALID_REQUEST_ID = "The requestId is invalid";

    public static final String API_KEY = "apikey=";


}
