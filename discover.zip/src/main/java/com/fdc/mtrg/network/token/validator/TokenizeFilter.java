package com.fdc.mtrg.network.token.validator;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fdc.mtrg.api.*;
import com.fdc.mtrg.network.token.error.ApplicationError;
import com.fdc.mtrg.network.token.util.Constants;
import com.fdc.util.exception.FdcException;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.integration.annotation.Filter;
import org.springframework.messaging.Message;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.stereotype.Service;
import org.springframework.validation.FieldError;

import java.util.ArrayList;
import java.util.List;

@Service
public class TokenizeFilter {
    private static final Logger logger = LoggerFactory.getLogger(TokenizeFilter.class);


    @Autowired
    private ObjectMapper objectMapper;

    public TokenizeFilter() {
    }

    @Filter
    public boolean doValidateRequest(@Header(Constants.MERCHANT_ID) final String pmerchantId,
                                     Message<ProvisionTokenRequest> pRequestMessage) throws FdcException {
        try {
            logger.debug("Request received @ doValidateRequest API for merchant Partner {} and request {} ",
                    pmerchantId, objectMapper.writeValueAsString(pRequestMessage.getPayload()));

            List<FieldError> fieldErrors = new ArrayList<>();
            ProvisionTokenRequest payload = pRequestMessage.getPayload();

            if (payload == null || payload.getProvision() == null) {
                fieldErrors.add(new FieldError(ProvisionTokenRequest.class.getName(), Constants.TOKEN_REQUEST_PAYLOAD, Constants.NULL_PAYLOAD));
            } else {

                if (StringUtils.isBlank(payload.getProvision().getLocale())) {
                    fieldErrors.add(new FieldError(Provision.class.getName(), Constants.LOCALE, Constants.ERROR_FORMAT));
                }

                Card card = payload.getProvision().getCard();

                if (card == null) {
                    fieldErrors.add(new FieldError(Card.class.getName(), Constants.CARD, Constants.ERROR_FORMAT));
                } else {
                    validateCard(fieldErrors, card);
                }
                validateAccount(fieldErrors, payload.getProvision().getAccount());
                validateDevice(fieldErrors, payload.getProvision().getDeviceDetails());
            }
            if (fieldErrors.size() > 0) {
                throw new FdcException(ApplicationError.INVALID_REQUEST.getErrorCode(),
                        ApplicationError.INVALID_REQUEST.getErrorDescription(), fieldErrors, ApplicationError.INVALID_REQUEST.getCategory(), null);
            }
        } catch (JsonProcessingException ex) {
            logger.error(ex.getMessage(), ex);
            throw new FdcException(ApplicationError.INVALID_REQUEST.getErrorCode(),
                    ApplicationError.INVALID_REQUEST.getErrorDescription());

        }
        return true;
    }

    private void validateCard(List<FieldError> fieldErrors, Card card) {

        if (StringUtils.isBlank(card.getCardNumber())) {
            fieldErrors.add(new FieldError(Card.class.getName(), Constants.CARD_NUMBER, Constants.ERROR_FORMAT));
        } else if (!card.getCardNumber().matches("^([0-9]{12,19})$") ){
            fieldErrors.add(new FieldError(Card.class.getName(), Constants.CARD_NUMBER, Constants.CARD_NUMBER_RANGE));
        }
        if (card.getExpiryDate() == null) {
            fieldErrors.add(new FieldError(Card.class.getName(), Constants.EXPIRY_DATE, Constants.ERROR_FORMAT));
        } else {
            ExpiryDate expiryDate = card.getExpiryDate();

            if (StringUtils.isBlank(expiryDate.getYear())) {
                fieldErrors.add(new FieldError(ExpiryDate.class.getName(), Constants.YEAR, Constants.ERROR_FORMAT));
            } else if (!expiryDate.getYear().matches("^[0-9]{2,2}$")) {
                fieldErrors.add(new FieldError(ExpiryDate.class.getName(), Constants.YEAR, Constants.YEAR_LENGTH));
            }

            if (StringUtils.isBlank(expiryDate.getMonth())) {
                fieldErrors.add(new FieldError(ExpiryDate.class.getName(), Constants.MONTH, Constants.ERROR_FORMAT));
            } else if (!expiryDate.getMonth().matches("^[0-9]{2,2}$")) {
                fieldErrors.add(new FieldError(ExpiryDate.class.getName(), Constants.MONTH, Constants.MONTH_LENGTH));
            } else if (!StringUtils.isNumeric(expiryDate.getMonth())) {
                fieldErrors.add(new FieldError(ExpiryDate.class.getName(), Constants.MONTH, Constants.MONTH_NOT_NUMERIC));
            } else if (Integer.valueOf(expiryDate.getMonth()) > 12 || Integer.valueOf(expiryDate.getMonth()) < 1) {
                fieldErrors.add(new FieldError(ExpiryDate.class.getName(), Constants.MONTH, Constants.MONTH_ABOVE_12_BELOW_1));
            }
        }
    }

    private void validateAccount(List<FieldError> fieldErrors, Account account) {
        if (account == null) {
            fieldErrors.add(new FieldError(Account.class.getName(), Constants.ACCOUNT, Constants.ERROR_FORMAT));
        }else {

            if (account.getEmail() == null || StringUtils.isBlank(account.getEmail().getValue())) {
                fieldErrors.add(new FieldError(Account.class.getName(), Constants.EMAIL, Constants.ERROR_FORMAT));

            }
        }
    }

    private void validateDevice(List<FieldError> fieldErrors, DeviceDetails device) {
        if (device != null) {
            DeviceDetailsLoaction deviceLocation = device.getLoaction();

                if (null != deviceLocation) {
                    if (StringUtils.isBlank(deviceLocation.getIpAddress()) || !deviceLocation.getIpAddress().matches("^(\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3})$")) {
                        fieldErrors.add(new FieldError(DeviceDetails.class.getName(), Constants.DEVICE_IP4_ADDRESS, "Is Invalid"));
                    }

                    if(StringUtils.isBlank(deviceLocation.getLatitude()) || !deviceLocation.getLatitude().matches("^([-+]?\\d{1,3}([.]\\d{1,7})?)$")){
                        fieldErrors.add(new FieldError(DeviceDetails.class.getName(), Constants.DEVICE_LOCATION, "lattitude is Invalid"));
                    }

                    if(StringUtils.isBlank(deviceLocation.getLongitude()) || !deviceLocation.getLongitude() .matches("^([-+]?\\d{1,3}([.]\\d{1,7})?)$")){
                        fieldErrors.add(new FieldError(DeviceDetails.class.getName(), Constants.DEVICE_LOCATION, "longitude is Invalid"));
                    }
                }

        }
    }
}
