
package com.fdc.mtrg.network.token.dto;

import java.io.Serializable;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fdc.mtrg.network.token.dto.ResponseHeader;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "responseHeader",
    "accountProvisionResponse"
})
public class ProvisionedTokenResponseDDX implements Serializable
{

    @JsonProperty("responseHeader")
    private ResponseHeader responseHeader;
    @JsonProperty("accountProvisionResponse")
    private AccountProvisionResponse accountProvisionResponse;
    private final static long serialVersionUID = -2539738329883498514L;

    @JsonProperty("responseHeader")
    public ResponseHeader getResponseHeader() {
        return responseHeader;
    }

    @JsonProperty("responseHeader")
    public void setResponseHeader(ResponseHeader responseHeader) {
        this.responseHeader = responseHeader;
    }

    @JsonProperty("accountProvisionResponse")
    public AccountProvisionResponse getAccountProvisionResponse() {
        return accountProvisionResponse;
    }

    @JsonProperty("accountProvisionResponse")
    public void setAccountProvisionResponse(AccountProvisionResponse accountProvisionResponse) {
        this.accountProvisionResponse = accountProvisionResponse;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("responseHeader", responseHeader).append("accountProvisionResponse", accountProvisionResponse).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(responseHeader).append(accountProvisionResponse).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof ProvisionedTokenResponseDDX) == false) {
            return false;
        }
        ProvisionedTokenResponseDDX rhs = ((ProvisionedTokenResponseDDX) other);
        return new EqualsBuilder().append(responseHeader, rhs.responseHeader).append(accountProvisionResponse, rhs.accountProvisionResponse).isEquals();
    }

}
