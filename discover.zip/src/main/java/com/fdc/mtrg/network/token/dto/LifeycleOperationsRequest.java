
package com.fdc.mtrg.network.token.dto;

import java.io.Serializable;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "tokenId"
})
public class LifeycleOperationsRequest implements Serializable
{

    @JsonProperty("tokenId")
    private String tokenId;
    private final static long serialVersionUID = -4967850052280588715L;

    @JsonProperty("tokenId")
    public String getTokenId() {
        return tokenId;
    }

    @JsonProperty("tokenId")
    public void setTokenId(String tokenId) {
        this.tokenId = tokenId;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("tokenId", tokenId).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(tokenId).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof LifeycleOperationsRequest) == false) {
            return false;
        }
        LifeycleOperationsRequest rhs = ((LifeycleOperationsRequest) other);
        return new EqualsBuilder().append(tokenId, rhs.tokenId).isEquals();
    }

}
