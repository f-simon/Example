package com.fdc.mtrg.network.token.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.util.Objects;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "token",
        "tokenExpDate",
        "tokenSeqNum"
})
public class TokenContext {

    @JsonProperty("token")
    private String token;
    @JsonProperty("tokenExpDate")
    private String tokenExpDate;
    @JsonProperty("tokenSeqNum")
    private String tokenSeqNum;

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getTokenExpDate() {
        return tokenExpDate;
    }

    public void setTokenExpDate(String tokenExpDate) {
        this.tokenExpDate = tokenExpDate;
    }

    public String getTokenSeqNum() {
        return tokenSeqNum;
    }

    public void setTokenSeqNum(String tokenSeqNum) {
        this.tokenSeqNum = tokenSeqNum;
    }

    @Override
    public String toString() {
        return "TokenContext{" +
                "token='" + token + '\'' +
                ", tokenExpDate='" + tokenExpDate + '\'' +
                ", tokenSeqNum='" + tokenSeqNum + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        TokenContext that = (TokenContext) o;
        return Objects.equals(token, that.token) &&
                Objects.equals(tokenExpDate, that.tokenExpDate) &&
                Objects.equals(tokenSeqNum, that.tokenSeqNum);
    }

    @Override
    public int hashCode() {
        return Objects.hash(token, tokenExpDate, tokenSeqNum);
    }
}
