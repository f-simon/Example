package com.fdc.mtrg.network.token.dto.transact;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fdc.mtrg.network.token.dto.RequestHeader;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TransactRequestDDX {
    @JsonProperty("requestHeader")
    private RequestHeader requestHeader;

    @JsonProperty("onDemandCredentialsRequest")
    private OnDemandCredentialsRequest onDemandCredentialsRequest;

    public RequestHeader getRequestHeader() {
        return requestHeader;
    }

    public void setRequestHeader(RequestHeader requestHeader) {
        this.requestHeader = requestHeader;
    }

    public OnDemandCredentialsRequest getOnDemandCredentialsRequest() {
        return onDemandCredentialsRequest;
    }

    public void setOnDemandCredentialsRequest(OnDemandCredentialsRequest onDemandCredentialsRequest) {
        this.onDemandCredentialsRequest = onDemandCredentialsRequest;
    }
}
