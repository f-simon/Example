
package com.fdc.mtrg.network.token.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "EncryptedContext",
        "provisioningDecision",
        "provisioningMetadata",
        "issuerContext",
        "accountMetadataContext"
})
public class AccountProvisionResponse implements Serializable {

    @JsonProperty("EncryptedContext")
    private EncryptedContextResponse encryptedContext;
    @JsonProperty("provisioningDecision")
    private String provisioningDecision;
    @JsonProperty("provisioningMetadata")
    private ProvisioningMetadata provisioningMetadata;
    @JsonProperty("issuerContext")
    private IssuerContext issuerContext;
    @JsonProperty("accountMetadataContext")
    private AccountMetadataContext accountMetadataContext;
    private final static long serialVersionUID = 3907781566504233817L;

    @JsonProperty("EncryptedContext")
    public EncryptedContextResponse getEncryptedContext() {
        return encryptedContext;
    }

    @JsonProperty("EncryptedContext")
    public void setEncryptedContext(EncryptedContextResponse encryptedContext) {
        this.encryptedContext = encryptedContext;
    }

    @JsonProperty("provisioningDecision")
    public String getProvisioningDecision() {
        return provisioningDecision;
    }

    @JsonProperty("provisioningDecision")
    public void setProvisioningDecision(String provisioningDecision) {
        this.provisioningDecision = provisioningDecision;
    }

    @JsonProperty("provisioningMetadata")
    public ProvisioningMetadata getProvisioningMetadata() {
        return provisioningMetadata;
    }

    @JsonProperty("provisioningMetadata")
    public void setProvisioningMetadata(ProvisioningMetadata provisioningMetadata) {
        this.provisioningMetadata = provisioningMetadata;
    }

    @JsonProperty("issuerContext")
    public IssuerContext getIssuerContext() {
        return issuerContext;
    }

    @JsonProperty("issuerContext")
    public void setIssuerContext(IssuerContext issuerContext) {
        this.issuerContext = issuerContext;
    }

    @JsonProperty("accountMetadataContext")
    public AccountMetadataContext getAccountMetadataContext() {
        return accountMetadataContext;
    }

    @JsonProperty("accountMetadataContext")
    public void setAccountMetadataContext(AccountMetadataContext accountMetadataContext) {
        this.accountMetadataContext = accountMetadataContext;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("encryptedContext", encryptedContext).append("provisioningDecision", provisioningDecision).append("provisioningMetadata", provisioningMetadata).append("issuerContext", issuerContext).append("accountMetadataContext", accountMetadataContext).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(encryptedContext).append(provisioningDecision).append(issuerContext).append(provisioningMetadata).append(accountMetadataContext).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof AccountProvisionResponse) == false) {
            return false;
        }
        AccountProvisionResponse rhs = ((AccountProvisionResponse) other);
        return new EqualsBuilder().append(encryptedContext, rhs.encryptedContext).append(provisioningDecision, rhs.provisioningDecision).append(issuerContext, rhs.issuerContext).append(provisioningMetadata, rhs.provisioningMetadata).append(accountMetadataContext, rhs.accountMetadataContext).isEquals();
    }

}
