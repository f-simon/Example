package com.fdc.mtrg.network.token.enricher;

import com.fdc.mtrg.api.Operation;
import com.fdc.mtrg.api.UpdateTokenRequest;

import com.fdc.mtrg.network.token.error.ApplicationError;
import com.fdc.mtrg.network.token.util.Constants;
import com.fdc.util.exception.FdcException;
import com.fdc.util.exception.types.FdcSystemException;
import com.fdc.util.logging.SimpleAroundLog;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.messaging.Message;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.stereotype.Component;
import org.springframework.validation.FieldError;

import java.util.ArrayList;
import java.util.List;

@Component
public class OperationTypeHeaderEnricher {

    private static final Logger logger = LoggerFactory.getLogger(OperationTypeHeaderEnricher.class);

    @SimpleAroundLog
    public String identifyOperations(@Header(Constants.MERCHANT_ID) final String merchantId,
                                     @Header(Constants.PROVISION_TOKEN_ID) final String tokenReferenceId,
                                     Message<UpdateTokenRequest> updateTokenRequest) throws FdcSystemException, FdcException {

        logger.debug("Request received @ identifyOperations API for merchant Partner {}", merchantId);

        UpdateTokenRequest payload = updateTokenRequest.getPayload();
        switch (payload.getOperation()) {
            case SUSPEND:
                return Operation.SUSPEND.getValue();
            case RESUME:
                return Operation.RESUME.getValue();
            case DELETE:
                return Operation.DELETE.getValue();
            default:
                List<FieldError> fieldErrors = new ArrayList<>();
                fieldErrors.add(new FieldError("Invalid Operation", "Invalid Operation", "Invalid Operation Type."));
                throw new FdcException(ApplicationError.INVALID_REQUEST.getErrorCode(), ApplicationError.INVALID_REQUEST.getErrorDescription(), fieldErrors);
        }
    }
}
