package com.fdc.mtrg.network.token.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.io.Serializable;
import java.util.Objects;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "tokenContext",
        "accountContext"
})
public class CredentialsContext implements Serializable {

    @JsonProperty("tokenContext")
    private TokenContext tokenContext;
    @JsonProperty("accountContext")
    private AccountContext accountContext;

    public TokenContext getTokenContext() {
        return tokenContext;
    }

    public void setTokenContext(TokenContext tokenContext) {
        this.tokenContext = tokenContext;
    }

    public AccountContext getAccountContext() {
        return accountContext;
    }

    public void setAccountContext(AccountContext accountContext) {
        this.accountContext = accountContext;
    }

    @Override
    public String toString() {
        return "CredentialsContext{" +
                "tokenContext=" + tokenContext +
                ", accountContext=" + accountContext +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CredentialsContext that = (CredentialsContext) o;
        return Objects.equals(tokenContext, that.tokenContext) &&
                Objects.equals(accountContext, that.accountContext);
    }

    @Override
    public int hashCode() {
        return Objects.hash(tokenContext, accountContext);
    }
}
