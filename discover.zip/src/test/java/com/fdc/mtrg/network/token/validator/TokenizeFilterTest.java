package com.fdc.mtrg.network.token.validator;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fdc.mtrg.api.DeviceDetails;
import com.fdc.mtrg.api.DeviceDetailsLoaction;
import com.fdc.mtrg.api.Email;
import com.fdc.mtrg.api.ProvisionTokenRequest;
import com.fdc.mtrg.network.token.error.ApplicationError;
import com.fdc.mtrg.network.token.util.Constants;
import com.fdc.util.exception.FdcException;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.messaging.Message;
import org.springframework.validation.FieldError;

import java.util.List;

import static com.fdc.mtrg.network.token.utils.TestUtils.*;
import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class TokenizeFilterTest {
    @Rule
    public ExpectedException expectedException = ExpectedException.none();

    @Mock
    private ObjectMapper objectMapper;

    @Mock
    Message<ProvisionTokenRequest> pRequestMessage;

    @InjectMocks
    private TokenizeFilter tokenizeFilter;

    private ProvisionTokenRequest provisionTokenRequest;

    @Before
    public void before() throws Exception {
        provisionTokenRequest = getTokenRequest(ProvisionTokenRequest.class);
        when(pRequestMessage.getPayload()).thenReturn(provisionTokenRequest);
        when(objectMapper.writeValueAsString(any())).thenReturn(REQUEST_PAYLOAD);
    }

    @Test
    public void testDoValidateRequest() throws Exception {
        assertTrue(tokenizeFilter.doValidateRequest(MERCHANT_ID, pRequestMessage));
    }

    @Test
    public void testDoValidateRequest_JsonProcessingException() throws Exception {
        when(objectMapper.writeValueAsString(any())).thenThrow(JsonProcessingException.class);
        expectedException.expect(FdcException.class);
        expectedException.expectMessage(ApplicationError.INVALID_REQUEST.getErrorDescription());

        tokenizeFilter.doValidateRequest(MERCHANT_ID, pRequestMessage);
    }

    @Test
    public void testDoValidateRequest_invalid_payload_null() {
        when(pRequestMessage.getPayload()).thenReturn(null);
        try {
            tokenizeFilter.doValidateRequest(MERCHANT_ID, pRequestMessage);
        } catch (Exception ex) {
            assertTrue(ex instanceof FdcException);
            FdcException fdcException = (FdcException) ex;
            assertEquals(ApplicationError.INVALID_REQUEST.getErrorCode(), fdcException.getCode());
            assertEquals(ApplicationError.INVALID_REQUEST.getErrorDescription(), fdcException.getMessage());

            List<FieldError> fieldErrors = fdcException.getFieldError();
            assertNotNull(fieldErrors);

            FieldError fieldError = fieldErrors.get(0);
            assertEquals(Constants.TOKEN_REQUEST_PAYLOAD, fieldError.getField());
            assertEquals(Constants.NULL_PAYLOAD, fieldError.getDefaultMessage());
        }
    }

    @Test
    public void testDoValidateRequest_invalid_local_null() {
        pRequestMessage.getPayload().getProvision().setLocale(null);
        when(pRequestMessage.getPayload()).thenReturn(provisionTokenRequest);
        try {
            tokenizeFilter.doValidateRequest(MERCHANT_ID, pRequestMessage);
        } catch (Exception ex) {
            assertTrue(ex instanceof FdcException);
            FdcException fdcException = (FdcException) ex;
            assertEquals(ApplicationError.INVALID_REQUEST.getErrorCode(), fdcException.getCode());
            assertEquals(ApplicationError.INVALID_REQUEST.getErrorDescription(), fdcException.getMessage());

            List<FieldError> fieldErrors = fdcException.getFieldError();
            assertNotNull(fieldErrors);

            FieldError fieldError = fieldErrors.get(0);
            assertEquals(Constants.LOCALE, fieldError.getField());
            assertEquals(Constants.ERROR_FORMAT, fieldError.getDefaultMessage());
        }
    }

    @Test
    public void testCard_invalid_card_null() {
        provisionTokenRequest.getProvision().setCard(null);
        when(pRequestMessage.getPayload()).thenReturn(provisionTokenRequest);
        try {
            tokenizeFilter.doValidateRequest(MERCHANT_ID, pRequestMessage);
        } catch (Exception ex) {
            assertTrue(ex instanceof FdcException);
            FdcException fdcException = (FdcException) ex;
            assertEquals(ApplicationError.INVALID_REQUEST.getErrorCode(), fdcException.getCode());
            assertEquals(ApplicationError.INVALID_REQUEST.getErrorDescription(), fdcException.getMessage());

            List<FieldError> fieldErrors = fdcException.getFieldError();
            assertNotNull(fieldErrors);

            FieldError fieldError = fieldErrors.get(0);
            assertEquals(Constants.CARD, fieldError.getField());
            assertEquals(Constants.ERROR_FORMAT, fieldError.getDefaultMessage());
        }
    }

    @Test
    public void testCard_invalid_card_number_blank() {
        provisionTokenRequest.getProvision().getCard().setCardNumber(" ");
        when(pRequestMessage.getPayload()).thenReturn(provisionTokenRequest);
        try {
            tokenizeFilter.doValidateRequest(MERCHANT_ID, pRequestMessage);
        } catch (Exception ex) {
            assertTrue(ex instanceof FdcException);
            FdcException fdcException = (FdcException) ex;
            assertEquals(ApplicationError.INVALID_REQUEST.getErrorCode(), fdcException.getCode());
            assertEquals(ApplicationError.INVALID_REQUEST.getErrorDescription(), fdcException.getMessage());

            List<FieldError> fieldErrors = fdcException.getFieldError();
            assertNotNull(fieldErrors);

            FieldError fieldError = fieldErrors.get(0);
            assertEquals(Constants.CARD_NUMBER, fieldError.getField());
            assertEquals(Constants.ERROR_FORMAT, fieldError.getDefaultMessage());
        }
    }

    @Test
    public void testCard_invalid_card_number_wrong_size() {
        provisionTokenRequest.getProvision().getCard().setCardNumber("12345678");
        when(pRequestMessage.getPayload()).thenReturn(provisionTokenRequest);
        try {
            tokenizeFilter.doValidateRequest(MERCHANT_ID, pRequestMessage);
        } catch (Exception ex) {
            assertTrue(ex instanceof FdcException);
            FdcException fdcException = (FdcException) ex;
            assertEquals(ApplicationError.INVALID_REQUEST.getErrorCode(), fdcException.getCode());
            assertEquals(ApplicationError.INVALID_REQUEST.getErrorDescription(), fdcException.getMessage());

            List<FieldError> fieldErrors = fdcException.getFieldError();
            assertNotNull(fieldErrors);

            FieldError fieldError = fieldErrors.get(0);
            assertEquals(Constants.CARD_NUMBER, fieldError.getField());
            assertEquals(Constants.CARD_NUMBER_RANGE, fieldError.getDefaultMessage());
        }
    }

    @Test
    public void testCard_invalid_card_expiryDate_null() {
        provisionTokenRequest.getProvision().getCard().setExpiryDate(null);
        when(pRequestMessage.getPayload()).thenReturn(provisionTokenRequest);
        try {
            tokenizeFilter.doValidateRequest(MERCHANT_ID, pRequestMessage);
        } catch (Exception ex) {
            assertTrue(ex instanceof FdcException);
            FdcException fdcException = (FdcException) ex;
            assertEquals(ApplicationError.INVALID_REQUEST.getErrorCode(), fdcException.getCode());
            assertEquals(ApplicationError.INVALID_REQUEST.getErrorDescription(), fdcException.getMessage());

            List<FieldError> fieldErrors = fdcException.getFieldError();
            assertNotNull(fieldErrors);

            FieldError fieldError = fieldErrors.get(0);
            assertEquals(Constants.EXPIRY_DATE, fieldError.getField());
            assertEquals(Constants.ERROR_FORMAT, fieldError.getDefaultMessage());
        }
    }

    @Test
    public void testCard_invalid_card_expiryDate_years_blank() {
        provisionTokenRequest.getProvision().getCard().getExpiryDate().setYear(" ");
        when(pRequestMessage.getPayload()).thenReturn(provisionTokenRequest);
        try {
            tokenizeFilter.doValidateRequest(MERCHANT_ID, pRequestMessage);
        } catch (Exception ex) {
            assertTrue(ex instanceof FdcException);
            FdcException fdcException = (FdcException) ex;
            assertEquals(ApplicationError.INVALID_REQUEST.getErrorCode(), fdcException.getCode());
            assertEquals(ApplicationError.INVALID_REQUEST.getErrorDescription(), fdcException.getMessage());

            List<FieldError> fieldErrors = fdcException.getFieldError();
            assertNotNull(fieldErrors);

            FieldError fieldError = fieldErrors.get(0);
            assertEquals(Constants.YEAR, fieldError.getField());
            assertEquals(Constants.ERROR_FORMAT, fieldError.getDefaultMessage());
        }
    }

    @Test
    public void testCard_invalid_card_expiryDate_year_wrong_size() {
        provisionTokenRequest.getProvision().getCard().getExpiryDate().setYear("123");
        when(pRequestMessage.getPayload()).thenReturn(provisionTokenRequest);
        try {
            tokenizeFilter.doValidateRequest(MERCHANT_ID, pRequestMessage);
        } catch (Exception ex) {
            assertTrue(ex instanceof FdcException);
            FdcException fdcException = (FdcException) ex;
            assertEquals(ApplicationError.INVALID_REQUEST.getErrorCode(), fdcException.getCode());
            assertEquals(ApplicationError.INVALID_REQUEST.getErrorDescription(), fdcException.getMessage());

            List<FieldError> fieldErrors = fdcException.getFieldError();
            assertNotNull(fieldErrors);

            FieldError fieldError = fieldErrors.get(0);
            assertEquals(Constants.YEAR, fieldError.getField());
            assertEquals(Constants.YEAR_LENGTH, fieldError.getDefaultMessage());
        }
    }

    @Test
    public void testCard_invalid_card_expiryDate_year_non_numeric() {
        provisionTokenRequest.getProvision().getCard().getExpiryDate().setYear("1a");
        when(pRequestMessage.getPayload()).thenReturn(provisionTokenRequest);
        try {
            tokenizeFilter.doValidateRequest(MERCHANT_ID, pRequestMessage);
        } catch (Exception ex) {
            assertTrue(ex instanceof FdcException);
            FdcException fdcException = (FdcException) ex;
            assertEquals(ApplicationError.INVALID_REQUEST.getErrorCode(), fdcException.getCode());
            assertEquals(ApplicationError.INVALID_REQUEST.getErrorDescription(), fdcException.getMessage());

            List<FieldError> fieldErrors = fdcException.getFieldError();
            assertNotNull(fieldErrors);

            FieldError fieldError = fieldErrors.get(0);
            assertEquals(Constants.YEAR, fieldError.getField());
            assertEquals(Constants.YEAR_LENGTH, fieldError.getDefaultMessage());
        }
    }

    @Test
    public void testCard_invalid_card_expiryDate_month_blank() {
        provisionTokenRequest.getProvision().getCard().getExpiryDate().setMonth(" ");
        when(pRequestMessage.getPayload()).thenReturn(provisionTokenRequest);
        try {
            tokenizeFilter.doValidateRequest(MERCHANT_ID, pRequestMessage);
        } catch (Exception ex) {
            assertTrue(ex instanceof FdcException);
            FdcException fdcException = (FdcException) ex;
            assertEquals(ApplicationError.INVALID_REQUEST.getErrorCode(), fdcException.getCode());
            assertEquals(ApplicationError.INVALID_REQUEST.getErrorDescription(), fdcException.getMessage());

            List<FieldError> fieldErrors = fdcException.getFieldError();
            assertNotNull(fieldErrors);

            FieldError fieldError = fieldErrors.get(0);
            assertEquals(Constants.MONTH, fieldError.getField());
            assertEquals(Constants.ERROR_FORMAT, fieldError.getDefaultMessage());
        }
    }

    @Test
    public void testCard_invalid_card_expiryDate_month_wrong_size() {
        provisionTokenRequest.getProvision().getCard().getExpiryDate().setMonth("123");
        when(pRequestMessage.getPayload()).thenReturn(provisionTokenRequest);
        try {
            tokenizeFilter.doValidateRequest(MERCHANT_ID, pRequestMessage);
        } catch (Exception ex) {
            assertTrue(ex instanceof FdcException);
            FdcException fdcException = (FdcException) ex;
            assertEquals(ApplicationError.INVALID_REQUEST.getErrorCode(), fdcException.getCode());
            assertEquals(ApplicationError.INVALID_REQUEST.getErrorDescription(), fdcException.getMessage());

            List<FieldError> fieldErrors = fdcException.getFieldError();
            assertNotNull(fieldErrors);

            FieldError fieldError = fieldErrors.get(0);
            assertEquals(Constants.MONTH, fieldError.getField());
            assertEquals(Constants.MONTH_LENGTH, fieldError.getDefaultMessage());
        }
    }

    @Test
    public void testCard_invalid_card_expiryDate_month_non_numeric() {
        provisionTokenRequest.getProvision().getCard().getExpiryDate().setMonth("1a");
        when(pRequestMessage.getPayload()).thenReturn(provisionTokenRequest);
        try {
            tokenizeFilter.doValidateRequest(MERCHANT_ID, pRequestMessage);
        } catch (Exception ex) {
            assertTrue(ex instanceof FdcException);
            FdcException fdcException = (FdcException) ex;
            assertEquals(ApplicationError.INVALID_REQUEST.getErrorCode(), fdcException.getCode());
            assertEquals(ApplicationError.INVALID_REQUEST.getErrorDescription(), fdcException.getMessage());

            List<FieldError> fieldErrors = fdcException.getFieldError();
            assertNotNull(fieldErrors);

            FieldError fieldError = fieldErrors.get(0);
            assertEquals(Constants.MONTH, fieldError.getField());
            assertEquals(Constants.MONTH_LENGTH, fieldError.getDefaultMessage());
        }
    }


    @Test
    public void testAccount_invalid_null() {
        provisionTokenRequest.getProvision().setAccount(null);
        when(pRequestMessage.getPayload()).thenReturn(provisionTokenRequest);
        try {
            tokenizeFilter.doValidateRequest(MERCHANT_ID, pRequestMessage);
        } catch (Exception ex) {
            assertTrue(ex instanceof FdcException);
            FdcException fdcException = (FdcException) ex;
            assertEquals(ApplicationError.INVALID_REQUEST.getErrorCode(), fdcException.getCode());
            assertEquals(ApplicationError.INVALID_REQUEST.getErrorDescription(), fdcException.getMessage());

            List<FieldError> fieldErrors = fdcException.getFieldError();
            assertNotNull(fieldErrors);

            FieldError fieldError = fieldErrors.get(0);
            assertEquals(Constants.ACCOUNT, fieldError.getField());
            assertEquals(Constants.ERROR_FORMAT, fieldError.getDefaultMessage());
        }
    }
    @Test
    public void testAccount_invalid_email_null() {
        provisionTokenRequest.getProvision().getAccount().setEmail(null);
        when(pRequestMessage.getPayload()).thenReturn(provisionTokenRequest);
        try {
            tokenizeFilter.doValidateRequest(MERCHANT_ID, pRequestMessage);
        } catch (Exception ex) {
            assertTrue(ex instanceof FdcException);
            FdcException fdcException = (FdcException) ex;
            assertEquals(ApplicationError.INVALID_REQUEST.getErrorCode(), fdcException.getCode());
            assertEquals(ApplicationError.INVALID_REQUEST.getErrorDescription(), fdcException.getMessage());

            List<FieldError> fieldErrors = fdcException.getFieldError();
            assertNotNull(fieldErrors);

            FieldError fieldError = fieldErrors.get(0);
            assertEquals(Constants.EMAIL, fieldError.getField());
            assertEquals(Constants.ERROR_FORMAT, fieldError.getDefaultMessage());
        }
    }
 //   @Test       for MTRG response transformer
    public void testAccount_invalid_clientWalletAccountID_null() {
        provisionTokenRequest.getProvision().getAccount().setClientWalletAccountId(null);
        when(pRequestMessage.getPayload()).thenReturn(provisionTokenRequest);
        try {
            tokenizeFilter.doValidateRequest(MERCHANT_ID, pRequestMessage);
        } catch (Exception ex) {
            assertTrue(ex instanceof FdcException);
            FdcException fdcException = (FdcException) ex;
            assertEquals(ApplicationError.INVALID_REQUEST.getErrorCode(), fdcException.getCode());
            assertEquals(ApplicationError.INVALID_REQUEST.getErrorDescription(), fdcException.getMessage());

            List<FieldError> fieldErrors = fdcException.getFieldError();
            assertNotNull(fieldErrors);

            FieldError fieldError = fieldErrors.get(0);
            assertEquals(Constants.CLIENT_WALLET_ACCOUNT_ID, fieldError.getField());
            assertEquals(Constants.ERROR_FORMAT, fieldError.getDefaultMessage());
        }
    }


  //  @Test  for MTRG response transformer
    public void testAccount_invalid_clientWalletAccountID_blank() {
        provisionTokenRequest.getProvision().getAccount().setClientWalletAccountId("   ");
        when(pRequestMessage.getPayload()).thenReturn(provisionTokenRequest);
        try {
            tokenizeFilter.doValidateRequest(MERCHANT_ID, pRequestMessage);
        } catch (Exception ex) {
            assertTrue(ex instanceof FdcException);
            FdcException fdcException = (FdcException) ex;
            assertEquals(ApplicationError.INVALID_REQUEST.getErrorCode(), fdcException.getCode());
            assertEquals(ApplicationError.INVALID_REQUEST.getErrorDescription(), fdcException.getMessage());

            List<FieldError> fieldErrors = fdcException.getFieldError();
            assertNotNull(fieldErrors);

            FieldError fieldError = fieldErrors.get(0);
            assertEquals(Constants.CLIENT_WALLET_ACCOUNT_ID, fieldError.getField());
            assertEquals(Constants.ERROR_FORMAT, fieldError.getDefaultMessage());
        }
    }

 //   @Test  for MTRG response transformer
    public void testAccount_invalid_clientWalletAccountEmailAddress_size() {
        Email email = new Email();
        email.setValue("0123456789@0123456789012345678901234567890123456789.0123456789");
        provisionTokenRequest.getProvision().getAccount().setEmail(email);
        when(pRequestMessage.getPayload()).thenReturn(provisionTokenRequest);
        try {
            tokenizeFilter.doValidateRequest(MERCHANT_ID, pRequestMessage);
        } catch (Exception ex) {
            assertTrue(ex instanceof FdcException);
            FdcException fdcException = (FdcException) ex;
            assertEquals(ApplicationError.INVALID_REQUEST.getErrorCode(), fdcException.getCode());
            assertEquals(ApplicationError.INVALID_REQUEST.getErrorDescription(), fdcException.getMessage());

            List<FieldError> fieldErrors = fdcException.getFieldError();
            assertNotNull(fieldErrors);

            FieldError fieldError = fieldErrors.get(0);
            assertEquals(Constants.EMAIL, fieldError.getField());
            assertEquals(String.format(Constants.LESS_OR_EQUAL_MESSAGE, Constants.EMAIL, "48"), fieldError.getDefaultMessage());
        }
    }

    @Test
    public void testDevice_invalid_ip_null() {
        DeviceDetails deviceDetails = provisionTokenRequest.getProvision().getDeviceDetails();
        DeviceDetailsLoaction location = deviceDetails.getLoaction();
        location.setIpAddress(null);
        deviceDetails.setLoaction(location);
        provisionTokenRequest.getProvision().setDeviceDetails(deviceDetails);
        when(pRequestMessage.getPayload()).thenReturn(provisionTokenRequest);
        try {
            tokenizeFilter.doValidateRequest(MERCHANT_ID, pRequestMessage);
        } catch (Exception ex) {
            assertTrue(ex instanceof FdcException);
            FdcException fdcException = (FdcException) ex;
            assertEquals(ApplicationError.INVALID_REQUEST.getErrorCode(), fdcException.getCode());
            assertEquals(ApplicationError.INVALID_REQUEST.getErrorDescription(), fdcException.getMessage());

            List<FieldError> fieldErrors = fdcException.getFieldError();
            assertNotNull(fieldErrors);

            FieldError fieldError = fieldErrors.get(0);
            assertEquals(Constants.DEVICE_IP4_ADDRESS, fieldError.getField());
            assertEquals("Is Invalid", fieldError.getDefaultMessage());
        }
    }

    @Test
    public void testDevice_invalid_Latitude() {
        DeviceDetails deviceDetails = provisionTokenRequest.getProvision().getDeviceDetails();
        DeviceDetailsLoaction location = deviceDetails.getLoaction();
        location.setLatitude("0123456789");
        deviceDetails.setLoaction(location);
        provisionTokenRequest.getProvision().setDeviceDetails(deviceDetails);
        when(pRequestMessage.getPayload()).thenReturn(provisionTokenRequest);
        try {
            tokenizeFilter.doValidateRequest(MERCHANT_ID, pRequestMessage);
        } catch (Exception ex) {
            assertTrue(ex instanceof FdcException);
            FdcException fdcException = (FdcException) ex;
            assertEquals(ApplicationError.INVALID_REQUEST.getErrorCode(), fdcException.getCode());
            assertEquals(ApplicationError.INVALID_REQUEST.getErrorDescription(), fdcException.getMessage());

            List<FieldError> fieldErrors = fdcException.getFieldError();
            assertNotNull(fieldErrors);

            FieldError fieldError = fieldErrors.get(0);
            assertEquals(Constants.DEVICE_LOCATION, fieldError.getField());
            assertEquals("lattitude is Invalid", fieldError.getDefaultMessage());
        }
    }

    @Test
    public void testDevice_invalid_Longitude() {
        DeviceDetails deviceDetails = provisionTokenRequest.getProvision().getDeviceDetails();
        DeviceDetailsLoaction location = deviceDetails.getLoaction();
        location.setLongitude("0123456789012345");
        deviceDetails.setLoaction(location);
        provisionTokenRequest.getProvision().setDeviceDetails(deviceDetails);
        when(pRequestMessage.getPayload()).thenReturn(provisionTokenRequest);
        try {
            tokenizeFilter.doValidateRequest(MERCHANT_ID, pRequestMessage);
        } catch (Exception ex) {
            assertTrue(ex instanceof FdcException);
            FdcException fdcException = (FdcException) ex;
            assertEquals(ApplicationError.INVALID_REQUEST.getErrorCode(), fdcException.getCode());
            assertEquals(ApplicationError.INVALID_REQUEST.getErrorDescription(), fdcException.getMessage());

            List<FieldError> fieldErrors = fdcException.getFieldError();
            assertNotNull(fieldErrors);

            FieldError fieldError = fieldErrors.get(0);
            assertEquals(Constants.DEVICE_LOCATION, fieldError.getField());
            assertEquals("longitude is Invalid", fieldError.getDefaultMessage());
        }
    }
}


