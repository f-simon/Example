package com.fdc.mtrg.network.token.transformer;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fdc.mtrg.network.token.dto.UpdateTokensRequestsDDX;
import com.fdc.mtrg.network.token.dto.UpdateTokensResponseDDX;
import com.fdc.util.exception.FdcException;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;


@RunWith(MockitoJUnitRunner.class)
public class CreateLifecycleTransformerResponseTest {

    @Rule
    public ExpectedException expectedException = ExpectedException.none();

    @InjectMocks
    private CreateLifecycleTransformer lifecycleTransformer;

    @Mock
    private ObjectMapper objectMapper;

    private UpdateTokensResponseDDX updateTokensResponseDDX;

    @Before
    public void setUp() throws JsonProcessingException {
        lifecycleTransformer = new CreateLifecycleTransformer();
        setData();
    }

    @Test
    public void testDoTransformResponse_ThenReturn_HttpStatus204() throws JsonProcessingException, FdcException {

        HttpStatus httpStatus = lifecycleTransformer.doTransformResposne("test", updateTokensResponseDDX);
        Assert.assertEquals("Should be equal ", HttpStatus.NO_CONTENT, httpStatus);
    }

    @Test(expected = FdcException.class)
    public void tesatDoTransformResponse_Then_Throw_FdcException() throws JsonProcessingException, FdcException {
        updateTokensResponseDDX.getResponseHeader().setProgramId("1234565");
        HttpStatus httpStatus = lifecycleTransformer.doTransformResposne("test", updateTokensResponseDDX);
    }

    public void setData() throws JsonProcessingException {
        String getUpdateTokensResponseJson =
                "{" +
                        "\"responseHeader\":{" +
                            "\"responseId\":\"5f306b361a134ef48dd1e809a338952d\"," +
                            "\"programId\":\"2490\"" +
                        "}," +
                        "\"accountLifecycleResponse\":{" +
                            "\"lifecycleOperationsResponse\":[" +
                                "{" +
                                    "\"tokenId\":\"ef106a60805440dcdf1f864c24061\"," +
                                    "\"operationStatus\":\"00\"," +
                                     "\"errorCode\":\"\"," +
                                      "\"errorMessage\":\"\"" +
                                "}" +
                            "]" +
                        "}" +
                 "}";


        objectMapper = new ObjectMapper();
        updateTokensResponseDDX = objectMapper.readValue(getUpdateTokensResponseJson, UpdateTokensResponseDDX.class);
    }
}
