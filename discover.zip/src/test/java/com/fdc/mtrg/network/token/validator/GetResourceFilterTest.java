package com.fdc.mtrg.network.token.validator;

import com.fdc.util.exception.FdcException;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;

import static com.fdc.mtrg.network.token.utils.TestUtils.*;

@RunWith(MockitoJUnitRunner.class)
public class GetResourceFilterTest {

    @Autowired
    private GetResourceFilter filter;

    @Before
    public void setUp(){
        filter = new GetResourceFilter();
    }

    @Test
    public void testDoValidateRequest_ThenReturnTrue() throws FdcException {
        Boolean returnTrue = filter.validateAssetRequest(programId, resourceUUID, requestId, merchantId);
        Assert.assertTrue(returnTrue);
    }

    @Test(expected = FdcException.class)
    public void testDoValidateRequest_With_Invalid_Parameters_ThenThrow_FdcException() throws FdcException {
        Boolean returnFalse = filter.validateAssetRequest(badProgramId, badResourceUUID, badRequestId, merchantId);
        Assert.assertTrue(returnFalse);
    }


}

