package com.fdc.mtrg.network.token.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fdc.mtrg.network.token.config.ApplicationProperties;
import com.fdc.mtrg.network.token.dto.healthcheck.HeathcheckResponseDDX;
import com.fdc.mtrg.network.token.error.ApplicationError;
import com.fdc.mtrg.network.token.utils.TestUtils;
import com.fdc.util.exception.FdcException;
import com.fdc.util.exception.model.NVP;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import java.util.List;

import static com.fdc.mtrg.network.token.util.Constants.MERCHANT_ID;
import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class HealthcheckServiceTest {

    @Rule
    public ExpectedException expectedException = ExpectedException.none();

    @Mock
    private ApplicationProperties applicationProperties;

    @Mock
    private RestTemplate restTemplate;

    @Mock
    private ObjectMapper objectMapper;

    @Mock
    private ResponseEntity<HeathcheckResponseDDX> responseEntity;

    @InjectMocks
    private HealthcheckService healthcheckService;

    @Mock
    private HttpClientErrorException errorException;

    private String programId = "programId";
    private String requestId = "requestId";

    @Before
    public void before() throws Exception {
        when(applicationProperties.getServiceUrl()).thenReturn(TestUtils.ROOT_URL);
    }

    @Test
    public void testHealthcheck() throws Exception {
        when(responseEntity.getBody()).thenReturn(TestUtils.getHealthcheckResponse(true, HeathcheckResponseDDX.class));

        when(restTemplate.exchange(anyString(),
                ArgumentMatchers.any(HttpMethod.class),
                ArgumentMatchers.any(),
                ArgumentMatchers.<Class<HeathcheckResponseDDX>>any())).thenReturn(responseEntity);
        HeathcheckResponseDDX responseDDX = healthcheckService.healthcheck(MERCHANT_ID, programId, requestId);

        assertNotNull(responseDDX);
        assertNotNull(responseDDX.getResponseHeader());
        assertNull(responseDDX.getResponseHeader().getErrors());
        assertNotNull(responseDDX.getHealthCheckResponse());
        assertEquals("false", responseDDX.getHealthCheckResponse().getHealthy());
    }

    @Test
    public void testHealthcheck_Errors() throws Exception {
        when(errorException.getResponseBodyAsString()).thenReturn(TestUtils.HEALTHCHECK_ERROR_RESPONSE);
        when(objectMapper.readValue(TestUtils.HEALTHCHECK_ERROR_RESPONSE, HeathcheckResponseDDX.class)).thenReturn(TestUtils.getHealthcheckResponse(false, HeathcheckResponseDDX.class));
                //.thenReturn(TestUtils.getHealthcheckResponse(false, HeathcheckResponseDDX.class))
        when(restTemplate.exchange(anyString(),
                ArgumentMatchers.any(HttpMethod.class),
                ArgumentMatchers.any(),
                ArgumentMatchers.<Class<HeathcheckResponseDDX>>any())).thenThrow(errorException);
        try {
            healthcheckService.healthcheck(MERCHANT_ID, programId, requestId);
        } catch (Exception ex) {
            assertTrue(ex instanceof FdcException);
            FdcException fdcException = (FdcException) ex;
            assertEquals(ApplicationError.INVALID_REQUEST.getErrorCode(), fdcException.getCode());
            assertEquals(ApplicationError.INVALID_REQUEST.getErrorDescription(), fdcException.getMessage());

            List<NVP>  extraInfos = fdcException.getHostExtraInfo();
            assertNotNull(extraInfos);

            NVP extraInfo = extraInfos.get(0);
            assertNotNull(extraInfo);
            assertEquals("10024", extraInfo.getName());
        }
    }
}
