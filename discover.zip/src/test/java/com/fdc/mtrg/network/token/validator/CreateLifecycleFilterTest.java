package com.fdc.mtrg.network.token.validator;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fdc.mtrg.api.*;
import com.fdc.util.exception.FdcException;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;

@RunWith(MockitoJUnitRunner.class)
public class CreateLifecycleFilterTest {

    @Mock
    private UpdateTokenRequest updateTokenRequest;

    @Mock
    private ObjectMapper objectMapper;

    @InjectMocks
    private CreateLifecycleFilter lifecycleSuspendFilter;

    @Before
    public void setUp() {
        setData();

    }
    @Test()
    public void testDoValidateRequest_ThenReturnTrue() throws FdcException, JsonProcessingException {
        Message<UpdateTokenRequest> msg = MessageBuilder.withPayload(updateTokenRequest).build();
        boolean returnValue = lifecycleSuspendFilter.doValidateRequest("test", "DWSPMC000000000132d72d4fcb2f4136a0532d3093ff1a45", msg);
    }

    @Test(expected = FdcException.class)
    public void testDoValidateRequest_ThenThrowException() throws FdcException, JsonProcessingException {
        Message<UpdateTokenRequest> msg = MessageBuilder.withPayload(new UpdateTokenRequest()).build();
        boolean returnValue = lifecycleSuspendFilter.doValidateRequest("test","DWSPMC000000000132d72d4fcb2f4136a0532d3093ff1a45",msg);
    }


    @Test(expected = FdcException.class)
    public void testDoValidateRequest_without_Reason_ThenThrowException() throws FdcException, JsonProcessingException {
        Message<UpdateTokenRequest> msg = MessageBuilder.withPayload(updateTokenRequest).build();
        updateTokenRequest.getUpdateReason().setReason(null);
        boolean returnValue = lifecycleSuspendFilter.doValidateRequest("test", "DWSDWSPMC000000000132d72d4fcb2f4136a0532d3093ff1a45", msg);

    }

    @Test(expected = FdcException.class)
    public void testDoValidateRequest_without_TSPID_ThenThrowException() throws FdcException, JsonProcessingException {
        Message<UpdateTokenRequest> msg = MessageBuilder.withPayload(updateTokenRequest).build();
        updateTokenRequest.getUpdateReason().setTspId(null);
        boolean returnValue = lifecycleSuspendFilter.doValidateRequest("test", "DWS" ,msg);
    }

    @Test(expected = FdcException.class)
    public void testDoValidateRequest_with_Invalid_TSPID__Length_ThenThrowException() throws FdcException, JsonProcessingException {
        Message<UpdateTokenRequest> msg = MessageBuilder.withPayload(updateTokenRequest).build();
        updateTokenRequest.getUpdateReason().setTspId("1234");
        boolean returnValue = lifecycleSuspendFilter.doValidateRequest("test", "DWS" ,msg);
    }
    private void setData() {
        updateTokenRequest = new UpdateTokenRequest();
        updateTokenRequest.setOperation(Operation.SUSPEND);

        UpdateReason updateReason = new UpdateReason();
        updateReason.setReason("User requested suspend due to lost device");
        updateReason.setTspId(TSPID.DISCOVER.getValue());

        updateTokenRequest.setUpdateReason(updateReason);
    }
}
