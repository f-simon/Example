package com.fdc.mtrg.network.token;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DiscoverAdapterApplicationTests {

	@Test
	void contextLoads() {
	}

}
