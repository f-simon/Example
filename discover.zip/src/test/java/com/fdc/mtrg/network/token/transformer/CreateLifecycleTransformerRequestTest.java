package com.fdc.mtrg.network.token.transformer;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fdc.mtrg.api.*;
import com.fdc.mtrg.network.token.dto.UpdateTokensRequestsDDX;
import com.fdc.mtrg.network.token.util.Constants;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;

@RunWith(MockitoJUnitRunner.class)
public class CreateLifecycleTransformerRequestTest {

    @Rule
    public ExpectedException expectedException = ExpectedException.none();

    @InjectMocks
    private CreateLifecycleTransformer lifecycleSuspendTransformer;

    @Mock
    private ObjectMapper objectMapper;

    @Mock
    private UpdateTokenRequest updateTokenRequest;

    @Before
    public void setUp() {
        setData();
    }

    @Test()
    public void testDoTransformRequest_ThenReturn_UpdateTokensRequestsDDX()throws JsonProcessingException {

        String reason = "User requested suspend due to lost device";
        String programId = Constants.DDXPROGRAM_ID;


        Message<UpdateTokenRequest> msg = MessageBuilder.withPayload(updateTokenRequest).build();
        UpdateTokensRequestsDDX returnRequestSchema  = lifecycleSuspendTransformer.doTransformRequest("test",  "DWSPMC000000000132d72d4fcb2f4136a0532d3093ff1a45", msg);

        Assert.assertEquals("Not equal", reason, returnRequestSchema.getAccountLifecycleRequest().getReason());
        Assert.assertNotNull("Is null", returnRequestSchema.getRequestHeader().getRequestId());
    //    Assert.assertEquals("Is not equal", programId, returnRequestSchema.getRequestHeader().getProgramId());
        Assert.assertNotNull("is null", returnRequestSchema.getRequestHeader().getProgramId());
    }

    @Test()
    public void testDoTransformRequest_ThenReturn_UpdateTokensRequestsDDX_DELETE()throws JsonProcessingException {

        String reason = "User requested suspend due to lost device";
        String programId = Constants.DDXPROGRAM_ID;


        updateTokenRequest.setOperation(Operation.DELETE);
        Message<UpdateTokenRequest> msg = MessageBuilder.withPayload(updateTokenRequest).build();
        UpdateTokensRequestsDDX returnRequestSchema  = lifecycleSuspendTransformer.doTransformRequest("test",  "DWSPMC000000000132d72d4fcb2f4136a0532d3093ff1a45", msg);

        Assert.assertEquals("Not equal", reason, returnRequestSchema.getAccountLifecycleRequest().getReason());
        Assert.assertNotNull("Is null", returnRequestSchema.getRequestHeader().getRequestId());
      //  Assert.assertEquals("Is not equal", programId, returnRequestSchema.getRequestHeader().getProgramId());
        Assert.assertNotNull("is null", returnRequestSchema.getRequestHeader().getProgramId());

    }

    @Test()
    public void testDoTransformRequest_ThenReturn_UpdateTokensRequestsDDX_RESUME()throws JsonProcessingException {

        String reason = "User requested suspend due to lost device";
        String programId = Constants.DDXPROGRAM_ID;


        updateTokenRequest.setOperation(Operation.RESUME);
        Message<UpdateTokenRequest> msg = MessageBuilder.withPayload(updateTokenRequest).build();
        UpdateTokensRequestsDDX returnRequestSchema  = lifecycleSuspendTransformer.doTransformRequest("test",  "DWSPMC000000000132d72d4fcb2f4136a0532d3093ff1a45", msg);

        Assert.assertEquals("Not equal", reason, returnRequestSchema.getAccountLifecycleRequest().getReason());
        Assert.assertNotNull("Is null", returnRequestSchema.getRequestHeader().getRequestId());
      //  Assert.assertEquals("Is not equal", programId, returnRequestSchema.getRequestHeader().getProgramId());
        Assert.assertNotNull("is null", returnRequestSchema.getRequestHeader().getProgramId());
    }
    private void setData() {
        updateTokenRequest = new UpdateTokenRequest();
        updateTokenRequest.setOperation(Operation.SUSPEND);

        UpdateReason updateReason = new UpdateReason();
        updateReason.setReason("User requested suspend due to lost device");
        updateReason.setTspId(TSPID.DISCOVER.getValue());

        updateTokenRequest.setUpdateReason(updateReason);
    }
}
