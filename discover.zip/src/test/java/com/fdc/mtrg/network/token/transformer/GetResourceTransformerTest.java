package com.fdc.mtrg.network.token.transformer;

import com.fdc.mtrg.api.GetAssetResponse;
import com.fdc.mtrg.network.token.dto.GetAssetResponseDDX;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

import static com.fdc.mtrg.network.token.utils.TestUtils.getAssetResponse;
import static com.fdc.mtrg.network.token.utils.TestUtils.merchantId;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@RunWith(MockitoJUnitRunner.class)
public class GetResourceTransformerTest {

    public GetResourceTransformer resourceTransformer = new GetResourceTransformer();

    public static GetAssetResponseDDX assetResponseDDX;

    @BeforeClass
    public static void setup() throws Exception {
        assetResponseDDX = getAssetResponse(GetAssetResponseDDX.class);
    }

    @Test
    public void testTransformer() {
        GetAssetResponse assetResponse = resourceTransformer.doTransformRequest(merchantId, assetResponseDDX);

        assertNotNull(assetResponse);
        assertNotNull(assetResponse.getMediaContents());
        assertNotNull(assetResponse.getMediaContents().getMimeType());
        assertNotNull(assetResponse.getMediaContents().getHeight());
        assertNotNull(assetResponse.getMediaContents().getWidth());
        assertNotNull(assetResponse.getMediaContents().getData());
    }
}
