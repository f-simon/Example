package com.fdc.mtrg.network.token.service;

import com.fdc.mtrg.network.token.config.ApplicationProperties;
import com.fdc.mtrg.network.token.dto.GetAssetResponseDDX;
import com.fdc.mtrg.network.token.error.ApplicationError;
import com.fdc.util.exception.FdcException;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import static com.fdc.mtrg.network.token.utils.TestUtils.*;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class GetResourceServiceTest {

    @Rule
    public ExpectedException expectedException = ExpectedException.none();

    @Mock
    private ApplicationProperties applicationProperties;

    @Mock
    private ResponseEntity<GetAssetResponseDDX> responseEntity;

    @Mock
    private RestTemplate restTemplate;

    @InjectMocks
    GetResourceService SUT = new GetResourceService();

    @Test
    public void testResource() throws Exception {
        GetAssetResponseDDX assetResponse = getAssetResponse(GetAssetResponseDDX.class);

        when(applicationProperties.getServiceUrl()).thenReturn(ROOT_URL);
        when(responseEntity.getBody()).thenReturn(assetResponse);

        GetResourceService spyService = spy(SUT);

        doReturn(responseEntity)
                .when(restTemplate).exchange(ArgumentMatchers.anyString(),
                        ArgumentMatchers.any(HttpMethod.class),
                        ArgumentMatchers.any(),
                        ArgumentMatchers.<Class<GetAssetResponseDDX>>any());

        spyService.getResource(programId, resourceUUID, requestId, merchantId);

        verify(restTemplate).exchange(ArgumentMatchers.anyString(),
                ArgumentMatchers.any(HttpMethod.class),
                ArgumentMatchers.any(),
                ArgumentMatchers.<Class<GetAssetResponseDDX>>any());
    }

    @Test
    public void testAsset_RestClientException() throws Exception {

        when(applicationProperties.getServiceUrl()).thenReturn(ROOT_URL);

        doThrow(HttpClientErrorException.class).when(restTemplate)
                .exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), eq(GetAssetResponseDDX.class));

        expectedException.expect(FdcException.class);
        expectedException.expectMessage(ApplicationError.AUTHORIZATION_FAILED.getErrorDescription());

        GetResourceService spyService = spy(SUT);
        spyService.getResource(programId, badResourceUUID, requestId, merchantId);
    }

    @Test
    public void testAsset_With_Invalid_ParametersException() throws Exception {

        when(applicationProperties.getServiceUrl()).thenReturn(ROOT_URL);

        doThrow(HttpClientErrorException.class).when(restTemplate)
                .exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), eq(GetAssetResponseDDX.class));

        expectedException.expect(FdcException.class);
        expectedException.expectMessage(ApplicationError.AUTHORIZATION_FAILED.getErrorDescription());

        GetResourceService spyService = spy(SUT);
        spyService.getResource(programId, badResourceUUID, requestId, merchantId);
    }
}
