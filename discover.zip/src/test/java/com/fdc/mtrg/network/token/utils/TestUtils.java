package com.fdc.mtrg.network.token.utils;

import com.fasterxml.jackson.databind.ObjectMapper;

public class TestUtils {

    public static ObjectMapper objectMapper = new ObjectMapper();

    public final static String programId = "2940";
    public final static String resourceUUID = "e00fee88-67c6-42a6-bfc2-00a078a7c2ff";
    public final static String requestId = "req0001";
    public final static String merchantId = "TEST";
    public final static String badResourceUUID = "e00fee88-67c6-42a6+bfc2-00a078a7c2ff";
    public final static String badRequestId = "r q0001";
    public final static String badProgramId = "29=40";
    public final static String ROOT_URL = "http://localhost:8080/";
    public final static String MERCHANT_ID = "merchantId";

    public final static String RESOURCE_PAYLOAD = "{\"responseHeader\":{\"responseId\":\"req0001\",\"programId\":\"1000\"" +
            "},\"resourceResponse\":{\"resourceTypeCode\":\"07\",\"resourceUUID\":\"e00fee88-67c6-42a6-bfc2-00a078a7c2ff" +
            "\",\"resource\":[{\"media\":\"text/html\",\"encodedResource\":\"PGh0bWw+DQo8c3R5bGU+......\",\"height\":\"" +
            "600\",\"width\":\"400\"}]}}";

    public final static String BAD_RESOURCE_PAYLOAD = "{\"responseHeader\":{\"responseId\":\"fbc6768759554d0d9ca8acd918c" +
            "6ddb9\",\"programId\":\"1234ABCXYZ\",\"errors\":[{\"errorCode\":\"90002\",\"errorMessage\":\"Invalid Field Le" +
            "ngth–{programId}\"}]}}";

    public final static String TRANSACT_RESPONSE_PAYLOAD = "{\"transactionType\":\"ECOM\",\"paymentInstrument\":{\"paymentAccountReference\":\"V0010013816180398947326400396\"}," +
            "\"tokenInfo\":{\"expirationDate\":{\"month\":\"10\",\"year\":\"2018\"}},\"cryptogramInfo\":{\"cryptogram\":\"SaDA0Gw9cR37j8xrZP6VFCJpZ\",\"eci\":\"07\"}}";

    public final static String HEALTHCHECK_SUCCESS_RESPONSE = "{\"responseHeader\":{\"responseId\":\"fbc6768759554d0d9ca8acd918c6ddb9\",\"programId\":\"1000\"}," +
            "\"healthCheckResponse\":{\"version\":\"4.24.6-SNAPSHOT\",\"timestamp\":\"2020-04-08T15:28:24.224Z\"," +
            "\"platform\":\"NWP\",\"healthy\":\"false\",\"message\":\"Services health check is unsuccessful\"}}";

    public final static String HEALTHCHECK_ERROR_RESPONSE = "{\"responseHeader\":{\"responseId\":\"fbc6768759554d0d9ca8acd918c6ddb9\",\"programId\":\"2940\"," +
            "\"errors\":[{\"errorCode\":\"10024\",\"errorMessage\":\"Unknown programId\"}]}}";

    // FS
    public final static String REQUEST_PAYLOAD = "{\"provision\":{\"card\":{\"cardNumber\":\"54321111111111111\",\"nameOnCard\":\"John Smith\",\"securityCode\":\"444\"," +
            "\"expiryDate\":{\"month\":\"09\",\"year\":\"20\"},\"billingAddress\":{\"type\":\"work\",\"streetAddress\":\"100 Universal City Plaza\",\"locality\":\"Hollywood\"," +
            "\"region\":\"CA\",\"postalCode\":\"91608\",\"country\":\"USA\",\"formatted\":\"100 Universal City Plaza\\nHollywood, CA 91608 US\",\"primary\":true}," +
            "\"source\":\"ACCOUNT_ON_FILE\",\"captureMethod\":\"KEYENTERED\"},\"account\":{\"accountType\":\"GUEST\",\"email\":{\"type\":\"work\",\"value\":\"bjensen@example.com\"," +
            "\"primary\":true},\"clientWalletAccountId\":\"1234560987\",\"clientAppId\":\"1234560987\"},\"deviceDetails\":{\"id\":\"537edec8-d33e-4ee8-93a7\"," +
            "\"deviceScore\":\"5\",\"accountScore\":\"5\",\"loaction\":{\"latitude\":\"38.63\",\"longitude\":\"-90.25\",\"ipAddress\":\"172.27.37.221\"}},\"locale\":\"en_US\"}}";



    public static <T> T  getTokenRequest(Class<T> valueType) throws Exception {
        return objectMapper.readValue(REQUEST_PAYLOAD.getBytes(), valueType);
    }



    //FS

    public static <T> T  getAssetResponse(Class<T> valueType) throws Exception {
        return objectMapper.readValue(RESOURCE_PAYLOAD.getBytes(), valueType);
    }

    public static <T> T  getBadAssetResponse(Class<T> valueType) throws Exception {
        return objectMapper.readValue(BAD_RESOURCE_PAYLOAD.getBytes(), valueType);
    }

    public static <T> T  getTransactResponse(Class<T> valueType) throws Exception {
        return objectMapper.readValue(TRANSACT_RESPONSE_PAYLOAD.getBytes(), valueType);
    }

    public static <T> T  getHealthcheckResponse(boolean isSuccess, Class<T> valueType) throws Exception {
        String responseStr = isSuccess ? HEALTHCHECK_SUCCESS_RESPONSE : HEALTHCHECK_ERROR_RESPONSE;
        return objectMapper.readValue(responseStr.getBytes(), valueType);
    }
}
