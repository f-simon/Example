package com.fdc.mtrg.network.token.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fdc.mtrg.network.token.config.ApplicationProperties;
import com.fdc.mtrg.network.token.dto.*;
import com.fdc.mtrg.network.token.error.ApplicationError;
import com.fdc.mtrg.network.token.error.HeadLevelError;
import com.fdc.mtrg.network.token.util.Constants;
import com.fdc.util.exception.FdcException;
import com.fdc.util.exception.types.FdcSystemException;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import javax.servlet.http.HttpServletRequest;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class CreateLifecycleDeleteServiceTest {
    @Rule
    public ExpectedException expectedException = ExpectedException.none();

    @InjectMocks
    private CreateLifecycleDeleteService lifecycleDeleteervice = new CreateLifecycleDeleteService();

    @Mock
    private ObjectMapper objectMapper;

    @Mock
    private HttpServletRequest httpServletRequest;

    @Mock
    private ApplicationProperties applicationProperties;

    @Mock
    private RestTemplate restTemplate;

    @Mock
    private UpdateTokensRequestsDDX updateTokenRequest;

    private String errorStr;

    //com.fdc.mtrg.network.token.error  this import
    @Mock
    private HeadLevelError error;

    @Mock
    private UpdateTokensResponseDDX updateTokensResponseDDX;

    @Before
    public void setUp() throws JsonProcessingException {
        setData();
        when(applicationProperties.getServiceUrl()).thenReturn("http://localhost:8080/");
        when(httpServletRequest.getQueryString()).thenReturn(Constants.DDX_LIFECYCLE_PATH);

    }

    @Test
    public void testDoOutboundServiceCall_ThenReturnHtt_UpdateTokenResponseDDX() throws FdcSystemException, FdcException, JsonProcessingException {

        doReturn(new ResponseEntity<>(updateTokensResponseDDX, HttpStatus.OK)).when(restTemplate)
                .exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(Class.class));



        updateTokensResponseDDX = lifecycleDeleteervice.doOutboundServiceCall("test", "DWSDWSPMC000000000132d72d4fcb2f4136a0532d3093ff1a45",  updateTokenRequest);
        Assert.assertNotNull("is null", updateTokensResponseDDX);
    }

    @Test
    public void testDoOutboundServiceCall_Then_Throw_RestClientException() throws FdcSystemException, FdcException, JsonProcessingException {
        doThrow(RestClientException.class).when(restTemplate)
                .exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(Class.class));

        expectedException.expect(FdcSystemException.class);
        expectedException.expectMessage(ApplicationError.SERVICE_UNAVAILABLE.getErrorDescription());

        lifecycleDeleteervice.doOutboundServiceCall("test", "DWSDWSPMC000000000132d72d4fcb2f4136a0532d3093ff1a45", updateTokenRequest);
    }


    @Test
    public void testDoOutboundServiceCall_Then_Throw_FdcException() throws FdcSystemException, FdcException, JsonProcessingException {

        HttpClientErrorException.BadRequest returnErrorThrown = (HttpClientErrorException.BadRequest) HttpClientErrorException.BadRequest.create(HttpStatus.BAD_REQUEST,
                "Bad request", null, errorStr.getBytes(), null);


        doThrow(returnErrorThrown).when(restTemplate)
                .exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(Class.class));

        expectedException.expect(FdcException.class);

        lifecycleDeleteervice.doOutboundServiceCall("test", "DWSDWSPMC000000000132d72d4fcb2f4136a0532d3093ff1a45", updateTokenRequest);
    }

    @Test
    public void testDoOutboundServiceCall_Then_Throw_401() throws FdcException, JsonProcessingException {

        HttpClientErrorException.Unauthorized returnErrorThrown = (HttpClientErrorException.Unauthorized) HttpClientErrorException.Unauthorized.create(HttpStatus.UNAUTHORIZED,
                "Bad request", null, errorStr.getBytes(), null);


        doThrow(returnErrorThrown).when(restTemplate)
                .exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(Class.class));

        expectedException.expect(FdcException.class);

        lifecycleDeleteervice.doOutboundServiceCall("test", "DWSDWSPMC000000000132d72d4fcb2f4136a0532d3093ff1a45", updateTokenRequest);
    }


    @Test
    public void testDoOutboundServiceCall_Then_Throw_403() throws FdcException, JsonProcessingException {

        HttpClientErrorException.Forbidden returnErrorThrown = (HttpClientErrorException.Forbidden) HttpClientErrorException.Forbidden.create(HttpStatus.FORBIDDEN,
                "Bad request", null, errorStr.getBytes(), null);


        doThrow(returnErrorThrown).when(restTemplate)
                .exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(Class.class));

        expectedException.expect(FdcException.class);

        lifecycleDeleteervice.doOutboundServiceCall("test", "DWSDWSPMC000000000132d72d4fcb2f4136a0532d3093ff1a45", updateTokenRequest);
    }
    private void setData() throws JsonProcessingException {
        updateTokenRequest = new UpdateTokensRequestsDDX();
        RequestHeader requestHeader = new RequestHeader();
        AccountLifecycleRequest accountLifecycleRequest = new AccountLifecycleRequest();
        List<LifeycleOperationsRequest> lor = new ArrayList<>();

        LifeycleOperationsRequest lifeycleOperationsRequest = new LifeycleOperationsRequest();


        requestHeader.setProgramId("2490");
        requestHeader.setRequestId("R12345");

        lifeycleOperationsRequest.setTokenId("DWSDWSPMC000000000132d72d4fcb2f4136a0532d3093ff1a45");
        lor.add(lifeycleOperationsRequest);

        accountLifecycleRequest.setOperationType("SUSPEND");
        accountLifecycleRequest.setReason("User requested suspend due to lost device");

        updateTokenRequest.setRequestHeader(requestHeader);
        updateTokenRequest.setAccountLifecycleRequest(accountLifecycleRequest);

        errorStr = "{\"responseHeader\":{\"responseId\":\"000225bd-a16b-4d9a-940f-2026d698836c\",\"programId\":\"1000\",\"errors\":[{\"errorCode\":\"90001\",\"errorMessage\":\"Mandatory document/field missing - accountLifecycleRequest.lifecycleOperationsRequest\"}],\"sessionId\":\"a3173b4c-739f-48e9-8784-8964f98e9f5f\"}}";

        error = objectMapper.readValue(errorStr, HeadLevelError.class);
    }
}

